# Revised Implementation Plan: EDC AITR Motion & Interactive UI System

A disciplined, seven-phase motion and interaction architecture for the EDC AITR platform that separates expressive public-facing editorial motion from high-speed operational workspaces, enforces strict accessibility and permission boundaries, and coordinates entrance choreography with the existing cinematic preloader.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> **Mandatory Corrections Applied in This Revision**
> 1. **QR Scanner Removed from Scope**: The QR Check-in Console upgrade has been completely removed from this plan and reserved for its dedicated *QR Scanner & Event Check-in UI Upgrade* specification.
> 2. **Dual-Track Motion Discipline**: Public showcase pages use refined editorial motion, while authenticated Participant, Alumni, and Team Workspaces prioritize operational speed, stability, and minimal motion.
> 3. **Preloader Readiness Synchronization**: Homepage hero and editorial headline entrances wait on a shared readiness signal from the cinematic preloader so no animation executes or completes unseen behind the curtain.
> 4. **Permission-Aware Command Palette & Session Isolation**: Search retrieval is decoupled into a permission-scoped query service honoring event- and team-specific access boundaries (compatible with backend/RLS enforcement rather than client-only role hiding) and purges all cached results and query state immediately on sign-out or account switch.
> 5. **Full Overlay Accessibility & Unified Layering**: All dialogs, palettes, bottom sheets, and toasts adhere to a single z-index and focus-stack contract with focus trapping, focus restoration, background scroll/pointer locking, Escape stack precedence, and unsaved-form exit protection.
> 6. **Isolated Seven-Phase Delivery**: Implementation is strictly partitioned into seven sequential phases ending with performance profiling and regression verification.

---

## 1. Overview & Dual-Track Motion Philosophy

Rather than applying uniform animation styling across the entire platform, this system establishes two distinct motion tracks governed by a shared infrastructure layer:

- **Track A — Public Showcase (Editorial & Deliberate)**: Used selectively on public hero banners, major editorial headings, and curated Event/Startup showcase cards. Emphasizes typographic pacing, light pointer responsiveness, and seamless handoff from the cinematic logo preloader without ever delaying content readability.
- **Track B — Authenticated Portal & Workspaces (Fast & Functional)**: Used across Participant Portal, Alumni Connect, Governance, and Team Workspace. Prioritizes instant scannability, zero decorative distractions on administrative tables or headings, snappy state transitions (`120–180ms`), pauseable accessible toasts, smart messaging scroll retention, and keyboard-first navigation via the global Command Palette.

### Scope Boundaries (What Is Explicitly Excluded)
- **QR Check-in Console**: Left completely untouched in this plan (handled separately).
- **Routine Dashboard & Workspace Headings**: Remain static, crisp semantic headings—never word-split animated.
- **Administrative Cards, Tables & Forms**: No cursor-tracked spotlights or decorative hover glows.
- **Backend, Auth & Schema Integrity**: All existing authentication flows, role checks, event/team data structures, responsive layouts, and light/dark obsidian-crimson design tokens remain preserved.

---

## 2. User Experience, Accessibility & Visual Design

### Unified Overlay Hierarchy & Interaction Contract
All layered interfaces share a single deterministic stacking order and top-most Escape coordinator so nested overlays never collide or leak focus to background controls:

| Layer Tier | Z-Index Band | Focus & Scroll Policy | Dismissal & Guard Rules |
| :--- | :--- | :--- | :--- |
| **Cinematic Logo Preloader** | Highest (`z-[100]`) | Blocks background interaction until dismissal; immediately yields on `prefers-reduced-motion` or repeat visit | Emits shared `introReady` signal upon exit or skip; never traps focus after unmount |
| **Stacked Toast Notifications** | High (`z-[90]`) | Non-modal (`aria-live="polite"` / `"assertive"` for errors); never steals focus | Pauses auto-dismiss on hover **and** keyboard focus (`focus-within`); touch-friendly explicit dismiss button + swipe-out on mobile; throttles/deduplicates rapid repetitive admin notifications |
| **Global Command Palette (`⌘K`)** | Modal Top (`z-[75]`) | Focus-trapped with `role="dialog"` & `aria-modal="true"`; restores focus to previous trigger on close | Top-of-stack `Escape` closes palette before underlying dialogs; backdrop click closes; disabled while Preloader is active |
| **Modal Dialogs & Bottom Sheets** | Modal Base (`z-[65]`) | Focus-trapped via accessible dialog manager; background `inert` / scroll-locked; restores trigger focus on close | Supports nested confirmation dialogs; optional `isDirty` unsaved-changes guard intercepts Escape/backdrop dismissal with an inline confirmation prompt |

### Accessibility, Semantics & Replay Hygiene
- **Heading & Screen Reader Integrity**: Word-split kinetic headlines render a single semantic heading element (`<h1>` / `<h2>`) with full accessible text (`aria-label` or `sr-only` clean text while animated visual spans carry `aria-hidden="true"`), preventing screen readers from stuttering across word fragments.
- **Reduced Motion Compliance**: Every motion primitive checks `prefers-reduced-motion` centrally. When enabled, split reveals, spotlight tracking, 3D certificate tilt, and spring displacements degrade cleanly to instant or subtle opacity transitions.
- **Zero Unwanted Replays**: A lightweight session-scoped animation registry prevents already-revealed editorial headings and portal sections from re-animating during internal route switches, tab changes, or component remounts.
- **Responsive `⌘K` Affordance**: Desktop top bars display a compact `Search` icon paired with a tabular `⌘K` / `Ctrl K` keycap hint; mobile viewports render a clean, touch-sized (`44×44px`) search icon button without desktop keyboard labels.

### Realistic Rendering & Performance Budgeting
- We do **not** assume CSS `filter: blur()`, `backdrop-filter`, or dynamic radial gradients are free or compositor-only across mid-range mobile GPUs.
- **Selective Blur & Gradient Budget**:
  - Kinetic headline blur transitions are restricted strictly to 2–3 major public headings and settle rapidly (`< 450ms`), removing the `filter` property cleanly at rest so no layer remains promoted.
  - Backdrop blur on modal overlays uses modest radius (`4–6px`) and degrades gracefully on low-power/reduced-motion environments.
  - Pointer-tracked spotlight effects and certificate glare are bound exclusively to fine-pointer desktop devices (`@media (hover: hover) and (pointer: fine)`), automatically disabled on touch screens and mid-range mobile browsers, and updated via `requestAnimationFrame`-throttled CSS variables without React state re-renders.
  - During `window.print()`, PDF export, and credential verification views, all 3D transforms, specular foil layers, and backdrop effects are forcefully stripped via `@media print` and a flat verification mode so QR codes remain 100% crisp and machine-scannable.

---

## 3. Key Product Decisions & Trade-Offs

- **Reusable Accessible Primitives Over Reinvention**:
  - *Decision*: Keep dependencies lean as a preference rather than a rigid dogma—reuse existing accessible UI primitives and battle-tested focus/accessibility patterns rather than hand-rolling fragile focus traps or combobox ARIA wiring.
  - *Why*: Focus trapping, `inert` background handling, nested overlay stacking, and ARIA combobox announcements are subtle; proven accessible patterns eliminate keyboard dead-ends.
- **Permission-Scoped Search Provider (Not Client Role Hiding)**:
  - *Decision*: Route Command Palette queries through a dedicated `searchPortalEntities(query, authScope)` service that enforces authentication state, event-level assignments, and operational team permissions before constructing results—mirroring backend/Supabase RLS boundaries—and subscribes to auth state changes to wipe in-memory indices and recent search history immediately on logout or user switch.
  - *Why*: Ensures restricted records (pending membership applications, event registrations, internal tasks, private alumni threads) never leak into search suggestions or persist across account sessions.
- **Fuzzy Ranking + Aliases + Accessible Announcements**:
  - *Decision*: Implement lightweight fuzzy token scoring with domain aliases (e.g., `"qr"` / `"gate"` → Registration Desk Check-in, `"cert"` → Verified Certificates, `"utr"` → Registrations & Exports, `"2fa"` → Governance Security) and a polite live region announcing result counts (`"6 results found"` / `"No matches"`).
  - *Why*: Volunteers and students rarely remember exact route titles; aliases and relevance ranking make `⌘K` genuinely faster than clicking menus.
- **Toast Fatigue Prevention**:
  - *Decision*: Deduplicate identical rapid-fire notifications within a short window, cap visible stack depth to 3 items, and move timer control into a pauseable per-toast scheduler that freezes automatically when hovered or keyboard-focused.
  - *Why*: Prevents administrative batch operations from burying the workspace under a wall of stale popups while ensuring keyboard and screen-reader users have time to read every message.
- **Scroll-Aware Messaging & Explicit Delivery States**:
  - *Decision*: Track whether the user is anchored near the bottom of the message list (`≤ 72px` threshold). Auto-scroll only when the user sends a message or is already at the bottom; otherwise preserve exact scroll position and surface a subtle `"Jump to latest"` pill when a new incoming message arrives. Represent every outgoing message with explicit lifecycle states (`pending` → `confirmed` or `failed` with inline retry) driven by the actual send operation outcome.
  - *Why*: Reading older mentorship messages should never be interrupted by sudden scroll jumps, and failed sends must never masquerade as delivered.

---

## 4. Technical Architecture, Affected Components & Data Strategy

### System Architecture & Data Flow

```
┌────────────────────────────────────────────────────────────────────────────┐
│                    Shared Lifecycle, Theme & Auth Layer                    │
│  IntroLifecycleSignal (Preloader Ready) · PortalState & AuthScope          │
│  Unified Overlay Stack Manager (Z-Index, Focus Trap, Escape Precedence)    │
└─────────────┬──────────────────────────┬──────────────────────────┬────────┘
              │                          │                          │
  ┌───────────▼────────────┐ ┌───────────▼────────────┐ ┌───────────▼────────────┐
  │ Shared Motion & UI     │ │ Permission-Aware       │ │ Operational & Domain   │
  │ Infrastructure         │ │ Command Search Engine  │ │ Interaction Modules    │
  │ • MotionTrack tokens   │ │ • Auth/Event/Team      │ │ • Pauseable ToastStack │
  │   (Public vs Portal)   │ │   scoped query layer   │ │   (hover/focus pause,  │
  │ • Reduced-motion hook  │ │ • Fuzzy rank + aliases │ │   dedupe, mobile X)    │
  │ • Session replay guard │ │ • Purge on logout /    │ │ • Focus-Trapped Modal  │
  │ • KineticHeading       │ │   account change       │ │   (nested + dirty form │
  │   (public hero only)   │ │ • ARIA combobox +      │ │   confirmation guard)  │
  │ • Selective Spotlight  │ │   live result count    │ │ • Smart-Scroll Alumni  │
  │   (pointer-fine only)  │ └───────────┬────────────┘ │   Messaging (pending / │
  │ • Print-Safe TiltCard  │             │              │   confirmed / failed)  │
  └───────────┬────────────┘             │              └───────────┬────────────┘
              │                          │                          │
              └──────────────────────────┼──────────────────────────┘
                                         ▼
  ┌──────────────────────────────────────────────────────────────────────────┐
  │                        Affected Application Surfaces                     │
  │ • Preloader Shell      : Emits shared introReady lifecycle event         │
  │ • Public Navigation    : Compact ⌘K trigger (icon-only on mobile)        │
  │ • Portal Inset Header  : Compact ⌘K trigger (icon-only on mobile)        │
  │ • Public Showcase      : Hero & major editorial KineticHeadings (gated   │
  │                          on introReady) + selective Event Spotlights     │
  │ • Startup Showcase     : Selective Startup card Spotlight (desktop fine) │
  │ • Certificates View    : Subtle 3D tilt + foil sheen (flat on print/PDF) │
  │ • Alumni Messaging     : Scroll-preserving feed + delivery state badges  │
  │ • All Modal Workflows  : Registration, Tasks, Startup, Referral, Certs   │
  └──────────────────────────────────────────────────────────────────────────┘
```

### Affected Components Summary
- **Preloader & App Root**: Adds the shared `introReady` readiness provider and mounts the unified Overlay Stack Manager, `CommandPalette`, and upgraded `ToastStack` at the application root.
- **Public & Portal Headers**: Adds the responsive Command Palette trigger (compact shortcut hint on desktop, touch-sized search icon button on mobile) while preserving single-row navigation budgets.
- **Dialog & Notification Primitives**: Upgrades `ModalDialog` with accessible focus trapping, focus restoration, background locking, nested modal stacking, and optional `isDirty` unsaved-form protection; upgrades `ToastStack` with hover/focus timer pause, deduplication, and accessible mobile dismissal.
- **Public Showcase & Startup Showcase**: Wires `KineticHeading` exclusively onto selected public hero/editorial headings (gated on `introReady` and session replay guard) and wraps selected Event and Startup Showcase cards in pointer-fine-only `SpotlightCard`.
- **Verified Certificates View**: Adds subtle (`±5°` max) tilt and low-intensity foil glare on desktop hover while guaranteeing zero transforms or decorative layers inside the verification preview, print stylesheet, and PDF export.
- **Alumni Messaging View**: Adds bottom-proximity scroll locking, `"New messages"` jump button, spring entrance strictly for newly appended bubbles (no full-list replay on thread switch), and `pending` / `confirmed` / `failed` delivery status with retry action.

---

## 5. Seven-Phase Isolated Rollout Plan

Implementation will execute strictly in these seven isolated phases, verifying compilation and interactive behavior at the end of each phase before moving to the next:

1. **Phase 1 — Shared Motion Infrastructure & Preloader Lifecycle**
   - Establish dual-track motion tokens (Public Editorial vs. Portal Operational), centralized `prefers-reduced-motion` handling, session replay suppression registry, Unified Overlay Stack Manager, and the `IntroLifecycleContext` readiness bridge emitted by the existing cinematic preloader.
2. **Phase 2 — Global Command Palette**
   - Build the permission-aware search provider (respecting auth, event, and team scopes with immediate state/cache purge on logout or user switch), fuzzy matching + domain alias ranking, ARIA combobox keyboard navigation (`↑/↓/Enter/Esc`), live-region count announcements, meaningful empty/quick-action states, and responsive top-bar triggers (icon-only on mobile).
3. **Phase 3 — Accessible Dialogs & Stacked Toast Notifications**
   - Upgrade `ModalDialog` with focus trap, focus restoration, background scroll/pointer lock, nested overlay safety, and unsaved-form confirmation guard across existing modal forms. Refactor toast scheduling into pauseable hover/focus timers with deduplication and mobile-friendly dismiss controls.
4. **Phase 4 — Alumni In-App Messaging Enhancements**
   - Implement proximity-based scroll anchoring (preserve reading position when scrolled up, auto-scroll on own send or when pinned near bottom), explicit `pending` / `confirmed` / `failed` delivery states backed by real send outcomes with safe retry, and restrained new-message spring entrances.
5. **Phase 5 — Public-Facing Visual Enhancements**
   - Integrate `KineticHeading` strictly on selected public hero and major editorial headings (synchronized to `introReady` so nothing plays behind the preloader, with semantic screen-reader text intact). Apply fine-pointer-only `SpotlightCard` strictly to public Event cards and Alumni Startup Showcase cards.
6. **Phase 6 — Verified Certificate Interactions**
   - Add subtle, professional desktop-only tilt and specular sheen to verified certificate cards while enforcing strict `@media print` and modal-preview flattening so QR codes and printed PDFs remain razor-sharp and undistorted.
7. **Phase 7 — Integration, Performance Profiling & Regression Testing**
   - Verify cross-overlay precedence, auth/logout search isolation, reduced-motion compliance, light/dark parity, print fidelity, and frame-rate smoothness across desktop and simulated mid-range mobile viewports.

---

## 6. Potential Regressions & Mitigations

| Risk Area | Potential Regression | Mitigation Strategy |
| :--- | :--- | :--- |
| **Preloader Handoff** | Homepage hero stays invisible if the preloader is skipped, failsafed, or disabled by `prefers-reduced-motion` | Initialize `introReady = true` immediately whenever session storage indicates prior visit, reduced motion is active, or the preloader failsafe timer fires—guaranteeing hero text is never stranded invisible |
| **Keyboard Shortcut Conflicts** | `⌘K` or `Escape` conflicts with open `DropdownMenu`, `ModalDialog`, or text inputs | Central Overlay Stack Manager enforces strict top-down `Escape` handling (`CommandPalette` → topmost `ModalDialog` → open `DropdownMenu`); `⌘K` opens palette cleanly unless the Preloader is still active |
| **Unsaved Form Data Loss** | Pressing `Escape` or tapping backdrop accidentally discards an in-progress Event Registration, Task, or Startup submission | Add opt-in `isDirty` tracking on form modals so backdrop/Escape triggers a clean inline discard confirmation instead of silently dropping input |
| **Permission & Session Leakage** | Switching from Director to Participant or signing out leaves stale workspace items in Command Palette memory | Derive search index strictly from current auth scope and reset palette query, recent items, and memoized results inside an effect keyed on `currentUser?.id` and `currentUser?.role` |
| **Mobile GPU & Frame Drops** | Backdrop blur, radial spotlights, or tilt transforms cause scroll jank on mid-range Android devices | Gate spotlights and 3D tilt behind fine-pointer media queries, avoid persistent `filter`/`will-change` layers after entrance animations settle, and throttle pointer listeners via `requestAnimationFrame` |
| **Certificate Print / QR Distortion** | 3D CSS perspective or foil overlay breaks QR readability or clips printed PDF pages | Keep the printable certificate modal strictly 2D/flat and enforce `@media print` rules stripping all transforms, masks, glare overlays, and shadows |
| **Scroll Hijacking in Messaging** | Reading older alumni replies gets violently jumped to the bottom on re-render or thread update | Measure `scrollHeight - scrollTop - clientHeight <= 72` before auto-scrolling; never force-scroll when the user is browsing history |

---

## 7. Verification, Performance Profiling & Testing Strategy

- **Functional & Interactive Verification**:
  - Verify `introReady` synchronization on both cold first visit (preloader active) and warm reload (preloader skipped) to confirm homepage hero headings animate immediately after reveal without replaying on internal navigation back to Home.
  - Test `⌘K` / `Ctrl+K` and top-bar trigger across Guest, Participant, Alumni, Core Team, and Director roles; verify fuzzy queries, aliases (`"cert"`, `"utr"`, `"2fa"`), empty-state suggestions, keyboard navigation, and immediate cache/result purge upon sign-out and role switch.
  - Verify `ModalDialog` focus trap (`Tab` / `Shift+Tab`), focus restoration to the launching button, background scroll lock, nested dialog behavior, and unsaved-form discard protection.
  - Verify `ToastStack` hover pause, keyboard focus pause, mobile dismiss button, and deduplication under rapid consecutive actions.
  - Verify Alumni Messaging scroll preservation when scrolled up, auto-scroll on new send, and visual distinction of `pending`, `confirmed`, and `failed` (retryable) messages.
  - Verify Certificate hover tilt on desktop, flat neutral rendering on mobile/touch, and pristine QR legibility in Print / Save as PDF preview.
  - Confirm the QR Check-in Console page remains completely unmodified and fully functional.
- **Accessibility & Reduced-Motion Audit**:
  - Keyboard-only walkthrough across public navigation, Command Palette, modals, toasts, and messaging.
  - Inspect semantic heading outline (`h1`–`h3`), `aria-modal`, `aria-live` result announcements, and `prefers-reduced-motion: reduce` behavior across all six upgraded domains.
- **Performance & Responsive Profiling**:
  - Verify single-row top-bar ergonomics and zero horizontal overflow at `375×812` (mobile), `768×1024` (tablet), and `1440×900` (desktop) in both Light and Dark themes.
  - Profile frame timing during scrolling, modal transitions, spotlight hover, and messaging interactions; disable or simplify any effect causing sustained frame drops on throttled CPU/mobile profiles.
  - Run full TypeScript typecheck and production build (`compile_applet` + `lint_applet`) after completing implementation.
