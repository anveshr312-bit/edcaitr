import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Award,
  Briefcase,
  Building2,
  CalendarPlus,
  ChevronDown,
  ChevronsUpDown,
  ClipboardCheck,
  Copy,
  ExternalLink,
  FileCheck2,
  Globe,
  KanbanSquare,
  LayoutDashboard,
  Lock,
  LogOut,
  Megaphone,
  MessageSquare,
  MoreHorizontal,
  PanelLeftClose,
  PanelLeftOpen,
  Plus,
  QrCode,
  RotateCcw,
  ShieldCheck,
  Ticket,
  UserCheck,
  UserCircle2,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { usePortal } from '../../context/PortalContext';
import { useTheme } from '../../context/ThemeContext';
import { StudioButton } from '../ui/Primitives';
import { MemberAvatar } from '../identity/MemberAvatar';
import { EdcMark } from '../ui/EdcMark';
import { ThemeToggleButton } from '../ui/ThemeToggle';
import { CursorGrid } from '../ui/CursorGrid';
import { SmokePageTransition } from '../ui/SmokePageTransition';
import { CommandPaletteTrigger } from '../ui/CommandPalette';
import { Button } from '../ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';

interface NavItem {
  label: string;
  href: string;
  icon: React.FC<{ className?: string; strokeWidth?: number }>;
  badge?: number;
  badgeAlert?: boolean;
}

interface NavGroup {
  id: string;
  heading: string;
  items: NavItem[];
}

const SIDEBAR_STORAGE_KEY = 'edc_aitr_sidebar_collapsed';

export const PortalShell: React.FC<{
  breadcrumb: string[];
  actionSlot?: React.ReactNode;
  showCursorGrid?: boolean;
  children: React.ReactNode;
}> = ({ breadcrumb, actionSlot, showCursorGrid, children }) => {
  const {
    path,
    navigate,
    currentUser,
    events,
    registrations,
    tasks,
    announcements,
    certificates,
    applications,
    conversations,
    activeWorkspaceEventId,
    setActiveWorkspaceEventId,
    signOut,
    resetDemoData,
    pushToast,
  } = usePortal();
  const { isDark } = useTheme();

  const [mobileOpen, setMobileOpen] = useState(false);
  const [collapsed, setCollapsed] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    try {
      return window.localStorage.getItem(SIDEBAR_STORAGE_KEY) === '1';
    } catch {
      return false;
    }
  });
  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});
  const [hoveredTip, setHoveredTip] = useState<{ label: string; top: number; badge?: number } | null>(null);

  const isParticipantPortal = showCursorGrid ?? breadcrumb[0] === 'Participant Portal';
  const isStaff =
    currentUser?.role === 'core_team' ||
    currentUser?.role === 'advisor' ||
    currentUser?.role === 'director';

  const activeEvent = useMemo(
    () => events.find((e) => e.id === activeWorkspaceEventId) ?? events[0],
    [events, activeWorkspaceEventId]
  );

  // Persist collapse state & support Cmd/Ctrl+B shortcut
  useEffect(() => {
    try {
      window.localStorage.setItem(SIDEBAR_STORAGE_KEY, collapsed ? '1' : '0');
    } catch {
      // Ignore storage quota / private mode
    }
  }, [collapsed]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'b') {
        event.preventDefault();
        setCollapsed((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // Compute live real-time badge counts from PortalContext
  const liveBadges = useMemo(() => {
    const myRegs = currentUser
      ? registrations.filter(
          (r) =>
            r.userId === currentUser.id ||
            r.attendeeEmail.toLowerCase() === currentUser.email.toLowerCase()
        ).length
      : 0;
    const myCerts = currentUser
      ? certificates.filter((c) => c.userId === currentUser.id).length
      : 0;
    const activeEventTasks = tasks.filter(
      (t) => t.eventId === activeWorkspaceEventId && t.status !== 'Approved'
    );
    const changesRequested = activeEventTasks.filter(
      (t) => t.status === 'Changes Requested'
    ).length;
    const pendingPayments = registrations.filter(
      (r) =>
        r.eventId === activeWorkspaceEventId &&
        r.paymentStatus === 'Pending Payment Verification'
    ).length;
    const pendingApps = applications.filter((a) => a.status === 'Pending').length;
    const activeThreads = currentUser
      ? conversations.filter((c) => c.participantIds.includes(currentUser.id)).length
      : conversations.length;

    return {
      myRegs,
      myCerts,
      announcementsCount: announcements.length,
      openTasksCount: activeEventTasks.length,
      changesRequested,
      pendingPayments,
      pendingApps,
      activeThreads,
    };
  }, [
    activeWorkspaceEventId,
    announcements.length,
    applications,
    certificates,
    conversations,
    currentUser,
    registrations,
    tasks,
  ]);

  const navGroups: NavGroup[] = useMemo(
    () => [
      {
        id: 'participant',
        heading: 'Participant Portal',
        items: [
          {
            label: 'Dashboard & Tickets',
            href: '/portal',
            icon: Ticket,
            badge: liveBadges.myRegs || undefined,
          },
          {
            label: 'Announcements',
            href: '/portal/announcements',
            icon: Megaphone,
            badge: liveBadges.announcementsCount || undefined,
          },
          {
            label: 'My Identity',
            href: '/portal/profile',
            icon: UserCircle2,
          },
          {
            label: 'My Certificates',
            href: '/portal/certificates',
            icon: Award,
            badge: liveBadges.myCerts || undefined,
          },
          { label: 'Membership Apply', href: '/account/apply', icon: UserPlus },
        ],
      },
      ...(isStaff
        ? [
            {
              id: 'workspace',
              heading: 'Team Workspace',
              items: [
                { label: 'Command Center', href: '/workspace', icon: LayoutDashboard },
                {
                  label: 'Event Builder',
                  href: `/workspace/events/${activeWorkspaceEventId}`,
                  icon: CalendarPlus,
                },
                {
                  label: '12-Team Roster',
                  href: `/workspace/events/${activeWorkspaceEventId}/teams`,
                  icon: Users,
                },
                {
                  label: 'Task Board',
                  href: `/workspace/events/${activeWorkspaceEventId}/tasks`,
                  icon: KanbanSquare,
                  badge: liveBadges.openTasksCount || undefined,
                  badgeAlert: liveBadges.changesRequested > 0,
                },
                {
                  label: 'QR Check-in Console',
                  href: `/workspace/events/${activeWorkspaceEventId}/checkin`,
                  icon: QrCode,
                },
                {
                  label: 'Registrations & CSV',
                  href: `/workspace/events/${activeWorkspaceEventId}/registrations`,
                  icon: ClipboardCheck,
                  badge: liveBadges.pendingPayments || undefined,
                  badgeAlert: liveBadges.pendingPayments > 0,
                },
                {
                  label: 'Closure & Records',
                  href: `/workspace/events/${activeWorkspaceEventId}/closure`,
                  icon: Lock,
                },
              ],
            },
            {
              id: 'governance',
              heading: 'Governance',
              items: [
                {
                  label: 'Application Reviews',
                  href: '/account/applications',
                  icon: UserCheck,
                  badge: liveBadges.pendingApps || undefined,
                  badgeAlert: liveBadges.pendingApps > 0,
                },
                { label: 'Director 2FA (TOTP)', href: '/account/mfa', icon: ShieldCheck },
              ],
            },
          ]
        : []),
      {
        id: 'alumni',
        heading: 'Alumni Connect',
        items: [
          { label: 'Verified Directory', href: '/alumni/directory', icon: Building2 },
          { label: 'Startup Showcase', href: '/alumni/startups', icon: FileCheck2 },
          { label: 'Opportunities Board', href: '/alumni/opportunities', icon: Briefcase },
          {
            label: 'In-App Messages',
            href: '/alumni/messages',
            icon: MessageSquare,
            badge: liveBadges.activeThreads || undefined,
          },
        ],
      },
    ],
    [activeWorkspaceEventId, isStaff, liveBadges]
  );

  const cleanRoutePath = path.split('?')[0].replace(/\/+$/, '') || '/';

  const isActive = (href: string) => {
    const cleanPath = cleanRoutePath;
    if (href === '/portal') {
      return (
        cleanPath === '/portal' ||
        cleanPath === '/account/dashboard' ||
        cleanPath.startsWith('/portal/registrations')
      );
    }
    if (href === '/workspace') return cleanPath === '/workspace';
    return cleanPath === href;
  };

  const toggleGroup = (id: string) => {
    setCollapsedGroups((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleCopyEventLink = (slug: string, title: string) => {
    const url = `${window.location.origin}/events/${slug}`;
    navigator.clipboard?.writeText(url).catch(() => {});
    pushToast('Event link copied', `${title} public URL copied to clipboard.`, 'success');
  };

  const handleSelectEventContext = (evtId: string) => {
    setActiveWorkspaceEventId(evtId);
    if (cleanRoutePath.startsWith('/workspace/events/')) {
      const subMatch = cleanRoutePath.match(/\/workspace\/events\/[^/]+(\/.*)?$/);
      const subPath = subMatch?.[1] ?? '';
      navigate(`/workspace/events/${evtId}${subPath}`);
    } else if (isStaff) {
      navigate('/workspace');
    }
    setMobileOpen(false);
  };

  const renderSidebarBody = (isMobileDrawer: boolean) => {
    const compact = !isMobileDrawer && collapsed;

    return (
      <div className="flex flex-col h-full select-none">
        {/* Header: Official EDC Monogram + Interactive Context / Workspace Switcher */}
        <div
          className={`h-[64px] shrink-0 flex items-center gap-2 border-b border-[var(--border-hairline)] ${
            compact ? 'px-2 justify-center' : 'px-3'
          }`}
        >
          <DropdownMenu>
            <DropdownMenuTrigger
              className={`group flex items-center gap-2.5 rounded-[10px] transition-colors duration-150 cursor-pointer hover:bg-[var(--surface)] aria-expanded:bg-[var(--surface)] focus-visible:outline-2 focus-visible:outline-[#C01E30] ${
                compact ? 'p-1.5 justify-center' : 'w-full px-2 py-1.5 min-w-0'
              }`}
            >
              <span className="size-8 shrink-0 rounded-[9px] bg-[#0B0C10] dark:bg-[#202022] border border-black/10 dark:border-[#303032] flex items-center justify-center p-1.5 shadow-xs transition-transform duration-200 group-hover:scale-[1.04]">
                <EdcMark className="w-full h-auto" />
              </span>
              {!compact && (
                <>
                  <span className="grid min-w-0 flex-1 text-left leading-tight">
                    <span className="truncate text-[13px] font-display font-semibold text-[var(--color-2-mood)]">
                      {isStaff && activeEvent ? activeEvent.title : 'EDC AITR Portal'}
                    </span>
                    <span className="truncate text-[11px] text-[var(--ink-muted)] flex items-center gap-1.5">
                      <span
                        className={`inline-block size-1.5 rounded-full shrink-0 ${
                          activeEvent?.status === 'Published'
                            ? 'bg-emerald-500'
                            : 'bg-zinc-400'
                        }`}
                      />
                      {isStaff && activeEvent
                        ? `${activeEvent.status} · Workspace`
                        : currentUser?.designation ?? 'Acropolis Indore'}
                    </span>
                  </span>
                  <ChevronsUpDown className="h-3.5 w-3.5 shrink-0 text-[var(--ink-muted)] group-hover:text-[var(--color-2-mood)] transition-colors" />
                </>
              )}
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="start"
              className="min-w-[248px]"
            >
              {isStaff ? (
                <>
                  <DropdownMenuGroup>
                    <DropdownMenuLabel>Active Event Workspace</DropdownMenuLabel>
                    {events.map((evt) => (
                      <DropdownMenuItem
                        key={evt.id}
                        selected={evt.id === activeEvent?.id}
                        onSelect={() => handleSelectEventContext(evt.id)}
                        icon={
                          <span
                            className={`inline-block size-2 rounded-full ${
                              evt.status === 'Published'
                                ? 'bg-emerald-500'
                                : 'bg-zinc-400'
                            }`}
                          />
                        }
                        shortcut={evt.status}
                      >
                        {evt.title}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem
                      icon={<Plus className="h-3.5 w-3.5 text-[#C01E30]" />}
                      onSelect={() => {
                        navigate('/workspace/events/new');
                        setMobileOpen(false);
                      }}
                    >
                      Create New Event
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      icon={<Globe className="h-3.5 w-3.5" />}
                      onSelect={() => {
                        navigate('/');
                        setMobileOpen(false);
                      }}
                    >
                      View Public Website
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                </>
              ) : (
                <>
                  <DropdownMenuGroup>
                    <DropdownMenuLabel>EDC AITR Spaces</DropdownMenuLabel>
                    <DropdownMenuItem
                      selected={breadcrumb[0] === 'Participant Portal'}
                      icon={<Ticket className="h-3.5 w-3.5" />}
                      onSelect={() => {
                        navigate('/portal');
                        setMobileOpen(false);
                      }}
                    >
                      Participant Portal
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      selected={breadcrumb[0] === 'Alumni Connect'}
                      icon={<Building2 className="h-3.5 w-3.5" />}
                      onSelect={() => {
                        navigate('/alumni/directory');
                        setMobileOpen(false);
                      }}
                    >
                      Alumni Connect
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem
                      icon={<Globe className="h-3.5 w-3.5" />}
                      onSelect={() => {
                        navigate('/');
                        setMobileOpen(false);
                      }}
                    >
                      Public Website
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          {isMobileDrawer && (
            <button
              type="button"
              onClick={() => setMobileOpen(false)}
              className="h-8 w-8 rounded-[8px] border border-[var(--border-hairline)] flex items-center justify-center text-[var(--ink-secondary)] hover:bg-[var(--surface)] cursor-pointer shrink-0"
              aria-label="Close sidebar"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Scrollable Navigation Groups + Interactive Live Events List */}
        <nav
          aria-label="Portal navigation"
          className={`flex-1 overflow-y-auto py-3 space-y-4 ${compact ? 'px-2' : 'px-2.5'}`}
        >
          {navGroups.map((group) => {
            const isGroupCollapsed = !compact && Boolean(collapsedGroups[group.id]);
            return (
              <div key={group.id} className="space-y-1">
                {!compact ? (
                  <button
                    type="button"
                    onClick={() => toggleGroup(group.id)}
                    className="w-full flex items-center justify-between px-2.5 py-1 text-[11px] font-semibold text-[var(--ink-muted)] hover:text-[var(--color-2-mood)] tracking-[0.03em] transition-colors cursor-pointer"
                  >
                    <span>{group.heading}</span>
                    <ChevronDown
                      className={`h-3 w-3 transition-transform duration-200 ${
                        isGroupCollapsed ? '-rotate-90' : 'rotate-0'
                      }`}
                    />
                  </button>
                ) : (
                  <div className="mx-2 my-1.5 h-px bg-[var(--border-hairline)]" />
                )}

                <AnimatePresence initial={false}>
                  {!isGroupCollapsed && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.18, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden space-y-0.5"
                    >
                      {group.items.map((item) => {
                        const Icon = item.icon;
                        const active = isActive(item.href);
                        return (
                          <button
                            key={item.href}
                            type="button"
                            onClick={() => {
                              navigate(item.href);
                              setMobileOpen(false);
                            }}
                            onMouseEnter={(e) => {
                              if (!compact) return;
                              const rect = e.currentTarget.getBoundingClientRect();
                              setHoveredTip({
                                label: item.label,
                                top: rect.top + rect.height / 2,
                                badge: item.badge,
                              });
                            }}
                            onMouseLeave={() => setHoveredTip(null)}
                            className={`group relative w-full flex items-center rounded-[9px] text-[13px] font-medium transition-colors duration-150 cursor-pointer ${
                              compact
                                ? 'justify-center h-9 px-0'
                                : 'gap-2.5 px-2.5 py-2'
                            } ${
                              active
                                ? 'text-[#C01E30] dark:text-[#F87171]'
                                : 'text-[var(--ink-secondary)] hover:text-[var(--color-2-mood)] hover:bg-[var(--surface)]/80'
                            }`}
                          >
                            {/* Spring-sliding active indicator pill */}
                            {active && (
                              <motion.span
                                layoutId={
                                  isMobileDrawer
                                    ? 'mobile-sidebar-active-pill'
                                    : 'desktop-sidebar-active-pill'
                                }
                                transition={{
                                  type: 'spring',
                                  stiffness: 420,
                                  damping: 32,
                                }}
                                className="absolute inset-0 rounded-[9px] bg-[var(--accent-soft)] border border-[var(--accent-border)]/70"
                              />
                            )}
                            {active && !compact && (
                              <motion.span
                                layoutId={
                                  isMobileDrawer
                                    ? 'mobile-sidebar-active-bar'
                                    : 'desktop-sidebar-active-bar'
                                }
                                transition={{
                                  type: 'spring',
                                  stiffness: 420,
                                  damping: 32,
                                }}
                                className="absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-r-full bg-[#C01E30]"
                              />
                            )}

                            <Icon
                              className={`relative z-10 h-4 w-4 shrink-0 transition-transform duration-150 group-hover:scale-110 ${
                                active ? 'text-[#C01E30] dark:text-[#F87171]' : ''
                              }`}
                              strokeWidth={active ? 2 : 1.75}
                            />
                            {!compact && (
                              <>
                                <span className="relative z-10 truncate flex-1 text-left">
                                  {item.label}
                                </span>
                                {item.badge !== undefined && (
                                  <span
                                    className={`relative z-10 font-mono-data text-[10px] font-semibold px-1.5 py-0.5 rounded-full leading-none ${
                                      item.badgeAlert
                                        ? 'bg-[#C01E30] text-white'
                                        : active
                                          ? 'bg-[#C01E30]/15 text-[#C01E30] dark:text-[#F87171]'
                                          : 'bg-[var(--surface)] border border-[var(--border-hairline)] text-[var(--ink-muted)]'
                                    }`}
                                  >
                                    {item.badge}
                                  </span>
                                )}
                              </>
                            )}
                            {compact && item.badgeAlert && (
                              <span className="absolute top-1.5 right-2 z-10 size-2 rounded-full bg-[#C01E30]" />
                            )}
                          </button>
                        );
                      })}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}

          {/* Interactive Live Events Quick-List (Upgraded ProjectNav with hover ••• DropdownMenu) */}
          {!compact && (
            <div className="pt-2 border-t border-[var(--border-hairline)] space-y-1">
              <div className="flex items-center justify-between px-2.5 py-1">
                <span className="text-[11px] font-semibold text-[var(--ink-muted)] tracking-[0.03em]">
                  Active Events
                </span>
                {isStaff && (
                  <button
                    type="button"
                    onClick={() => {
                      navigate('/workspace/events/new');
                      setMobileOpen(false);
                    }}
                    title="Create new event"
                    aria-label="Create new event"
                    className="h-5 w-5 rounded-[6px] flex items-center justify-center text-[var(--ink-muted)] hover:text-[#C01E30] hover:bg-[var(--surface)] transition-colors cursor-pointer"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>

              <div className="space-y-0.5">
                {events.slice(0, 4).map((evt) => {
                  const isCurrentEvt = evt.id === activeWorkspaceEventId && isStaff;
                  return (
                    <div
                      key={evt.id}
                      className={`group relative flex items-center rounded-[9px] transition-colors duration-150 ${
                        isCurrentEvt
                          ? 'bg-[var(--surface)] border border-[var(--border-hairline)]'
                          : 'hover:bg-[var(--surface)]/80'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => {
                          if (isStaff) {
                            handleSelectEventContext(evt.id);
                          } else {
                            navigate(`/events/${evt.slug}`);
                            setMobileOpen(false);
                          }
                        }}
                        className="flex-1 min-w-0 flex items-center gap-2.5 px-2.5 py-1.5 text-left text-xs font-medium text-[var(--ink-secondary)] group-hover:text-[var(--color-2-mood)] cursor-pointer"
                      >
                        <span className="relative flex size-2 shrink-0">
                          {evt.status === 'Published' && (
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60" />
                          )}
                          <span
                            className={`relative inline-flex rounded-full size-2 ${
                              evt.status === 'Published'
                                ? 'bg-emerald-500'
                                : 'bg-zinc-400'
                            }`}
                          />
                        </span>
                        <span className="truncate">{evt.title}</span>
                      </button>

                      <DropdownMenu>
                        <DropdownMenuTrigger
                          aria-label={`Actions for ${evt.title}`}
                          className="h-7 w-7 mr-1 rounded-[7px] flex items-center justify-center text-[var(--ink-muted)] hover:text-[var(--color-2-mood)] hover:bg-[var(--surface-subtle)] opacity-100 md:opacity-0 md:group-hover:opacity-100 aria-expanded:opacity-100 transition-opacity cursor-pointer shrink-0"
                        >
                          <MoreHorizontal className="h-3.5 w-3.5" />
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="min-w-[196px]">
                          <DropdownMenuGroup>
                            <DropdownMenuLabel>{evt.title}</DropdownMenuLabel>
                            <DropdownMenuItem
                              icon={<ExternalLink className="h-3.5 w-3.5" />}
                              onSelect={() => {
                                navigate(`/events/${evt.slug}`);
                                setMobileOpen(false);
                              }}
                            >
                              View Public Page
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              icon={<Copy className="h-3.5 w-3.5" />}
                              onSelect={() => handleCopyEventLink(evt.slug, evt.title)}
                            >
                              Copy Event Link
                            </DropdownMenuItem>
                          </DropdownMenuGroup>
                          {isStaff && (
                            <>
                              <DropdownMenuSeparator />
                              <DropdownMenuGroup>
                                <DropdownMenuItem
                                  icon={<CalendarPlus className="h-3.5 w-3.5" />}
                                  onSelect={() => {
                                    setActiveWorkspaceEventId(evt.id);
                                    navigate(`/workspace/events/${evt.id}`);
                                    setMobileOpen(false);
                                  }}
                                >
                                  Open Event Builder
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  icon={<QrCode className="h-3.5 w-3.5" />}
                                  onSelect={() => {
                                    setActiveWorkspaceEventId(evt.id);
                                    navigate(`/workspace/events/${evt.id}/checkin`);
                                    setMobileOpen(false);
                                  }}
                                >
                                  QR Check-in Console
                                </DropdownMenuItem>
                              </DropdownMenuGroup>
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </nav>

        {/* Footer: Interactive Account Dropdown Menu */}
        <div
          className={`shrink-0 border-t border-[var(--border-hairline)] ${
            compact ? 'p-2' : 'p-2.5'
          }`}
        >
          {currentUser && (
            <DropdownMenu>
              <DropdownMenuTrigger
                className={`group flex items-center gap-2.5 rounded-[10px] transition-colors duration-150 cursor-pointer hover:bg-[var(--surface)] aria-expanded:bg-[var(--surface)] focus-visible:outline-2 focus-visible:outline-[#C01E30] ${
                  compact ? 'w-full justify-center p-1.5' : 'w-full px-2 py-2'
                }`}
              >
                <MemberAvatar
                  name={currentUser.preferredName || currentUser.name}
                  avatarUrl={currentUser.avatarUrl}
                  avatarPosition={currentUser.avatarPosition}
                  size="sm"
                  tone="obsidian"
                />
                {!compact && (
                  <>
                    <span className="grid min-w-0 flex-1 text-left leading-tight">
                      <span className="truncate text-xs font-semibold text-[var(--color-2-mood)]">
                        {currentUser.preferredName || currentUser.name}
                      </span>
                      <span className="truncate text-[11px] text-[var(--ink-muted)]">
                        {currentUser.designation}
                      </span>
                    </span>
                    <ChevronsUpDown className="h-3.5 w-3.5 shrink-0 text-[var(--ink-muted)] group-hover:text-[var(--color-2-mood)] transition-colors" />
                  </>
                )}
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="min-w-[232px]">
                <DropdownMenuGroup>
                  <DropdownMenuLabel>
                    <span className="block text-xs font-semibold text-[var(--color-2-mood)] truncate">
                      {currentUser.preferredName || currentUser.name}
                    </span>
                    <span className="block text-[10px] font-normal text-[var(--ink-muted)] truncate">
                      {currentUser.email}
                    </span>
                  </DropdownMenuLabel>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem
                    icon={<UserCircle2 className="h-3.5 w-3.5" />}
                    onSelect={() => {
                      navigate('/portal/profile');
                      setMobileOpen(false);
                    }}
                  >
                    My Identity
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    icon={<Ticket className="h-3.5 w-3.5" />}
                    onSelect={() => {
                      navigate('/portal');
                      setMobileOpen(false);
                    }}
                  >
                    Dashboard &amp; Tickets
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    icon={<Award className="h-3.5 w-3.5" />}
                    onSelect={() => {
                      navigate('/portal/certificates');
                      setMobileOpen(false);
                    }}
                  >
                    My Certificates
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    icon={<Globe className="h-3.5 w-3.5" />}
                    onSelect={() => {
                      navigate('/');
                      setMobileOpen(false);
                    }}
                  >
                    Public Website
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem
                    icon={<Users className="h-3.5 w-3.5" />}
                    onSelect={() => {
                      navigate('/account');
                      setMobileOpen(false);
                    }}
                  >
                    Switch Role / Account
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    icon={<RotateCcw className="h-3.5 w-3.5" />}
                    onSelect={() => {
                      resetDemoData();
                      setMobileOpen(false);
                    }}
                  >
                    Reset Demo Data
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    destructive
                    icon={<LogOut className="h-3.5 w-3.5" />}
                    shortcut="⇧⌘Q"
                    onSelect={() => {
                      signOut();
                      setMobileOpen(false);
                    }}
                  >
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuGroup>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="relative min-h-screen flex bg-[var(--surface-subtle)] dark:bg-[#101011] text-[var(--color-2-mood)] transition-colors duration-200">
      {/* Interactive WebGL2 CursorGrid Background for Participant Web */}
      {isParticipantPortal && (
        <div
          className="fixed inset-0 z-0 pointer-events-none no-print"
          aria-hidden="true"
        >
          <CursorGrid
            cellSize={isDark ? 50 : 56}
            color="#C01E30"
            gridColor={isDark ? '#A1A1AA' : '#111318'}
            highlight="area"
            gridStyle="lines"
            radius={isDark ? 105 : 145}
            falloff="smooth"
            lineWidth={isDark ? 0.7 : 1}
            holdTime={isDark ? 80 : 360}
            fadeDuration={isDark ? 450 : 760}
            maxOpacity={isDark ? 0.22 : 0.45}
            fillOpacity={isDark ? 0.012 : 0.045}
            gridOpacity={isDark ? 0.03 : 0.055}
            spotlight={isDark ? 0.1 : 0.5}
            ambient={0}
            edgeFade={isDark ? 0.32 : 0.18}
            lightMode={!isDark}
            clickPulse
            intro
          />
        </div>
      )}

      {/* Desktop Collapsible Inset Rail Sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: collapsed ? 72 : 268 }}
        transition={{ type: 'spring', stiffness: 340, damping: 34 }}
        className="hidden lg:block shrink-0 sticky top-0 h-screen z-20 no-print overflow-hidden"
      >
        {renderSidebarBody(false)}
      </motion.aside>

      {/* Floating Tooltip for Collapsed Desktop Icon Rail */}
      <AnimatePresence>
        {collapsed && hoveredTip && (
          <motion.div
            initial={{ opacity: 0, x: -6 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -4 }}
            transition={{ duration: 0.12 }}
            style={{ top: hoveredTip.top, left: 78 }}
            className="hidden lg:flex fixed -translate-y-1/2 z-50 items-center gap-2 px-2.5 py-1.5 rounded-[8px] bg-[#0B0C10] dark:bg-[#F1F0ED] text-white dark:text-[#101011] text-xs font-medium shadow-lg pointer-events-none whitespace-nowrap"
          >
            <span>{hoveredTip.label}</span>
            {hoveredTip.badge !== undefined && (
              <span className="font-mono-data text-[10px] px-1.5 py-0.5 rounded-full bg-[#C01E30] text-white">
                {hoveredTip.badge}
              </span>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Slide-Over Animated Sidebar Sheet */}
      <AnimatePresence>
        {mobileOpen && (
          <div className="fixed inset-0 z-50 lg:hidden no-print">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="absolute inset-0 bg-[#030405]/55 dark:bg-black/68 backdrop-blur-xs"
              onClick={() => setMobileOpen(false)}
            />
            <motion.aside
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', stiffness: 360, damping: 36 }}
              className="relative w-[280px] max-w-[85vw] h-full bg-[var(--surface-subtle)] dark:bg-[#141416] border-r border-[var(--border-strong)] shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              {renderSidebarBody(true)}
            </motion.aside>
          </div>
        )}
      </AnimatePresence>

      {/* Inset Elevated Workbench Surface */}
      <div className="relative z-10 flex-1 min-w-0 flex flex-col lg:py-2.5 lg:pr-2.5">
        <div className="flex-1 min-w-0 flex flex-col bg-[var(--color-1-mood)]/96 dark:bg-[#141416] lg:rounded-[18px] lg:border lg:border-[var(--border-hairline)] dark:lg:border-[#303032]/85 lg:shadow-[0_10px_32px_-16px_rgba(3,4,5,0.12)] dark:lg:shadow-none overflow-x-clip">
          {/* Inset Sticky Header with SidebarTrigger + Animated Breadcrumb + Account Menu + Theme Toggle */}
          <header className="sticky top-0 z-30 h-[62px] bg-white/90 dark:bg-[#141416]/94 backdrop-blur-md border-b border-[var(--border-hairline)] dark:border-[#303032]/75 lg:rounded-t-[18px] px-3.5 sm:px-6 flex items-center justify-between gap-3 no-print">
            <div className="flex items-center gap-2.5 min-w-0">
              {/* Desktop Rail Collapse Toggle */}
              <button
                type="button"
                onClick={() => setCollapsed((prev) => !prev)}
                aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                title={collapsed ? 'Expand sidebar (⌘B)' : 'Collapse sidebar (⌘B)'}
                className="hidden lg:inline-flex h-8 w-8 rounded-[8px] border border-[var(--border-hairline)] hover:border-[var(--border-strong)] hover:bg-[var(--surface-subtle)] items-center justify-center text-[var(--ink-secondary)] hover:text-[var(--color-2-mood)] transition-colors cursor-pointer shrink-0"
              >
                {collapsed ? (
                  <PanelLeftOpen className="h-4 w-4" />
                ) : (
                  <PanelLeftClose className="h-4 w-4" />
                )}
              </button>

              {/* Mobile Drawer Toggle */}
              <button
                type="button"
                onClick={() => setMobileOpen(true)}
                aria-label="Open portal navigation"
                className="lg:hidden h-8 w-8 rounded-[8px] border border-[var(--border-strong)] flex items-center justify-center text-[var(--color-2-mood)] hover:bg-[var(--surface-subtle)] cursor-pointer shrink-0"
              >
                <PanelLeftOpen className="h-4 w-4" />
              </button>

              <span className="h-4 w-px bg-[var(--border-hairline)] shrink-0" aria-hidden="true" />

              <nav aria-label="Breadcrumb" className="min-w-0 overflow-hidden">
                <ol className="flex items-center gap-1.5 text-sm min-w-0">
                  {breadcrumb.map((crumb, idx) => {
                    const isLast = idx === breadcrumb.length - 1;
                    const resolvedHref = (() => {
                      switch (crumb) {
                        case 'Team Workspace':
                        case 'Governance':
                          return '/workspace';
                        case 'Participant Portal':
                        case 'My Registrations':
                          return '/portal';
                        case 'Alumni Connect':
                          return '/alumni/directory';
                        case 'Identity Studio':
                          return '/portal/profile';
                        case 'Event Builder':
                          return `/workspace/events/${activeWorkspaceEventId}`;
                        default:
                          return null;
                      }
                    })();

                    return (
                      <li key={`${crumb}-${idx}`} className="flex items-center gap-1.5 min-w-0">
                        {idx > 0 && (
                          <span aria-hidden="true" className="text-[var(--ink-muted)]/60 shrink-0">
                            /
                          </span>
                        )}
                        {!isLast && resolvedHref ? (
                          <button
                            type="button"
                            onClick={() => navigate(resolvedHref)}
                            className="truncate text-[var(--ink-muted)] hover:text-[var(--color-2-mood)] hover:underline underline-offset-4 transition-colors duration-150 cursor-pointer rounded-[4px] px-1 -mx-1 py-0.5"
                          >
                            {crumb}
                          </button>
                        ) : (
                          <span
                            aria-current={isLast ? 'page' : undefined}
                            className={`truncate ${
                              isLast
                                ? 'font-semibold text-[var(--color-2-mood)]'
                                : 'text-[var(--ink-muted)]'
                            }`}
                          >
                            {crumb}
                          </span>
                        )}
                      </li>
                    );
                  })}
                </ol>
              </nav>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
              <CommandPaletteTrigger />
              {actionSlot}
              {!actionSlot && (
                <StudioButton
                  variant="secondary"
                  size="sm"
                  className="hidden lg:inline-flex"
                  onClick={() => navigate('/events')}
                >
                  Browse Events
                </StudioButton>
              )}
              {currentUser && (
                <DropdownMenu>
                  <DropdownMenuTrigger
                    render={
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-fit px-2.5 sm:px-3 gap-1.5"
                      />
                    }
                  >
                    <MemberAvatar
                      name={currentUser.preferredName || currentUser.name}
                      avatarUrl={currentUser.avatarUrl}
                      avatarPosition={currentUser.avatarPosition}
                      size="xs"
                      shape="circle"
                      tone="crimson"
                    />
                    <span className="hidden sm:inline max-w-[110px] truncate">
                      {(currentUser.preferredName || currentUser.name).split(' ')[0]}
                    </span>
                    <ChevronDown className="h-3.5 w-3.5 text-[var(--ink-muted)]" />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="min-w-[224px]">
                    <DropdownMenuGroup>
                      <DropdownMenuLabel>My Account</DropdownMenuLabel>
                      <DropdownMenuItem
                        icon={<UserCircle2 className="h-3.5 w-3.5" />}
                        onSelect={() => navigate('/portal/profile')}
                      >
                        My Identity
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        icon={<Ticket className="h-3.5 w-3.5" />}
                        onSelect={() => navigate('/portal')}
                      >
                        Dashboard &amp; Tickets
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        icon={<Award className="h-3.5 w-3.5" />}
                        onSelect={() => navigate('/portal/certificates')}
                      >
                        My Certificates
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        icon={<Building2 className="h-3.5 w-3.5" />}
                        onSelect={() => navigate('/alumni/directory')}
                      >
                        Alumni Directory
                      </DropdownMenuItem>
                      {isStaff && (
                        <DropdownMenuItem
                          icon={<LayoutDashboard className="h-3.5 w-3.5" />}
                          onSelect={() => navigate('/workspace')}
                        >
                          Team Workspace
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuGroup>
                    <DropdownMenuSeparator />
                    <DropdownMenuGroup>
                      <DropdownMenuItem
                        icon={<Globe className="h-3.5 w-3.5" />}
                        onSelect={() => navigate('/')}
                      >
                        Public Website
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        icon={<Users className="h-3.5 w-3.5" />}
                        onSelect={() => navigate('/account')}
                      >
                        Switch Account
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        icon={<RotateCcw className="h-3.5 w-3.5" />}
                        onSelect={resetDemoData}
                      >
                        Reset Demo Data
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        destructive
                        icon={<LogOut className="h-3.5 w-3.5" />}
                        shortcut="⇧⌘Q"
                        onSelect={signOut}
                      >
                        Sign Out
                      </DropdownMenuItem>
                    </DropdownMenuGroup>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
              <ThemeToggleButton variant="circle-blur" start="top-right" blur />
            </div>
          </header>

          {/* Main Content with Smoke Page Transition */}
          <main className="relative z-10 flex-1 p-4 sm:p-6 lg:p-8 max-w-[1280px] w-full mx-auto">
            <SmokePageTransition routeKey={cleanRoutePath}>
              {children}
            </SmokePageTransition>
          </main>
        </div>
      </div>
    </div>
  );
};
