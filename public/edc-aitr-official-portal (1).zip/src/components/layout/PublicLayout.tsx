import React, { useMemo } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  Award,
  Building2,
  ChevronDown,
  LayoutDashboard,
  LogOut,
  Ticket,
  Users,
} from 'lucide-react';
import { usePortal } from '../../context/PortalContext';
import { useTheme } from '../../context/ThemeContext';
import { EdcLogo } from '../ui/Primitives';
import { EdcMark } from '../ui/EdcMark';
import { GooeyNav } from '../ui/GooeyNav';
import { LiquidButton } from '../ui/LiquidButton';
import { ThemeToggleButton } from '../ui/ThemeToggle';
import { CursorGrid } from '../ui/CursorGrid';
import { SmokePageTransition } from '../ui/SmokePageTransition';
import { AnimatedContent } from '../ui/AnimatedContent';
import { CommandPaletteTrigger } from '../ui/CommandPalette';
import { Button } from '../ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';

const PUBLIC_NAV_LINKS = [
  { label: 'Home', href: '/' },
  { label: 'Events', href: '/events' },
  { label: 'About', href: '/about' },
  { label: 'Team', href: '/team' },
  { label: 'Contact', href: '/contact' },
];

export const PublicLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { path, navigate, currentUser, signOut } = usePortal();
  const { theme, isDark } = useTheme();
  const isStaff =
    currentUser?.role === 'core_team' ||
    currentUser?.role === 'advisor' ||
    currentUser?.role === 'director';

  const isLinkActive = (href: string) => {
    if (href === '/') return path === '/';
    return path === href || path.startsWith(`${href}/`);
  };

  const activeNavIndex = useMemo(() => {
    const idx = PUBLIC_NAV_LINKS.findIndex((link) => isLinkActive(link.href));
    return idx >= 0 ? idx : 0;
  }, [path]);

  const portalTarget = !currentUser
    ? '/account'
    : currentUser.role === 'alumni'
      ? '/alumni/directory'
      : currentUser.role === 'participant'
        ? '/portal'
        : '/workspace';

  return (
    <div className="relative min-h-screen flex flex-col overflow-x-clip bg-[var(--color-1-mood)] text-[var(--color-2-mood)] transition-colors duration-200">
      {/* Interactive WebGL2 CursorGrid Background across Public Web */}
      <div className="fixed inset-0 z-0 pointer-events-none no-print" aria-hidden="true">
        <CursorGrid
          cellSize={isDark ? 50 : 58}
          color="#C01E30"
          gridColor={isDark ? '#A1A1AA' : '#111318'}
          highlight="area"
          gridStyle="lines"
          radius={isDark ? 110 : 150}
          falloff="smooth"
          lineWidth={isDark ? 0.7 : 1}
          holdTime={isDark ? 80 : 360}
          fadeDuration={isDark ? 450 : 780}
          maxOpacity={isDark ? 0.28 : 0.48}
          fillOpacity={isDark ? 0.015 : 0.05}
          gridOpacity={isDark ? 0.035 : 0.06}
          spotlight={isDark ? 0.12 : 0.55}
          ambient={0}
          edgeFade={isDark ? 0.3 : 0.16}
          lightMode={!isDark}
          clickPulse
          intro
        />
      </div>

      {/* Unified Top Bar (Mobile + Desktop): Brand + WebGL2 GooeyNav + LiquidButton + Top-Right Theme Toggle */}
      <header className="sticky top-0 z-40 bg-white/90 dark:bg-[#101011]/92 backdrop-blur-md border-b border-[var(--border-hairline)] dark:border-[#303032]/75 no-print">
        <div className="max-w-[1200px] mx-auto px-3 sm:px-6 py-2.5 md:py-0 md:h-[70px] flex flex-wrap md:flex-nowrap items-center justify-between gap-y-2.5 gap-x-3 md:gap-6">
          {/* Zone 1: Official Brand Wordmark (auto switches light/dark logo) */}
          <button
            type="button"
            onClick={() => navigate('/')}
            className="order-1 flex items-center shrink-0 cursor-pointer rounded-[6px] focus-visible:outline-2"
            aria-label="EDC AITR Home"
          >
            <EdcLogo variant="auto" className="h-8 sm:h-10 md:h-11 w-auto" />
          </button>

          {/* Zone 2: WebGL2 GooeyNav — unified across mobile & desktop */}
          <div className="order-3 md:order-2 w-full md:w-auto flex items-center justify-center">
            <GooeyNav
              items={PUBLIC_NAV_LINKS}
              activeIndex={activeNavIndex}
              onChange={(_, item) => {
                if (item.href) navigate(item.href);
              }}
              theme={theme}
              color="#C01E30"
              activeTextColor="#ffffff"
              colors={isDark ? ['#C01E30', '#D4283B', '#9E1625'] : ['#C01E30', '#E11D48', '#9E1625']}
              size="sm"
              frame={true}
              particleCount={14}
              spread={46}
              animationTime={540}
              timeVariance={240}
              gooeyness={0.5}
              wobble={0.45}
              hoverEffect={true}
            />
          </div>

          {/* Zone 3: Compact Search Trigger + Account DropdownMenu / Sign In CTA + Dark Theme Toggle */}
          <div className="order-2 md:order-3 flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            <CommandPaletteTrigger />
            {currentUser ? (
              <DropdownMenu>
                <DropdownMenuTrigger
                  render={
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-fit px-2.5 sm:px-3 gap-1.5"
                    />
                  }
                >
                  <span className="h-5 w-5 rounded-full bg-[#C01E30] text-white text-[10px] font-semibold flex items-center justify-center shrink-0">
                    {currentUser.name
                      .split(' ')
                      .map((part) => part[0])
                      .slice(0, 2)
                      .join('')}
                  </span>
                  <span className="max-w-[90px] sm:max-w-[120px] truncate">
                    {currentUser.name.split(' ')[0]}
                  </span>
                  <ChevronDown className="h-3.5 w-3.5 text-[var(--ink-muted)]" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="min-w-[220px]">
                  <DropdownMenuGroup>
                    <DropdownMenuLabel>My Account</DropdownMenuLabel>
                    <DropdownMenuItem
                      icon={<Ticket className="h-3.5 w-3.5" />}
                      onSelect={() => navigate(portalTarget)}
                    >
                      Dashboard &amp; Tickets
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      icon={<Award className="h-3.5 w-3.5" />}
                      onSelect={() => navigate('/portal/certificates')}
                    >
                      My Certificates
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      icon={<Building2 className="h-3.5 w-3.5" />}
                      onSelect={() => navigate('/alumni/directory')}
                    >
                      Alumni Connect
                    </DropdownMenuItem>
                    {isStaff && (
                      <DropdownMenuItem
                        icon={<LayoutDashboard className="h-3.5 w-3.5" />}
                        onSelect={() => navigate('/workspace')}
                      >
                        Team Workspace
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem
                      icon={<Users className="h-3.5 w-3.5" />}
                      onSelect={() => navigate('/account')}
                    >
                      Switch Role / Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      destructive
                      icon={<LogOut className="h-3.5 w-3.5" />}
                      onSelect={signOut}
                    >
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuGroup>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <LiquidButton
                variant="crimson"
                size="sm"
                className="px-3 sm:px-4"
                onClick={() => navigate(portalTarget)}
              >
                Sign In
              </LiquidButton>
            )}
            <ThemeToggleButton variant="circle-blur" start="top-right" blur />
          </div>
        </div>
      </header>

      <main className="relative z-10 flex-1">
        <SmokePageTransition routeKey={path.split('?')[0].replace(/\/+$/, '') || '/'}>
          {children}
        </SmokePageTransition>
      </main>

      {/* Curved Architectural Obsidian Footer (Reference-Inspired, Calibrated to EDC AITR) */}
      <footer className="relative z-10 mt-24 sm:mt-28 px-3 sm:px-6 pb-5 sm:pb-7 no-print">
        <AnimatedContent distance={36} duration={0.7} threshold={0.08}>
        <div className="relative max-w-[1240px] mx-auto bg-[#121316] dark:bg-[#171719] text-[#F4F5F7] dark:text-[#F1F0ED] rounded-t-[34px] sm:rounded-t-[48px] rounded-b-[20px] border border-white/[0.08] dark:border-[#303032]">
          {/* Subtle Topographic Contour Linework Backdrop */}
          <div
            aria-hidden="true"
            className="absolute inset-0 overflow-hidden rounded-[inherit] pointer-events-none select-none"
          >
            <svg
              viewBox="0 0 1240 420"
              fill="none"
              preserveAspectRatio="xMidYMid slice"
              className="w-full h-full opacity-[0.07]"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M-40 90 C 90 140, 140 280, 260 260 C 380 240, 410 70, 560 95 C 710 120, 740 310, 910 295 C 1060 282, 1140 120, 1290 165"
                stroke="#FFFFFF"
                strokeWidth="1.25"
              />
              <path
                d="M-60 210 C 60 170, 170 360, 320 340 C 470 320, 510 160, 680 185 C 850 210, 890 385, 1080 350 C 1180 332, 1230 240, 1300 250"
                stroke="#FFFFFF"
                strokeWidth="1.25"
              />
              <path
                d="M120 -20 C 180 95, 290 125, 340 45 C 390 -35, 520 -10, 575 75 C 630 160, 780 135, 860 40 C 930 -45, 1080 35, 1130 140"
                stroke="#FFFFFF"
                strokeWidth="1.1"
              />
              <path
                d="M-30 330 C 110 300, 180 410, 310 390 C 440 370, 530 265, 675 305 C 820 345, 920 430, 1090 395"
                stroke="#FFFFFF"
                strokeWidth="1.1"
              />
            </svg>
          </div>

          {/* Centered Overlapping Official EDC Vector Monogram Crest */}
          <div className="relative z-10 flex justify-center -translate-y-1/2 -mb-9 sm:-mb-11">
            <button
              type="button"
              onClick={() => navigate('/')}
              aria-label="EDC AITR Home"
              className="group cursor-pointer rounded-2xl p-2 transition-transform duration-300 hover:scale-[1.03] focus-visible:outline-2"
            >
              <EdcMark className="w-24 sm:w-28 h-auto" />
            </button>
          </div>

          {/* Main 3-Column Footer Architecture */}
          <div className="relative z-10 px-6 sm:px-10 lg:px-14 pb-9 sm:pb-12 pt-1">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-6 items-end">
              {/* Center Brand Focal Anchor (First on mobile, Center on desktop) */}
              <div className="lg:col-span-4 lg:order-2 flex flex-col items-center text-center">
                <h2 className="font-display text-3xl sm:text-[2.35rem] font-semibold tracking-tight text-white leading-[1.04]">
                  EDC AITR
                  <span className="block text-2xl sm:text-[1.85rem] text-white/90 font-semibold mt-0.5">
                    Acropolis Indore
                  </span>
                </h2>
                <p className="mt-2.5 text-sm sm:text-[15px] italic text-white/70 font-serif tracking-wide">
                  Where student founders take flight
                </p>

                {/* Dual Reference-Style Pill CTAs */}
                <div className="mt-6 flex flex-wrap items-center justify-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => navigate('/events')}
                    className="inline-flex items-center gap-2.5 pl-4 pr-2 py-2 rounded-full bg-[#BD011F] hover:bg-[#9E1625] text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <span>Explore Events</span>
                    <span className="h-6 w-6 rounded-full bg-black/25 flex items-center justify-center">
                      <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate('/account/apply')}
                    className="inline-flex items-center gap-2.5 pl-4 pr-2 py-2 rounded-full bg-white/[0.05] hover:bg-white/[0.11] border border-white/15 text-white text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <span>Join EDC Cell</span>
                    <span className="h-6 w-6 rounded-full bg-[#BD011F] text-white flex items-center justify-center">
                      <ArrowRight className="h-3.5 w-3.5" />
                    </span>
                  </button>
                </div>
              </div>

              {/* Left Column: Contact + Channels + Institutional Backing */}
              <div className="lg:col-span-4 lg:order-1 space-y-6">
                <div className="grid grid-cols-2 gap-4 items-start">
                  <div className="space-y-2">
                    <h3 className="font-display text-base font-semibold text-white">Contact</h3>
                    <div className="text-xs text-white/70 leading-relaxed space-y-0.5">
                      <p>Bypass Road, Manglia Square,</p>
                      <p>Indore, MP 453771</p>
                      <p className="pt-1">
                        <a
                          href="mailto:edc@acropolis.in"
                          className="text-white/90 underline underline-offset-4 hover:text-[#F87171] transition-colors"
                        >
                          edc@acropolis.in
                        </a>
                      </p>
                    </div>
                  </div>

                  <div className="space-y-1.5 pt-1 sm:pt-7 text-xs">
                    <a
                      href="https://instagram.com/edc_acropolis"
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1.5 text-white/80 hover:text-white transition-colors"
                    >
                      <span>Instagram</span>
                      <ArrowUpRight className="h-3.5 w-3.5 text-[#E11D48] dark:text-[#C01E30]" />
                    </a>
                    <a
                      href="https://www.linkedin.com"
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1.5 text-white/80 hover:text-white transition-colors"
                    >
                      <span>LinkedIn</span>
                      <ArrowUpRight className="h-3.5 w-3.5 text-[#E11D48] dark:text-[#C01E30]" />
                    </a>
                    <button
                      type="button"
                      onClick={() => navigate('/events/fokus-x-e-summit-2026')}
                      className="flex items-center gap-1.5 text-white/80 hover:text-white transition-colors cursor-pointer"
                    >
                      <span>E-Summit 2026</span>
                      <ArrowUpRight className="h-3.5 w-3.5 text-[#E11D48] dark:text-[#C01E30]" />
                    </button>
                  </div>
                </div>

                {/* Bottom-Left Institutional Backing Strip */}
                <div className="pt-1 flex flex-wrap items-center gap-2.5 text-[11px] text-white/65">
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-[#BD011F] text-white font-mono-data font-semibold text-[10px]">
                    AIIH
                  </span>
                  <span>Backed by AIIH Foundation · IIC (MoE Innovation Cell)</span>
                </div>
              </div>

              {/* Right Column: Quick Links + High-Contrast Editorial Legal Bar */}
              <div className="lg:col-span-4 lg:order-3 flex flex-col lg:items-end justify-between space-y-6">
                <div className="w-full lg:max-w-[290px] space-y-2.5">
                  <h3 className="font-display text-base font-semibold text-white">Quick Links</h3>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 text-xs text-white/75">
                    <button
                      type="button"
                      onClick={() => navigate('/')}
                      className="text-left hover:text-white transition-colors cursor-pointer"
                    >
                      Home
                    </button>
                    <button
                      type="button"
                      onClick={() => navigate('/events')}
                      className="text-left hover:text-white transition-colors cursor-pointer"
                    >
                      Live Events
                    </button>
                    <button
                      type="button"
                      onClick={() => navigate('/about')}
                      className="text-left hover:text-white transition-colors cursor-pointer"
                    >
                      About EDC
                    </button>
                    <button
                      type="button"
                      onClick={() => navigate('/portal')}
                      className="text-left hover:text-white transition-colors cursor-pointer"
                    >
                      Participant Portal
                    </button>
                    <button
                      type="button"
                      onClick={() => navigate('/team')}
                      className="text-left hover:text-white transition-colors cursor-pointer"
                    >
                      Team Directory
                    </button>
                    <button
                      type="button"
                      onClick={() => navigate('/alumni/directory')}
                      className="text-left hover:text-white transition-colors cursor-pointer"
                    >
                      Alumni Connect
                    </button>
                  </div>
                </div>

                {/* High-Contrast Editorial Legal Bar (Reference Signature Detail) */}
                <div className="inline-flex flex-wrap items-center gap-x-4 gap-y-1 bg-[#F4F5F7] dark:bg-[#202022] text-[#111318] dark:text-[#F1F0ED] dark:border dark:border-[#303032] rounded-[8px] px-3.5 py-2 text-[11px] font-medium self-start lg:self-end">
                  <button
                    type="button"
                    onClick={() => navigate('/contact')}
                    className="hover:text-[#BD011F] dark:hover:text-[#E67C87] transition-colors cursor-pointer"
                  >
                    Contact
                  </button>
                  <button
                    type="button"
                    onClick={() => navigate('/workspace')}
                    className="hover:text-[#BD011F] dark:hover:text-[#E67C87] transition-colors cursor-pointer"
                  >
                    Workspace
                  </button>
                  <span className="font-mono-data text-[#343435] dark:text-[#A4A4A8]">©2026 EDC AITR</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        </AnimatedContent>
      </footer>
    </div>
  );
};
