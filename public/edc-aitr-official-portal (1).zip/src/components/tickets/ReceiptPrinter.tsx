import React, {
  type ComponentPropsWithoutRef,
  createContext,
  type ReactNode,
  useContext,
  useEffect,
  useState,
} from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Loader2,
  Lock,
  RotateCw,
  ShieldCheck,
} from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { EventItem, Registration } from '../../types/portal';
import { EdcLogo, QrCodeSvg, StatusBadge } from '../ui/Primitives';
import { EdcMark } from '../ui/EdcMark';

export type ReceiptPrinterStage = 'processing' | 'printing' | 'complete';
export type ReceiptFeedMotion = 'smooth' | 'stepped';

function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(' ');
}

export type ReceiptPrinterRootProps = Omit<
  ComponentPropsWithoutRef<'section'>,
  'children'
> & {
  /** Disables all stage transitions when false. */
  animate?: boolean;
  children: ReactNode;
  /** Controls whether the paper feeds continuously or one line at a time. */
  feedMotion?: ReceiptFeedMotion;
  /** Current state of the printer. */
  stage: ReceiptPrinterStage;
  /** Indicates whether registration is verified & confirmed (gates QR reveal). */
  isVerified?: boolean;
};

export type ReceiptPrinterMachineProps = ComponentPropsWithoutRef<'div'>;
export type ReceiptPrinterHeaderProps = ComponentPropsWithoutRef<'div'>;
export type ReceiptPrinterScreenProps = ComponentPropsWithoutRef<'div'>;
export type ReceiptPrinterOutputProps = ComponentPropsWithoutRef<'div'>;
export type ReceiptPrinterPaperProps = ComponentPropsWithoutRef<'article'>;

export type ReceiptPrinterStatusProps = Omit<
  ComponentPropsWithoutRef<'div'>,
  'children'
> & {
  /** Custom status content. Defaults to a label derived from the current stage. */
  children?: ReactNode;
  tone?: 'default' | 'warning' | 'error';
};

type ReceiptPrinterContextValue = {
  animate: boolean;
  feedMotion: ReceiptFeedMotion;
  isVerified: boolean;
  shouldMove: boolean;
  stage: ReceiptPrinterStage;
};

const ReceiptPrinterContext = createContext<ReceiptPrinterContextValue | null>(
  null
);

const easeOut = [0.23, 1, 0.32, 1] as const;
const easeInOut = [0.77, 0, 0.175, 1] as const;

const receiptToothCount = 36;
const receiptToothDepth = 5;
const receiptToothPoints = Array.from(
  { length: receiptToothCount * 2 },
  (_, index) => {
    const x = 100 - ((index + 1) * 100) / (receiptToothCount * 2);
    const y = index % 2 === 0 ? '100%' : `calc(100% - ${receiptToothDepth}px)`;
    return `${x}% ${y}`;
  }
).join(', ');

const receiptClipPath = `polygon(0 0, 100% 0, 100% calc(100% - ${receiptToothDepth}px), ${receiptToothPoints})`;

const printingTransformKeyframes = [
  'translateY(calc(-100% + 2px))',
  'translateY(-91%)',
  'translateY(-91%)',
  'translateY(-81%)',
  'translateY(-81%)',
  'translateY(-70%)',
  'translateY(-70%)',
  'translateY(-58%)',
  'translateY(-58%)',
  'translateY(-45%)',
  'translateY(-45%)',
  'translateY(-32%)',
  'translateY(-32%)',
  'translateY(-20%)',
  'translateY(-20%)',
  'translateY(-10%)',
  'translateY(-10%)',
  'translateY(-3%)',
  'translateY(-3%)',
  'translateY(0%)',
];

const printingKeyframeTimes = [
  0, 0.075, 0.105, 0.18, 0.21, 0.285, 0.315, 0.39, 0.42, 0.495, 0.525, 0.6,
  0.63, 0.705, 0.735, 0.81, 0.84, 0.915, 0.945, 1,
];

const statusLabels: Record<ReceiptPrinterStage, ReactNode> = {
  processing: 'Verifying event registration',
  printing: 'Printing official delegate pass',
  complete: 'Pass issued · QR ready for check-in',
};

const machineClassName =
  'relative isolate w-full overflow-hidden rounded-[9px] border border-[#030405] dark:border-white/15 bg-[#111318] p-3.5 pb-9 text-white';

function useReceiptPrinter(component: string) {
  const context = useContext(ReceiptPrinterContext);
  if (!context) {
    throw new Error(`${component} must be used inside ReceiptPrinter.Root.`);
  }
  return context;
}

function ReceiptPrinterRoot({
  'aria-label': ariaLabel = 'EDC AITR Event Ticket Printer',
  animate = true,
  children,
  className,
  feedMotion = 'stepped',
  isVerified = false,
  stage,
  ...props
}: ReceiptPrinterRootProps) {
  const shouldReduceMotion = useReducedMotion();
  const context: ReceiptPrinterContextValue = {
    animate,
    feedMotion,
    isVerified,
    shouldMove: animate && !shouldReduceMotion,
    stage,
  };

  return (
    <ReceiptPrinterContext.Provider value={context}>
      <section
        aria-label={ariaLabel}
        className={cn(
          'relative isolate flex w-full max-w-[420px] flex-col items-center',
          className
        )}
        data-stage={stage}
        {...props}
      >
        {children}
      </section>
    </ReceiptPrinterContext.Provider>
  );
}

function ReceiptPrinterMachine({
  children,
  className,
  ...props
}: ReceiptPrinterMachineProps) {
  return (
    <div className={cn(machineClassName, className)} {...props}>
      {children}
      {/* Thermal paper dispensing slot */}
      <div
        aria-hidden="true"
        className="absolute inset-x-5 bottom-3 z-40 h-2.5 rounded-[4px] border border-white/15 bg-[#030405]"
      />
    </div>
  );
}

function ReceiptPrinterHeader({
  children,
  className,
  ...props
}: ReceiptPrinterHeaderProps) {
  return (
    <div
      className={cn(
        'relative z-10 flex min-h-11 items-center justify-between gap-3 pb-3',
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
}

function ReceiptPrinterScreen({
  children,
  className,
  ...props
}: ReceiptPrinterScreenProps) {
  return (
    <div
      className={cn(
        'relative z-10 isolate overflow-hidden rounded-[6px] border border-white/12 bg-[#030405] px-4 py-3.5 text-white',
        className
      )}
      {...props}
    >
      <div className="relative z-10">{children}</div>
    </div>
  );
}

function StatusIndicator({
  animate,
  move,
  stage,
  isVerified,
  tone = 'default',
}: {
  animate: boolean;
  move: boolean;
  stage: ReceiptPrinterStage;
  isVerified: boolean;
  tone?: 'default' | 'warning' | 'error';
}) {
  const isComplete = stage === 'complete' && isVerified;

  return (
    <span
      aria-hidden="true"
      className="relative grid size-5 shrink-0 place-items-center"
    >
      <AnimatePresence initial={false} mode="sync">
        {!isVerified ? (
          <motion.span
            key="locked"
            animate={{ opacity: 1, transform: 'scale(1)' }}
            exit={{ opacity: 0, transform: move ? 'scale(0.95)' : 'scale(1)' }}
            initial={{ opacity: animate ? 0 : 1, transform: move ? 'scale(0.95)' : 'scale(1)' }}
            transition={{ duration: animate ? 0.16 : 0, ease: easeOut }}
            className={cn(
              'col-start-1 row-start-1 grid place-items-center',
              tone === 'error' ? 'text-[#C01E30]' : 'text-[#F59E0B]'
            )}
          >
            {tone === 'error' ? (
              <AlertCircle className="h-4 w-4" strokeWidth={2} />
            ) : (
              <Clock className="h-4 w-4" strokeWidth={2} />
            )}
          </motion.span>
        ) : isComplete ? (
          <motion.span
            key="complete"
            animate={{ opacity: 1, transform: 'scale(1)' }}
            className="col-start-1 row-start-1 grid place-items-center text-[#22C55E]"
            exit={{
              opacity: animate ? 0 : 1,
              transform: move ? 'scale(0.96)' : 'scale(1)',
            }}
            initial={{
              opacity: animate ? 0 : 1,
              transform: move ? 'scale(0.94)' : 'scale(1)',
            }}
            transition={{ duration: animate ? 0.16 : 0, ease: easeOut }}
          >
            <CheckCircle2 className="h-4 w-4" strokeWidth={2.2} />
          </motion.span>
        ) : (
          <motion.span
            key="working"
            animate={{ opacity: 1, transform: 'scale(1)' }}
            className="col-start-1 row-start-1 grid place-items-center text-white/80"
            exit={{
              opacity: animate ? 0 : 1,
              transform: move ? 'scale(0.96)' : 'scale(1)',
            }}
            initial={{
              opacity: animate ? 0 : 1,
              transform: move ? 'scale(0.94)' : 'scale(1)',
            }}
            transition={{ duration: animate ? 0.16 : 0, ease: easeOut }}
          >
            <Loader2
              className={cn(
                'h-4 w-4',
                animate && 'animate-spin motion-reduce:animate-none'
              )}
              strokeWidth={2.2}
            />
          </motion.span>
        )}
      </AnimatePresence>
    </span>
  );
}

function ReceiptPrinterStatus({
  children,
  className,
  tone = 'default',
  ...props
}: ReceiptPrinterStatusProps) {
  const { animate, isVerified, shouldMove, stage } = useReceiptPrinter(
    'ReceiptPrinter.Status'
  );

  return (
    <div
      className={cn('flex min-w-0 items-center gap-2.5', className)}
      {...props}
    >
      <StatusIndicator
        animate={animate}
        isVerified={isVerified}
        move={shouldMove}
        stage={stage}
        tone={tone}
      />
      <div
        aria-live="polite"
        className="grid min-w-0 flex-1 items-center"
        role="status"
      >
        <AnimatePresence initial={false} mode="sync">
          <motion.div
            animate={{ opacity: 1, transform: 'translateY(0px)' }}
            className="col-start-1 row-start-1 truncate font-mono-data text-xs font-medium text-white/90 leading-snug"
            exit={{
              opacity: animate ? 0 : 1,
              transform: shouldMove ? 'translateY(-4px)' : 'translateY(0px)',
            }}
            initial={{
              opacity: animate ? 0 : 1,
              transform: shouldMove ? 'translateY(4px)' : 'translateY(0px)',
            }}
            key={`${stage}-${isVerified}`}
            transition={{ duration: animate ? 0.18 : 0, ease: easeOut }}
          >
            {children ?? statusLabels[stage]}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

function ReceiptPrinterPaper({
  children,
  className,
  style,
  ...props
}: ReceiptPrinterPaperProps) {
  return (
    <article
      className={cn(
        'relative z-10 w-full bg-white border-x border-t border-[rgba(3,4,5,0.14)] px-5 pt-6 pb-8 text-[#030405] print-only-surface',
        className
      )}
      style={{ clipPath: receiptClipPath, ...style }}
      {...props}
    >
      {children}
    </article>
  );
}

function ReceiptPrinterOutput({
  children,
  className,
  ...props
}: ReceiptPrinterOutputProps) {
  const { animate, feedMotion, isVerified, shouldMove, stage } =
    useReceiptPrinter('ReceiptPrinter.Output');

  // Strict security rule: paper with QR code does not dispense unless registration is verified/confirmed
  const isReceiptVisible = isVerified && stage !== 'processing';
  const shouldUseSteppedFeed =
    feedMotion === 'stepped' && stage === 'printing' && shouldMove;

  return (
    <div
      className={cn(
        'relative z-30 -mt-3.5 w-[calc(100%-2.25rem)] max-w-full overflow-hidden px-1 pb-2',
        isReceiptVisible ? 'min-h-[460px]' : 'h-0',
        className
      )}
      {...props}
    >
      {isReceiptVisible ? (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-1 top-0 z-20 h-1.5 bg-[#030405]/15"
        />
      ) : null}

      <motion.div
        animate={{
          opacity: isReceiptVisible ? 1 : 0,
          transform:
            stage === 'printing' && shouldMove
              ? shouldUseSteppedFeed
                ? printingTransformKeyframes
                : 'translateY(0%)'
              : isReceiptVisible || !shouldMove
                ? 'translateY(0%)'
                : 'translateY(calc(-100% + 2px))',
        }}
        aria-hidden={!isReceiptVisible || stage !== 'complete'}
        className="relative isolate"
        initial={false}
        transition={{
          opacity: { duration: animate ? 0.16 : 0, ease: easeOut },
          transform: {
            duration: shouldMove ? 1.75 : 0,
            ease: shouldUseSteppedFeed ? 'linear' : easeInOut,
            times: shouldUseSteppedFeed ? printingKeyframeTimes : undefined,
          },
        }}
      >
        {isVerified ? children : null}
      </motion.div>
    </div>
  );
}

export const ReceiptPrinter = {
  Header: ReceiptPrinterHeader,
  Machine: ReceiptPrinterMachine,
  Output: ReceiptPrinterOutput,
  Paper: ReceiptPrinterPaper,
  Root: ReceiptPrinterRoot,
  Screen: ReceiptPrinterScreen,
  Status: ReceiptPrinterStatus,
};

/**
 * High-level EDC AITR Event Ticket Thermal Printer wrapper.
 * Strictly hides/unmounts the QR code until the attendee is successfully registered
 * (`paymentStatus === 'Free' || paymentStatus === 'Verified'`).
 */
export const EventTicketReceipt: React.FC<{
  registration: Registration;
  event: EventItem;
}> = ({ registration, event }) => {
  const isSuccessfullyRegistered =
    registration.paymentStatus === 'Free' ||
    registration.paymentStatus === 'Verified';
  const isRejected = registration.paymentStatus === 'Rejected';

  const [feedMotion, setFeedMotion] = useState<ReceiptFeedMotion>('stepped');
  const [stage, setStage] = useState<ReceiptPrinterStage>(
    isSuccessfullyRegistered ? 'processing' : 'processing'
  );
  const [replaySeed, setReplaySeed] = useState(0);

  useEffect(() => {
    if (!isSuccessfullyRegistered) {
      setStage('processing');
      return;
    }

    setStage('processing');
    const t1 = window.setTimeout(() => {
      setStage('printing');
    }, 360);
    const t2 = window.setTimeout(() => {
      setStage('complete');
    }, 2180);

    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [registration.id, registration.paymentStatus, isSuccessfullyRegistered, replaySeed]);

  const statusText = !isSuccessfullyRegistered
    ? isRejected
      ? 'Payment rejected · Pass withheld'
      : 'Pending RD UTR verification · Pass locked'
    : stage === 'processing'
      ? 'Confirming delegate registration...'
      : stage === 'printing'
        ? 'Printing official delegate pass...'
        : registration.checkInStatus === 'Checked In'
          ? `Checked in · ${registration.checkedInAt}`
          : 'Pass issued · QR ready for RD check-in';

  return (
    <div className="flex flex-col items-center w-full space-y-4">
      <ReceiptPrinter.Root
        stage={stage}
        feedMotion={feedMotion}
        isVerified={isSuccessfullyRegistered}
        className="w-full"
      >
        <ReceiptPrinter.Machine className="no-print">
          <ReceiptPrinter.Header>
            <div className="inline-flex items-center gap-2">
              <EdcMark className="h-5 w-auto" />
              <span className="font-display text-xs font-semibold tracking-tight text-white">
                EDC AITR
              </span>
            </div>
            <span className="font-mono-data text-[10px] text-white/65 border border-white/15 rounded-[4px] px-2 py-0.5">
              RD-PASS UNIT
            </span>
          </ReceiptPrinter.Header>

          <ReceiptPrinter.Screen>
            <ReceiptPrinter.Status
              tone={isRejected ? 'error' : !isSuccessfullyRegistered ? 'warning' : 'default'}
            >
              {statusText}
            </ReceiptPrinter.Status>
            <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between text-[11px] font-mono-data text-white/60">
              <span>{event.category}</span>
              <span>
                {isSuccessfullyRegistered
                  ? registration.ticketToken
                  : 'QR LOCKED'}
              </span>
            </div>
          </ReceiptPrinter.Screen>
        </ReceiptPrinter.Machine>

        {/* Dispensed Thermal Ticket Paper — ONLY mounts QR when successfully registered */}
        <ReceiptPrinter.Output key={replaySeed}>
          {isSuccessfullyRegistered ? (
            <ReceiptPrinter.Paper>
              <div className="space-y-4">
                {/* Official Light Logo & Header */}
                <div className="flex items-start justify-between gap-3 pb-3.5 border-b border-dashed border-[rgba(3,4,5,0.2)]">
                  <EdcLogo variant="light" className="h-8 w-auto" />
                  <div className="text-right font-mono-data">
                    <p className="text-[10px] font-semibold text-[#C01E30]">
                      ADMIT ONE
                    </p>
                    <p className="text-[10px] text-[#636468] mt-0.5">
                      {event.dateLabel}
                    </p>
                  </div>
                </div>

                {/* Event Title & Slot */}
                <div className="space-y-1">
                  <p className="font-mono-data text-[10px] text-[#636468]">
                    {event.category} · AITR INDORE
                  </p>
                  <h2 className="font-display text-lg font-semibold text-[#030405] leading-snug">
                    {event.title}
                  </h2>
                  {registration.trackName && (
                    <p className="font-mono-data text-[11px] font-semibold uppercase tracking-wide text-[#C01E30]">
                      {registration.trackName}
                    </p>
                  )}
                  <p className="text-xs text-[#343435]">{registration.seatSlot}</p>
                </div>

                {/* Attendee Ledger Lines */}
                <dl className="py-3 border-y border-dashed border-[rgba(3,4,5,0.2)] space-y-2 text-xs font-mono-data">
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-[#636468]">DELEGATE</dt>
                    <dd className="font-semibold text-[#030405] text-right truncate">
                      {registration.attendeeName}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-[#636468]">CATEGORY</dt>
                    <dd className="font-semibold text-[#030405] text-right truncate">
                      {registration.trackName || 'General Attendee'}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-[#636468]">ENROLLMENT</dt>
                    <dd className="text-[#030405]">{registration.enrollmentNo}</dd>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-[#636468]">FEE</dt>
                    <dd className="text-[#030405]">
                      {registration.pricingSnapshot?.type === 'paid' &&
                      registration.pricingSnapshot.amountInr > 0
                        ? `₹${registration.pricingSnapshot.amountInr}`
                        : registration.amountInr && registration.amountInr > 0
                          ? `₹${registration.amountInr}`
                          : registration.paymentStatus === 'Free'
                            ? 'FREE'
                            : event.isPaid
                              ? `₹${event.feeInr}`
                              : 'FREE'}
                    </dd>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <dt className="text-[#636468]">STATUS</dt>
                    <dd className="text-[#15803D] font-semibold">
                      {registration.paymentStatus === 'Free'
                        ? 'CONFIRMED (FREE)'
                        : 'PAYMENT VERIFIED'}
                    </dd>
                  </div>
                  {registration.utrNumber && (
                    <div className="flex items-center justify-between gap-2">
                      <dt className="text-[#636468]">UTR REF</dt>
                      <dd className="text-[#030405]">{registration.utrNumber}</dd>
                    </div>
                  )}
                </dl>

                {/* Scannable QR Code — Strictly rendered ONLY after confirmed registration */}
                <div className="pt-1 flex flex-col items-center text-center space-y-2.5">
                  <QrCodeSvg
                    value={registration.ticketToken}
                    size={172}
                    label={`Official Entry QR Code ${registration.ticketToken}`}
                  />
                  <div>
                    <p className="font-mono-data text-xs font-semibold text-[#030405] tracking-wide">
                      {registration.ticketToken}
                    </p>
                    <p className="text-[11px] text-[#636468] mt-0.5">
                      Scan at RD Check-in Console · Carry Institute ID
                    </p>
                  </div>
                  {registration.checkInStatus === 'Checked In' && (
                    <StatusBadge
                      label={`Checked In · ${registration.checkedInAt}`}
                      tone="green"
                    />
                  )}
                </div>

                <div className="pt-3 border-t border-dashed border-[rgba(3,4,5,0.2)] flex items-center justify-between text-[10px] font-mono-data text-[#636468]">
                  <span>ISSUED {registration.registeredAt}</span>
                  <span>EDC AITR · AIIH</span>
                </div>
              </div>
            </ReceiptPrinter.Paper>
          ) : null}
        </ReceiptPrinter.Output>
      </ReceiptPrinter.Root>

      {/* Locked State Card when NOT yet successfully registered (No QR mounted anywhere) */}
      {!isSuccessfullyRegistered && (
        <div className="w-full max-w-[420px] studio-card p-5 space-y-3 text-center">
          <div className="mx-auto h-10 w-10 rounded-[9px] bg-[var(--color-1-mood)] border border-[var(--border-strong)] flex items-center justify-center text-[var(--color-2-mood)]">
            <Lock className="h-4 w-4 text-[#C01E30] dark:text-[#F87171]" strokeWidth={1.8} />
          </div>
          <div className="space-y-1">
            <p className="text-sm font-display font-semibold text-[var(--color-2-mood)]">
              {isRejected
                ? 'Registration Payment Rejected'
                : 'Entry QR Code Withheld Until Confirmed'}
            </p>
            <p className="text-xs text-[var(--ink-muted)] leading-relaxed">
              {isRejected
                ? 'The submitted UPI UTR reference could not be matched. Please contact the RD desk or re-register with a valid receipt.'
                : `Your UTR reference (${registration.utrNumber ?? 'submitted'}) is queued with the RD team. Your thermal pass and scannable QR code will print automatically once verified.`}
            </p>
          </div>
          <div className="pt-1 flex justify-center">
            <StatusBadge
              label={registration.paymentStatus}
              tone={isRejected ? 'crimson' : 'amber'}
            />
          </div>
        </div>
      )}

      {/* Printer Motion Controls (only shown for confirmed passes) */}
      {isSuccessfullyRegistered && (
        <div className="w-full max-w-[420px] flex flex-wrap items-center justify-between gap-2 px-1 no-print">
          <div className="inline-flex items-center gap-1 p-0.5 bg-[var(--surface-subtle)] border border-[var(--border-hairline)] rounded-[9px]">
            <button
              type="button"
              onClick={() => {
                setFeedMotion('stepped');
                setReplaySeed((n) => n + 1);
              }}
              className={cn(
                'px-2.5 py-1 text-[11px] font-medium rounded-[7px] transition-colors cursor-pointer',
                feedMotion === 'stepped'
                  ? 'bg-[var(--surface)] text-[var(--color-2-mood)] border border-[var(--border-hairline)]'
                  : 'text-[var(--ink-muted)] hover:text-[var(--color-2-mood)]'
              )}
            >
              Stepped Feed
            </button>
            <button
              type="button"
              onClick={() => {
                setFeedMotion('smooth');
                setReplaySeed((n) => n + 1);
              }}
              className={cn(
                'px-2.5 py-1 text-[11px] font-medium rounded-[7px] transition-colors cursor-pointer',
                feedMotion === 'smooth'
                  ? 'bg-[var(--surface)] text-[var(--color-2-mood)] border border-[var(--border-hairline)]'
                  : 'text-[var(--ink-muted)] hover:text-[var(--color-2-mood)]'
              )}
            >
              Smooth Feed
            </button>
          </div>

          <button
            type="button"
            onClick={() => setReplaySeed((n) => n + 1)}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-[var(--ink-secondary)] hover:text-[#C01E30] dark:hover:text-[#F87171] cursor-pointer"
          >
            <RotateCw className="h-3.5 w-3.5" />
            <span>Replay Print</span>
          </button>
        </div>
      )}

      {isSuccessfullyRegistered && (
        <div className="inline-flex items-center gap-1.5 text-[11px] text-[#15803D] dark:text-emerald-400 font-medium no-print">
          <ShieldCheck className="h-3.5 w-3.5" />
          <span>Verified EDC AITR Registration · QR Unlocked</span>
        </div>
      )}
    </div>
  );
};
