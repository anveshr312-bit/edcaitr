import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowUpRight,
  Award,
  Calendar,
  Download,
  FileText,
  Lock,
  MapPin,
  Megaphone,
  Paperclip,
  Printer,
  ShieldCheck,
  Ticket,
  UserPlus,
} from 'lucide-react';
import { usePortal } from '../../context/PortalContext';
import { AnnouncementCategory, Certificate, UploadedFileRef } from '../../types/portal';
import {
  EdcLogo,
  ModalDialog,
  QrCodeSvg,
  StatusBadge,
  StudioButton,
} from '../../components/ui/Primitives';
import { EventTicketReceipt } from '../../components/tickets/ReceiptPrinter';
import { AnimatedContent } from '../../components/ui/AnimatedContent';
import { TiltGlareCard } from '../../components/ui/TiltGlareCard';
import { formatRegistrationAnswer } from '../../utils/eventTracks';
import { downloadStoredDocument, formatBytes } from '../../utils/mediaStorage';

export const ParticipantDashboardPage: React.FC = () => {
  const { currentUser, registrations, events, certificates, announcements, navigate } = usePortal();

  const myRegistrations = useMemo(() => {
    if (!currentUser) return registrations.slice(0, 4);
    const mine = registrations.filter(
      (r) => r.userId === currentUser.id || r.attendeeEmail.toLowerCase() === currentUser.email.toLowerCase()
    );
    return mine.length > 0 ? mine : registrations.slice(0, 3);
  }, [registrations, currentUser]);

  const quickActions = [
    {
      title: 'My Tickets & QR Codes',
      detail: `${myRegistrations.length} active pass${myRegistrations.length === 1 ? '' : 'es'}`,
      icon: Ticket,
      onClick: () =>
        navigate(
          myRegistrations[0] ? `/portal/registrations/${myRegistrations[0].id}` : '/events'
        ),
    },
    {
      title: 'Browse Live Events',
      detail: `${events.filter((e) => e.status === 'Published').length} open programs`,
      icon: Calendar,
      onClick: () => navigate('/events'),
    },
    {
      title: 'Submit Membership Application',
      detail: 'Join one of 12 teams',
      icon: UserPlus,
      onClick: () => navigate('/account/apply'),
    },
    {
      title: 'Announcements Stream',
      detail: `${announcements.length} official notices`,
      icon: Megaphone,
      onClick: () => navigate('/portal/announcements'),
    },
    {
      title: 'Issued Certificates',
      detail: `${certificates.length} verified credentials`,
      icon: Award,
      onClick: () => navigate('/portal/certificates'),
    },
  ];

  const getStatusDisplay = (paymentStatus: string, checkInStatus: string) => {
    if (checkInStatus === 'Checked In') {
      return { label: 'Checked In', tone: 'green' as const };
    }
    if (paymentStatus === 'Pending Payment Verification') {
      return { label: 'Pending Payment Verification', tone: 'amber' as const };
    }
    if (paymentStatus === 'Rejected') {
      return { label: 'Payment Rejected', tone: 'crimson' as const };
    }
    return { label: 'Registered', tone: 'crimson' as const };
  };

  return (
    <div className="space-y-8">
      <AnimatedContent
        trigger="mount"
        distance={24}
        duration={0.6}
        className="flex flex-col sm:flex-row sm:items-end justify-between gap-4"
      >
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Participant Portal</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Welcome back, {currentUser?.name ?? 'Participant'}
          </h1>
          <p className="text-sm text-[var(--ink-muted)] mt-1">
            Access your event passes, UPI verification status, campus broadcasts, and signed certificates.
          </p>
        </div>
        <StudioButton variant="primary" size="sm" onClick={() => navigate('/events')}>
          <span>Register for an Event</span>
        </StudioButton>
      </AnimatedContent>

      {/* Quick Action Grid */}
      <AnimatedContent
        trigger="mount"
        distance={32}
        duration={0.65}
        stagger={0.06}
        delay={0.05}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5"
      >
        {quickActions.map((action) => {
          const Icon = action.icon;
          return (
            <button
              key={action.title}
              type="button"
              onClick={action.onClick}
              className="studio-card p-4 text-left flex flex-col justify-between gap-4 hover:border-[#C01E30] transition-colors cursor-pointer group"
            >
              <div className="h-9 w-9 rounded-[9px] bg-[var(--surface-subtle)] border border-[var(--border-hairline)] flex items-center justify-center text-[var(--color-2-mood)] group-hover:bg-[var(--accent-soft)] group-hover:text-[#C01E30] transition-colors">
                <Icon className="h-4 w-4" strokeWidth={1.75} />
              </div>
              <div>
                <p className="text-sm font-semibold text-[var(--color-2-mood)] leading-snug">{action.title}</p>
                <p className="text-xs text-[var(--ink-muted)] mt-1">{action.detail}</p>
              </div>
            </button>
          );
        })}
      </AnimatedContent>

      {/* Active Registrations List */}
      <AnimatedContent trigger="mount" distance={36} duration={0.7} delay={0.14}>
        <section className="studio-card overflow-hidden">
        <div className="px-6 py-4 border-b border-[var(--border-hairline)] flex items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
              Active Event Registrations
            </h2>
            <p className="text-xs text-[var(--ink-muted)]">
              Open any pass to view your scannable QR code, UTR status, or printable receipt.
            </p>
          </div>
          <span className="font-mono-data text-xs text-[var(--ink-muted)]">
            {myRegistrations.length} total
          </span>
        </div>

        <div className="divide-y divide-[var(--border-hairline)]">
          {myRegistrations.map((reg) => {
            const evt = events.find((e) => e.id === reg.eventId);
            const badge = getStatusDisplay(reg.paymentStatus, reg.checkInStatus);
            const isConfirmed =
              reg.paymentStatus === 'Free' || reg.paymentStatus === 'Verified';
            return (
              <div
                key={reg.id}
                className="px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-[var(--surface-subtle)] transition-colors"
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[var(--ink-muted)]">
                    <span className="font-mono-data font-medium text-[var(--color-2-mood)]">
                      {isConfirmed ? reg.ticketToken : 'QR Locked · Pending Verification'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{evt?.dateLabel ?? 'Upcoming'}</span>
                    {reg.utrNumber && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono-data">UTR {reg.utrNumber}</span>
                      </>
                    )}
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-base font-display font-semibold text-[var(--color-2-mood)] truncate">
                      {evt?.title ?? 'EDC AITR Event'}
                    </p>
                    {reg.trackName && (
                      <StatusBadge label={reg.trackName} tone="neutral" />
                    )}
                  </div>
                  <p className="text-xs text-[var(--ink-muted)]">{reg.seatSlot}</p>
                </div>

                <div className="flex flex-wrap items-center gap-3 shrink-0">
                  <StatusBadge label={badge.label} tone={badge.tone} />
                  <StudioButton
                    variant="secondary"
                    size="sm"
                    onClick={() => navigate(`/portal/registrations/${reg.id}`)}
                  >
                    <span>{isConfirmed ? 'Print / Open Pass' : 'View Status'}</span>
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </StudioButton>
                </div>
              </div>
            );
          })}
        </div>
        </section>
      </AnimatedContent>
    </div>
  );
};

export const TicketDetailPage: React.FC<{ registrationId: string }> = ({ registrationId }) => {
  const { registrations, events, currentUser, navigate, pushToast } = usePortal();
  const reg = registrations.find((r) => r.id === registrationId) ?? registrations[0];
  const evt = events.find((e) => e.id === reg?.eventId);

  if (!reg || !evt) {
    return (
      <div className="studio-card p-8 text-center space-y-3">
        <p className="text-base font-semibold text-[var(--color-2-mood)]">Ticket record not found</p>
        <StudioButton variant="secondary" size="sm" onClick={() => navigate('/portal')}>
          Return to Dashboard
        </StudioButton>
      </div>
    );
  }

  const isSuccessfullyRegistered =
    reg.paymentStatus === 'Free' || reg.paymentStatus === 'Verified';
  const isStaff =
    currentUser?.role === 'core_team' ||
    currentUser?.role === 'advisor' ||
    currentUser?.role === 'director';

  const paymentTone =
    reg.paymentStatus === 'Verified' || reg.paymentStatus === 'Free'
      ? 'green'
      : reg.paymentStatus === 'Pending Payment Verification'
        ? 'amber'
        : 'crimson';

  const handlePrintOrPdf = (mode: 'pdf' | 'print') => {
    if (!isSuccessfullyRegistered) return;
    pushToast(
      mode === 'pdf' ? 'Preparing PDF Ticket' : 'Opening Print Dialog',
      `Thermal pass ${reg.ticketToken} formatted for print/PDF export.`
    );
    window.setTimeout(() => window.print(), 180);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 no-print">
        <button
          type="button"
          onClick={() => navigate('/portal')}
          className="inline-flex items-center gap-1.5 text-sm font-medium text-[var(--ink-secondary)] hover:text-[#C01E30] cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Registrations</span>
        </button>

        <div className="flex items-center gap-2.5">
          <StudioButton
            variant="secondary"
            size="sm"
            disabled={!isSuccessfullyRegistered}
            onClick={() => handlePrintOrPdf('print')}
          >
            <Printer className="h-4 w-4" />
            <span>Print Pass</span>
          </StudioButton>
          <StudioButton
            variant="primary"
            size="sm"
            disabled={!isSuccessfullyRegistered}
            onClick={() => handlePrintOrPdf('pdf')}
          >
            <Download className="h-4 w-4" />
            <span>Download PDF Ticket</span>
          </StudioButton>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left/Center: Animated Thermal ReceiptPrinter Ticket Dispenser */}
        <div className="lg:col-span-6 flex justify-center">
          <EventTicketReceipt registration={reg} event={evt} />
        </div>

        {/* Right: Structured Pass Summary & Verification Gate Status */}
        <aside className="lg:col-span-6 space-y-5 no-print">
          <div className="studio-card p-6 space-y-5">
            <div className="flex flex-wrap items-start justify-between gap-3 pb-4 border-b border-[var(--border-hairline)]">
              <div>
                <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">
                  {evt.category} · {evt.dateLabel}
                </p>
                <h1 className="text-xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
                  {evt.title}
                </h1>
                <p className="text-xs font-mono-data text-[var(--ink-secondary)] mt-1">
                  Category: <span className="font-semibold">{reg.trackName || 'General Attendee'}</span>
                  {' · '}
                  <span>
                    {reg.pricingSnapshot?.type === 'paid' && reg.pricingSnapshot.amountInr > 0
                      ? `₹${reg.pricingSnapshot.amountInr}`
                      : reg.amountInr && reg.amountInr > 0
                        ? `₹${reg.amountInr}`
                        : reg.paymentStatus === 'Free'
                          ? 'Free Pass'
                          : evt.isPaid
                            ? `₹${evt.feeInr}`
                            : 'Free Pass'}
                  </span>
                </p>
              </div>
              <StatusBadge label={reg.paymentStatus} tone={paymentTone} />
            </div>

            <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
              <div>
                <dt className="text-xs text-[var(--ink-muted)]">Attendee</dt>
                <dd className="font-semibold text-[var(--color-2-mood)] mt-0.5">{reg.attendeeName}</dd>
                <dd className="text-xs text-[var(--ink-muted)]">{reg.attendeeEmail}</dd>
              </div>
              <div>
                <dt className="text-xs text-[var(--ink-muted)]">Enrollment / ID</dt>
                <dd className="font-mono-data font-medium text-[var(--color-2-mood)] mt-0.5">
                  {reg.enrollmentNo}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-[var(--ink-muted)]">Auditorium / Slot</dt>
                <dd className="font-medium text-[var(--color-2-mood)] mt-0.5">{reg.seatSlot}</dd>
              </div>
              <div>
                <dt className="text-xs text-[var(--ink-muted)]">Registration Token</dt>
                <dd className="font-mono-data text-xs font-semibold text-[var(--color-2-mood)] mt-1">
                  {isSuccessfullyRegistered ? reg.ticketToken : 'Hidden until verified'}
                </dd>
              </div>
              {reg.utrNumber && (
                <div className="sm:col-span-2 pt-3 border-t border-[var(--border-hairline)] flex items-center justify-between text-xs">
                  <span className="text-[var(--ink-muted)]">Submitted UPI UTR Reference</span>
                  <span className="font-mono-data font-semibold text-[var(--color-2-mood)]">
                    {reg.utrNumber}
                  </span>
                </div>
              )}
            </dl>

            <div className="pt-4 border-t border-[var(--border-hairline)] flex items-start gap-2 text-xs text-[var(--ink-muted)]">
              <MapPin className="h-3.5 w-3.5 text-[#C01E30] mt-0.5 shrink-0" />
              <span>{evt.venue}</span>
            </div>
          </div>

          {/* Submitted Category-Specific Form Responses */}
          {reg.formResponses && Object.keys(reg.formResponses).length > 0 && (
            <div className="studio-card p-6 space-y-3.5">
              <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-[var(--border-hairline)]">
                <h2 className="text-sm font-display font-semibold text-[var(--color-2-mood)]">
                  Submitted {reg.trackName || 'Category'} Details
                </h2>
                <StatusBadge
                  label={`${Object.keys(reg.formResponses).length} fields`}
                  tone="neutral"
                />
              </div>
              <dl className="space-y-3 text-xs">
                {Object.values(reg.formResponses).map((resp) => {
                  const isFile =
                    resp.type === 'file' &&
                    typeof resp.value === 'object' &&
                    resp.value !== null &&
                    'assetRef' in resp.value;
                  const fileRef = isFile ? (resp.value as UploadedFileRef) : null;
                  return (
                    <div
                      key={resp.fieldId}
                      className="flex flex-col sm:flex-row sm:items-start justify-between gap-1 sm:gap-4"
                    >
                      <dt className="text-[var(--ink-muted)] shrink-0">{resp.label}</dt>
                      <dd className="text-[var(--color-2-mood)] font-medium sm:text-right break-words">
                        {fileRef ? (
                          <button
                            type="button"
                            onClick={async () => {
                              const ok = await downloadStoredDocument(fileRef);
                              if (!ok) {
                                pushToast(
                                  'File unavailable',
                                  'This file is stored in browser IndexedDB on the originating browser.',
                                  'warning'
                                );
                              }
                            }}
                            className="inline-flex items-center gap-1.5 text-[#C01E30] dark:text-[#E67C87] hover:underline cursor-pointer"
                          >
                            <Paperclip className="h-3.5 w-3.5" />
                            <span>
                              {fileRef.name} ({formatBytes(fileRef.size)})
                            </span>
                          </button>
                        ) : (
                          formatRegistrationAnswer(resp.value)
                        )}
                      </dd>
                    </div>
                  );
                })}
              </dl>
            </div>
          )}

          {/* Registration Verification Gate Explainer */}
          <div className="studio-subtle p-5 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-[var(--color-2-mood)]">
              {isSuccessfullyRegistered ? (
                <ShieldCheck className="h-4 w-4 text-[#15803D] dark:text-emerald-400" />
              ) : (
                <Lock className="h-4 w-4 text-[#C01E30]" />
              )}
              <span>
                {isSuccessfullyRegistered
                  ? 'Gate Entry QR Code Active'
                  : 'QR Code Protected Until Confirmation'}
              </span>
            </div>
            <p className="text-xs text-[var(--ink-secondary)] leading-relaxed">
              {isSuccessfullyRegistered
                ? 'Your registration is confirmed. Present the dispensed thermal pass QR code at the Main Auditorium RD desk for instant entry check-in.'
                : 'To prevent unauthorized gate passes, EDC AITR never renders or issues an entry QR code until your registration is confirmed (and UTR payment is verified by the RD desk).'}
            </p>
            {!isSuccessfullyRegistered && (
              <div className="pt-1 flex flex-wrap gap-2">
                {isStaff ? (
                  <StudioButton
                    variant="obsidian"
                    size="sm"
                    onClick={() => navigate(`/workspace/events/${evt.id}/registrations`)}
                  >
                    Approve UTR in RD Ledger
                  </StudioButton>
                ) : (
                  <StudioButton
                    variant="secondary"
                    size="sm"
                    onClick={() => navigate('/account')}
                  >
                    Switch to RD Lead to Verify UTR
                  </StudioButton>
                )}
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
};

export const AnnouncementsPage: React.FC = () => {
  const { announcements, pushToast } = usePortal();
  const [filter, setFilter] = useState<'All' | AnnouncementCategory>('All');

  const visible = announcements.filter((a) => filter === 'All' || a.category === filter);

  const handleDownloadAttachment = (filename: string) => {
    const content = `EDC AITR Official Broadcast Attachment\nFile: ${filename}\nIssued by Entrepreneurship Development Cell, AITR Indore & AIIH Foundation.\n`;
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename.replace(/\.pdf$/i, '.txt');
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    pushToast('Attachment downloaded', filename, 'success');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Official Broadcast Feed</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Announcements Stream
          </h1>
        </div>
        <div className="flex items-center gap-1.5">
          {(['All', 'Urgent', 'Conclave', 'General'] as const).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setFilter(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-[9px] border transition-colors cursor-pointer ${
                filter === cat
                  ? 'bg-[#030405] dark:bg-[#F1F0ED] text-white dark:text-[#101011] border-[#030405] dark:border-[#F1F0ED]'
                  : 'bg-[var(--surface)] text-[var(--ink-secondary)] border-[var(--border-hairline)] hover:bg-[var(--surface-subtle)]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <AnimatedContent
        key={filter}
        trigger="mount"
        distance={32}
        duration={0.65}
        stagger={0.06}
        className="space-y-4"
      >
        {visible.map((item) => (
          <article key={item.id} className="studio-card p-6 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <StatusBadge
                  label={item.category}
                  tone={
                    item.category === 'Urgent'
                      ? 'crimson'
                      : item.category === 'Conclave'
                        ? 'obsidian'
                        : 'neutral'
                  }
                />
                <span className="text-xs text-[var(--ink-muted)]">{item.author}</span>
              </div>
              <span className="font-mono-data text-xs text-[var(--ink-muted)]">{item.date}</span>
            </div>

            <h2 className="text-lg font-display font-semibold text-[var(--color-2-mood)]">{item.title}</h2>
            <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">{item.summary}</p>
            <p className="text-sm text-[var(--ink-muted)] leading-relaxed">{item.body}</p>

            {item.attachmentName && (
              <div className="pt-3 border-t border-[var(--border-hairline)] flex flex-wrap items-center justify-between gap-3">
                <div className="inline-flex items-center gap-2 text-xs text-[var(--color-2-mood)]">
                  <Paperclip className="h-3.5 w-3.5 text-[#C01E30]" />
                  <span className="font-mono-data">{item.attachmentName}</span>
                  <span className="text-[var(--ink-muted)]">({item.attachmentSize})</span>
                </div>
                <StudioButton
                  variant="secondary"
                  size="sm"
                  onClick={() => handleDownloadAttachment(item.attachmentName!)}
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Download Attachment</span>
                </StudioButton>
              </div>
            )}
          </article>
        ))}
      </AnimatedContent>
    </div>
  );
};

export const CertificatesPage: React.FC = () => {
  const { certificates, pushToast } = usePortal();
  const [selectedCert, setSelectedCert] = useState<Certificate | null>(null);

  const handlePrintCert = () => {
    pushToast('Generating Verified Certificate PDF', 'Use Save as PDF in the print dialog.');
    window.setTimeout(() => window.print(), 180);
  };

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Verified Institutional Credentials</p>
        <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
          My Certificates
        </h1>
        <p className="text-sm text-[var(--ink-muted)] mt-1">
          Cryptographically cataloged participation, winner, and organizing credentials issued by EDC AITR.
        </p>
      </div>

      <AnimatedContent
        trigger="mount"
        distance={36}
        duration={0.7}
        stagger={0.08}
        className="grid grid-cols-1 md:grid-cols-2 gap-5"
      >
        {certificates.map((cert) => (
          <TiltGlareCard
            key={cert.id}
            maxTiltDeg={4.5}
            className="studio-card p-6 flex flex-col justify-between space-y-5 hover:border-[var(--border-strong)]"
          >
            <div className="relative z-10 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <StatusBadge
                  label={cert.role}
                  tone={cert.role === 'Winner' ? 'crimson' : cert.role === 'Organizer' ? 'obsidian' : 'green'}
                />
                <span className="font-mono-data text-xs text-[var(--ink-muted)]">Issued {cert.issueDate}</span>
              </div>
              <div>
                <h2 className="text-lg font-display font-semibold text-[var(--color-2-mood)]">
                  {cert.eventName}
                </h2>
                <p className="text-xs text-[var(--ink-secondary)] mt-1">Awarded to {cert.recipientName}</p>
              </div>
              <div className="text-xs text-[var(--ink-muted)] font-mono-data bg-[var(--color-1-mood)] border border-[var(--border-hairline)] rounded-[6px] px-3 py-2 flex items-center justify-between">
                <span>Credential ID</span>
                <span className="font-semibold text-[var(--color-2-mood)]">{cert.credentialCode}</span>
              </div>
            </div>

            <div className="relative z-10 pt-4 border-t border-[var(--border-hairline)] flex items-center justify-between gap-3">
              <span className="inline-flex items-center gap-1.5 text-xs text-[#15803D] dark:text-emerald-400 font-medium">
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>Verified by EDC AITR</span>
              </span>
              <StudioButton
                variant="primary"
                size="sm"
                onClick={() => setSelectedCert(cert)}
              >
                <FileText className="h-3.5 w-3.5" />
                <span>Download Verified Certificate (PDF)</span>
              </StudioButton>
            </div>
          </TiltGlareCard>
        ))}
      </AnimatedContent>

      {/* Printable Certificate Preview Modal — intentionally crisp white paper */}
      <ModalDialog
        open={Boolean(selectedCert)}
        onClose={() => setSelectedCert(null)}
        title="Verified Certificate Preview"
        subtitle="Ready for PDF download or archival printing."
        maxWidthClass="max-w-2xl"
      >
        {selectedCert && (
          <div className="space-y-5">
            <div className="border-2 border-[#030405] rounded-[9px] p-6 sm:p-8 bg-white text-[#030405] space-y-6 print-only-surface">
              <div className="flex items-start justify-between gap-4 pb-5 border-b border-[rgba(3,4,5,0.12)]">
                <EdcLogo variant="light" className="h-11 w-auto" />
                <div className="text-right">
                  <p className="text-[11px] font-mono-data text-[#C01E30] font-semibold">
                    CERTIFICATE OF {selectedCert.role.toUpperCase()}
                  </p>
                  <p className="text-xs font-mono-data text-[#636468] mt-1">
                    {selectedCert.credentialCode}
                  </p>
                </div>
              </div>

              <div className="py-4 space-y-3">
                <p className="text-xs text-[#636468]">This official record certifies that</p>
                <p className="text-3xl font-display font-semibold !text-[#030405]">
                  {selectedCert.recipientName}
                </p>
                <p className="text-sm text-[#343435] leading-relaxed">
                  served as <strong className="text-[#030405]">{selectedCert.role}</strong> during{' '}
                  <strong className="text-[#030405]">{selectedCert.eventName}</strong> organized by the Entrepreneurship Development Cell, Acropolis Institute of Technology &amp; Research, Indore in partnership with AIIH Foundation.
                </p>
              </div>

              <div className="pt-5 border-t border-[rgba(3,4,5,0.12)] flex items-end justify-between gap-4">
                <div>
                  <p className="text-xs font-semibold text-[#030405]">{selectedCert.signatory}</p>
                  <p className="text-[11px] font-mono-data text-[#636468] mt-0.5">
                    Issued on {selectedCert.issueDate}
                  </p>
                </div>
                <QrCodeSvg value={selectedCert.credentialCode} size={74} />
              </div>
            </div>

            <div className="flex justify-end gap-2.5 no-print">
              <StudioButton variant="secondary" onClick={() => setSelectedCert(null)}>
                Close
              </StudioButton>
              <StudioButton variant="primary" onClick={handlePrintCert}>
                <Printer className="h-4 w-4" />
                <span>Print / Save as PDF</span>
              </StudioButton>
            </div>
          </div>
        )}
      </ModalDialog>
    </div>
  );
};
