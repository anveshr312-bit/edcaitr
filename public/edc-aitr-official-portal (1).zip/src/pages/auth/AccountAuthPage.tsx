import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowRight, KeyRound, Lock, Mail, ShieldCheck, UserCheck } from 'lucide-react';
import { usePortal } from '../../context/PortalContext';
import { DEMO_PRESET_ACCOUNTS } from '../../data/seedData';
import {
  EdcLogo,
  ModalDialog,
  MonogramAvatar,
  StatusBadge,
  StudioButton,
} from '../../components/ui/Primitives';
import { AnimatedContent } from '../../components/ui/AnimatedContent';

export const AccountAuthPage: React.FC = () => {
  const { users, currentUser, signInAsUser, signInWithEmail, registerAccount, pushToast, navigate } =
    usePortal();

  const [tab, setTab] = useState<'signin' | 'register'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [department, setDepartment] = useState('B.Tech CSE');
  const [batch, setBatch] = useState('2027');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [resetEmail, setResetEmail] = useState('');

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setLoading(true);
    window.setTimeout(() => {
      signInWithEmail(email);
      setLoading(false);
    }, 350);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !email.trim()) return;
    setLoading(true);
    window.setTimeout(() => {
      registerAccount({ name: fullName, email, department, batch });
      setLoading(false);
    }, 400);
  };

  const handleGoogleContinue = () => {
    setGoogleLoading(true);
    window.setTimeout(() => {
      setGoogleLoading(false);
      signInAsUser('usr-student', '/portal');
    }, 450);
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetEmail.trim()) return;
    pushToast('Password reset link sent', `Check ${resetEmail.trim()} for recovery instructions.`, 'success');
    setForgotOpen(false);
    setResetEmail('');
  };

  return (
    <div className="max-w-[1080px] mx-auto px-4 sm:px-6 py-10 sm:py-14">
      <AnimatedContent
        trigger="mount"
        distance={32}
        duration={0.65}
        stagger={0.09}
        className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
      >
        {/* Main Auth Card */}
        <div className="lg:col-span-6 studio-card p-6 sm:p-8 space-y-6">
          <div className="space-y-4">
            <EdcLogo variant="auto" className="h-10 w-auto" />
            <div>
              <h1 className="text-2xl font-display font-semibold text-[var(--color-2-mood)]">
                EDC AITR Portal Access
              </h1>
              <p className="text-sm text-[var(--ink-muted)] mt-1">
                Sign in for event passes, verified certificates, team operations, or alumni connect.
              </p>
            </div>
          </div>

          {/* Animated Tabs: Sign In & Create Account */}
          <div className="relative grid grid-cols-2 border-b border-[var(--border-hairline)]">
            <button
              type="button"
              onClick={() => setTab('signin')}
              className={`relative pb-3 text-sm font-medium transition-colors cursor-pointer ${
                tab === 'signin'
                  ? 'text-[var(--color-2-mood)]'
                  : 'text-[var(--ink-muted)] hover:text-[var(--color-2-mood)]'
              }`}
            >
              Sign In
              {tab === 'signin' && (
                <motion.span
                  layoutId="auth-tab-underline"
                  transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                  className="absolute left-0 right-0 bottom-0 h-[2px] bg-[#C01E30]"
                />
              )}
            </button>
            <button
              type="button"
              onClick={() => setTab('register')}
              className={`relative pb-3 text-sm font-medium transition-colors cursor-pointer ${
                tab === 'register'
                  ? 'text-[var(--color-2-mood)]'
                  : 'text-[var(--ink-muted)] hover:text-[var(--color-2-mood)]'
              }`}
            >
              Create Account
              {tab === 'register' && (
                <motion.span
                  layoutId="auth-tab-underline"
                  transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                  className="absolute left-0 right-0 bottom-0 h-[2px] bg-[#C01E30]"
                />
              )}
            </button>
          </div>

          <AnimatePresence mode="wait" initial={false}>
          {tab === 'signin' ? (
            <motion.form
              key="auth-signin"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
              onSubmit={handleSignIn}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                  Institutional or Registered Email
                </label>
                <div className="relative">
                  <Mail className="h-4 w-4 text-[var(--ink-muted)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@acropolis.in"
                    className="studio-input pl-9"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-medium text-[var(--color-2-mood)]">Password</label>
                  <button
                    type="button"
                    onClick={() => setForgotOpen(true)}
                    className="text-xs font-medium text-[#C01E30] dark:text-[#F87171] hover:underline cursor-pointer"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="h-4 w-4 text-[var(--ink-muted)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="studio-input pl-9"
                  />
                </div>
              </div>

              <StudioButton type="submit" variant="primary" loading={loading} className="w-full">
                <span>Sign In</span>
                <ArrowRight className="h-4 w-4" />
              </StudioButton>
            </motion.form>
          ) : (
            <motion.form
              key="auth-register"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
              onSubmit={handleRegister}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Full Name</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Riya Choudhary"
                  className="studio-input"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="riya.choudhary@acropolis.in"
                  className="studio-input"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Department</label>
                  <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="studio-input"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Graduation Batch</label>
                  <input
                    type="text"
                    value={batch}
                    onChange={(e) => setBatch(e.target.value)}
                    className="studio-input font-mono-data"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Create Password</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 8 characters"
                  className="studio-input"
                />
              </div>

              <StudioButton type="submit" variant="primary" loading={loading} className="w-full">
                <span>Create Account</span>
              </StudioButton>
            </motion.form>
          )}
          </AnimatePresence>

          <div className="relative py-1">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[var(--border-hairline)]" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-[var(--surface)] px-3 text-[var(--ink-muted)]">or</span>
            </div>
          </div>

          <StudioButton
            type="button"
            variant="secondary"
            loading={googleLoading}
            onClick={handleGoogleContinue}
            className="w-full"
          >
            <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden="true">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.79-.07-1.54-.19-2.27h-11.3v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
              />
              <path
                fill="#34A853"
                d="M12.255 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96h-3.98v3.09C3.515 21.3 7.565 24 12.255 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.525 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62h-3.98a11.86 11.86 0 000 10.76l3.98-3.09z"
              />
              <path
                fill="#EA4335"
                d="M12.255 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C18.205 1.19 15.495 0 12.255 0c-4.69 0-8.74 2.7-10.71 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
              />
            </svg>
            <span>Continue with Google</span>
          </StudioButton>
        </div>

        {/* Quick Demo Account Presets Panel */}
        <div className="lg:col-span-6 space-y-5">
          <div className="studio-card p-6 sm:p-8 space-y-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <StatusBadge label="Frontend Review Presets" tone="crimson" />
                </div>
                <h2 className="text-xl font-display font-semibold text-[var(--color-2-mood)]">
                  Quick Demo Account Access
                </h2>
                <p className="text-sm text-[var(--ink-muted)] mt-1">
                  Switch immediately into any verified role to evaluate all four EDC AITR portals prior to Supabase wiring.
                </p>
              </div>
              <KeyRound className="h-5 w-5 text-[var(--ink-secondary)] shrink-0" strokeWidth={1.7} />
            </div>

            <div className="space-y-3">
              {DEMO_PRESET_ACCOUNTS.map((preset) => {
                const user = users.find((u) => u.id === preset.userId);
                if (!user) return null;
                const isCurrent = currentUser?.id === user.id;

                return (
                  <div
                    key={preset.userId}
                    className={`p-4 rounded-[9px] border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all duration-200 hover:-translate-y-0.5 ${
                      isCurrent
                        ? 'bg-[var(--accent-soft)] border-[var(--accent-border)]'
                        : 'bg-[var(--color-1-mood)] border-[var(--border-hairline)] hover:border-[#C01E30]/60'
                    }`}
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <MonogramAvatar
                        name={user.name}
                        size="md"
                        tone={user.role === 'director' ? 'obsidian' : 'neutral'}
                      />
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="text-sm font-semibold text-[var(--color-2-mood)]">{preset.label}</p>
                          {isCurrent && <StatusBadge label="Active" tone="green" />}
                        </div>
                        <p className="text-xs text-[var(--ink-secondary)] font-medium mt-0.5">
                          {user.name} · <span className="font-mono-data text-[var(--ink-muted)]">{user.email}</span>
                        </p>
                        <p className="text-xs text-[var(--ink-muted)] mt-1">{preset.scopeSummary}</p>
                      </div>
                    </div>

                    <StudioButton
                      variant={isCurrent ? 'secondary' : 'obsidian'}
                      size="sm"
                      onClick={() => signInAsUser(user.id, preset.defaultRoute)}
                    >
                      <UserCheck className="h-3.5 w-3.5" />
                      <span>{isCurrent ? 'Open' : 'Enter'}</span>
                    </StudioButton>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="studio-subtle p-5 flex items-start gap-3">
            <ShieldCheck className="h-5 w-5 text-[#C01E30] shrink-0 mt-0.5" strokeWidth={1.7} />
            <div className="text-xs text-[var(--ink-secondary)] leading-relaxed">
              <p className="font-semibold text-[var(--color-2-mood)]">Cross-Portal Synchronization Active</p>
              <p className="mt-1">
                Actions taken as one persona update every other portal immediately—test submitting a paid event UTR as <strong className="text-[var(--color-2-mood)]">Kabir Sharma</strong>, then approve it and scan the ticket token as <strong className="text-[var(--color-2-mood)]">Aarav Deshmukh (RD Lead)</strong>.
              </p>
              <button
                type="button"
                onClick={() => navigate('/events/fokus-x-e-summit-2026')}
                className="text-[#C01E30] dark:text-[#F87171] font-semibold hover:underline mt-2 inline-block cursor-pointer"
              >
                Jump to FOKUS X E-Summit 2026 Registration
              </button>
            </div>
          </div>
        </div>
      </AnimatedContent>

      {/* Forgot Password Modal */}
      <ModalDialog
        open={forgotOpen}
        onClose={() => setForgotOpen(false)}
        title="Reset Account Password"
        subtitle="Enter your Acropolis or registered email address to receive a recovery link."
      >
        <form onSubmit={handleForgotSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Email Address</label>
            <input
              type="email"
              required
              value={resetEmail}
              onChange={(e) => setResetEmail(e.target.value)}
              placeholder="name@acropolis.in"
              className="studio-input"
            />
          </div>
          <div className="flex justify-end gap-2">
            <StudioButton type="button" variant="secondary" onClick={() => setForgotOpen(false)}>
              Cancel
            </StudioButton>
            <StudioButton type="submit" variant="primary">
              Send Reset Link
            </StudioButton>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
};
