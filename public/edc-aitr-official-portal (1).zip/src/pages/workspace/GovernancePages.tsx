import React, { useState } from 'react';
import { Check, Copy, KeyRound, ShieldCheck, UserCheck, UserPlus, X } from 'lucide-react';
import { usePortal } from '../../context/PortalContext';
import { OPERATIONAL_TEAMS } from '../../data/seedData';
import { OperationalTeamCode } from '../../types/portal';
import {
  MonogramAvatar,
  QrCodeSvg,
  StatusBadge,
  StudioButton,
} from '../../components/ui/Primitives';
import { SelectDropdown } from '../../components/ui/dropdown-menu';
import { AnimatedContent } from '../../components/ui/AnimatedContent';

export const MfaSetupPage: React.FC = () => {
  const { currentUser, toggleMfaForCurrentUser, pushToast } = usePortal();
  const [totpCode, setTotpCode] = useState('');
  const [copiedSecret, setCopiedSecret] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const secretKey = 'AITR-EDC7-AIIH-92XK-2026';
  const otpAuthUri = `otpauth://totp/EDC-AITR:${encodeURIComponent(
    currentUser?.email ?? 'director.edc@acropolis.in'
  )}?secret=AITREDC7AIIH92XK2026&issuer=EDC%20AITR%20Indore`;

  const handleCopySecret = () => {
    navigator.clipboard?.writeText(secretKey).catch(() => {});
    setCopiedSecret(true);
    pushToast('Secret key copied', secretKey);
    window.setTimeout(() => setCopiedSecret(false), 2000);
  };

  const handleVerifyTotp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!/^\d{6}$/.test(totpCode.trim())) {
      setErrorMsg('Enter a valid 6-digit numeric TOTP code from your authenticator app.');
      return;
    }
    toggleMfaForCurrentUser(true);
    setTotpCode('');
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Administrative Security</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Director Authenticator App (TOTP 2FA)
          </h1>
          <p className="text-sm text-[var(--ink-muted)] mt-1">
            Protect event closure locks, certificate issuance, and role promotions with time-based one-time passcodes.
          </p>
        </div>
        <StatusBadge
          label={currentUser?.mfaEnabled ? '2FA Active' : '2FA Not Enrolled'}
          tone={currentUser?.mfaEnabled ? 'green' : 'amber'}
        />
      </div>

      <div className="studio-card p-6 sm:p-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        <div className="md:col-span-5 flex flex-col items-center p-5 bg-[var(--color-1-mood)] border border-[var(--border-hairline)] rounded-[9px] space-y-3">
          <QrCodeSvg value={otpAuthUri} size={172} label="TOTP Authenticator Setup QR" />
          <p className="text-[11px] text-[var(--ink-muted)] text-center">
            Scan with Google Authenticator, Authy, or 1Password
          </p>
        </div>

        <div className="md:col-span-7 space-y-5">
          <div className="space-y-1.5">
            <p className="text-xs font-semibold text-[var(--color-2-mood)]">Step 1 · Pair Authenticator Key</p>
            <p className="text-xs text-[var(--ink-muted)]">
              If you cannot scan the QR code, enter this institutional setup key manually:
            </p>
            <div className="flex items-center gap-2 pt-1">
              <code className="font-mono-data text-xs font-semibold text-[var(--color-2-mood)] bg-[var(--surface-subtle)] border border-[var(--border-strong)] rounded-[6px] px-3 py-2 flex-1">
                {secretKey}
              </code>
              <StudioButton type="button" variant="secondary" size="sm" onClick={handleCopySecret}>
                {copiedSecret ? <Check className="h-3.5 w-3.5 text-[#15803D] dark:text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copiedSecret ? 'Copied' : 'Copy'}</span>
              </StudioButton>
            </div>
          </div>

          <form onSubmit={handleVerifyTotp} className="space-y-3 pt-4 border-t border-[var(--border-hairline)]">
            <p className="text-xs font-semibold text-[var(--color-2-mood)]">
              Step 2 · Verify 6-Digit Authenticator Code
            </p>
            <div className="flex flex-col sm:flex-row gap-2.5">
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={totpCode}
                onChange={(e) => setTotpCode(e.target.value.replace(/\D/g, ''))}
                placeholder="e.g. 482910"
                className="studio-input font-mono-data tracking-[0.2em] text-center sm:w-44"
              />
              <StudioButton type="submit" variant="primary">
                <ShieldCheck className="h-4 w-4" />
                <span>{currentUser?.mfaEnabled ? 'Re-Verify TOTP' : 'Verify & Enable 2FA'}</span>
              </StudioButton>
            </div>
            {errorMsg && <p className="text-xs text-[#C01E30] dark:text-[#F87171] font-medium">{errorMsg}</p>}
          </form>

          {currentUser?.mfaEnabled && (
            <div className="pt-3 border-t border-[var(--border-hairline)] flex items-center justify-between">
              <span className="text-xs text-[#15803D] dark:text-emerald-400 font-medium inline-flex items-center gap-1.5">
                <KeyRound className="h-3.5 w-3.5" />
                <span>Authenticator verified for {currentUser.email}</span>
              </span>
              <button
                type="button"
                onClick={() => toggleMfaForCurrentUser(false)}
                className="text-xs font-medium text-[#C01E30] dark:text-[#F87171] hover:underline cursor-pointer"
              >
                Disable 2FA
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export const MembershipApplyPage: React.FC = () => {
  const { currentUser, submitMembershipApplication, navigate } = usePortal();
  const [name, setName] = useState(currentUser?.name ?? '');
  const [email, setEmail] = useState(currentUser?.email ?? '');
  const [enrollmentNo, setEnrollmentNo] = useState('0827CS241089');
  const [branchYear, setBranchYear] = useState(currentUser?.department ?? 'B.Tech CSE · II Year');
  const [preferredTeam, setPreferredTeam] = useState<OperationalTeamCode>('RD');
  const [secondaryTeam, setSecondaryTeam] = useState<OperationalTeamCode>('DOCS');
  const [portfolioUrl, setPortfolioUrl] = useState('');
  const [statement, setStatement] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !statement.trim()) return;
    setSubmitting(true);
    window.setTimeout(() => {
      submitMembershipApplication({
        applicantName: name.trim(),
        email: email.trim(),
        enrollmentNo: enrollmentNo.trim().toUpperCase(),
        branchYear: branchYear.trim(),
        preferredTeam,
        secondaryTeam,
        portfolioUrl: portfolioUrl.trim() || 'https://linkedin.com',
        statement: statement.trim(),
      });
      setSubmitting(false);
      setSubmitted(true);
    }, 350);
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Student Recruitment · 2026 Intake</p>
        <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
          Submit EDC AITR Membership Application
        </h1>
        <p className="text-sm text-[var(--ink-muted)] mt-1">
          Apply to join one of EDC AITR’s 12 operational divisions. Applications are reviewed by Faculty Advisors and the Core Leadership Board.
        </p>
      </div>

      {submitted ? (
        <div className="studio-card p-8 space-y-4">
          <StatusBadge label="Application Submitted" tone="green" />
          <h2 className="text-xl font-display font-semibold text-[var(--color-2-mood)]">
            Your application is queued for Advisor &amp; Core Review
          </h2>
          <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">
            You can inspect how Advisors review your application immediately by switching to the Director or Core Team preset and opening Application Reviews.
          </p>
          <div className="flex flex-wrap gap-2.5 pt-2">
            <StudioButton variant="primary" size="sm" onClick={() => navigate('/portal')}>
              Return to Dashboard
            </StudioButton>
            <StudioButton variant="secondary" size="sm" onClick={() => setSubmitted(false)}>
              Submit Another Application
            </StudioButton>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="studio-card p-6 sm:p-8 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="studio-input"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Institutional Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="studio-input"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Enrollment Number</label>
              <input
                type="text"
                required
                value={enrollmentNo}
                onChange={(e) => setEnrollmentNo(e.target.value)}
                className="studio-input font-mono-data"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Branch &amp; Year</label>
              <input
                type="text"
                required
                value={branchYear}
                onChange={(e) => setBranchYear(e.target.value)}
                className="studio-input"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                Primary Operational Division
              </label>
              <SelectDropdown
                value={preferredTeam}
                onChange={(val) => setPreferredTeam(val as OperationalTeamCode)}
                size="default"
                className="w-full"
                menuLabel="Primary Division"
                options={OPERATIONAL_TEAMS.map((t) => ({
                  value: t.code,
                  label: `${t.code} — ${t.name}`,
                }))}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                Secondary Operational Division
              </label>
              <SelectDropdown
                value={secondaryTeam}
                onChange={(val) => setSecondaryTeam(val as OperationalTeamCode)}
                size="default"
                className="w-full"
                menuLabel="Secondary Division"
                options={OPERATIONAL_TEAMS.map((t) => ({
                  value: t.code,
                  label: `${t.code} — ${t.name}`,
                }))}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
              LinkedIn / GitHub / Design Portfolio URL
            </label>
            <input
              type="url"
              value={portfolioUrl}
              onChange={(e) => setPortfolioUrl(e.target.value)}
              placeholder="https://linkedin.com/in/your-profile"
              className="studio-input"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
              Why do you want to operate in this EDC AITR division?
            </label>
            <textarea
              rows={4}
              required
              value={statement}
              onChange={(e) => setStatement(e.target.value)}
              placeholder="Share concrete execution experience, event skills, or startup initiatives..."
              className="studio-input"
            />
          </div>

          <div className="pt-2 flex justify-end">
            <StudioButton type="submit" variant="primary" loading={submitting}>
              <UserPlus className="h-4 w-4" />
              <span>Submit Membership Application</span>
            </StudioButton>
          </div>
        </form>
      )}
    </div>
  );
};

export const ApplicationsReviewPage: React.FC = () => {
  const { applications, reviewMembershipApplication } = usePortal();
  const [filter, setFilter] = useState<'All' | 'Pending' | 'Approved' | 'Rejected'>('All');
  const [notesDraft, setNotesDraft] = useState<Record<string, string>>({});

  const visible = applications.filter((a) => filter === 'All' || a.status === filter);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Advisor &amp; Director Governance</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Core Team Applications &amp; Promotions
          </h1>
        </div>

        <div className="flex items-center gap-1.5">
          {(['All', 'Pending', 'Approved', 'Rejected'] as const).map((tab) => (
            <button
              key={tab}
              type="button"
              onClick={() => setFilter(tab)}
              className={`px-3 py-1.5 text-xs font-medium rounded-[9px] border cursor-pointer ${
                filter === tab
                  ? 'bg-[#030405] dark:bg-[#F1F0ED] text-white dark:text-[#101011] border-[#030405] dark:border-[#F1F0ED]'
                  : 'bg-[var(--surface)] text-[var(--ink-secondary)] border-[var(--border-strong)] hover:bg-[var(--surface-subtle)]'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      <AnimatedContent
        key={`apps-${filter}`}
        trigger="mount"
        distance={24}
        duration={0.55}
        stagger={0.06}
        className="space-y-4"
      >
        {visible.length === 0 ? (
          <div className="studio-card p-8 text-center text-sm text-[var(--ink-muted)]">
            No membership applications in this queue.
          </div>
        ) : (
          visible.map((app) => {
            const currentNote = notesDraft[app.id] ?? app.internalNotes;
            return (
              <article key={app.id} className="studio-card p-6 space-y-4 hover:border-[#C01E30]/45 transition-colors">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="flex items-start gap-3.5">
                    <MonogramAvatar name={app.applicantName} size="md" />
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
                          {app.applicantName}
                        </h2>
                        <StatusBadge
                          label={app.status}
                          tone={
                            app.status === 'Approved'
                              ? 'green'
                              : app.status === 'Rejected'
                                ? 'crimson'
                                : 'amber'
                          }
                        />
                      </div>
                      <p className="text-xs text-[var(--ink-muted)] mt-0.5">
                        {app.branchYear} · <span className="font-mono-data">{app.enrollmentNo}</span> ·{' '}
                        {app.email}
                      </p>
                      <div className="flex flex-wrap items-center gap-2 mt-2 text-xs">
                        <span className="font-mono-data font-semibold text-[var(--color-2-mood)] bg-[var(--surface-subtle)] border border-[var(--border-hairline)] rounded-[4px] px-2 py-0.5">
                          Primary: {app.preferredTeam}
                        </span>
                        <span className="font-mono-data text-[var(--ink-secondary)] bg-[var(--color-1-mood)] border border-[var(--border-hairline)] rounded-[4px] px-2 py-0.5">
                          Secondary: {app.secondaryTeam}
                        </span>
                        <a
                          href={app.portfolioUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[#C01E30] dark:text-[#F87171] font-medium hover:underline"
                        >
                          Portfolio Link
                        </a>
                      </div>
                    </div>
                  </div>
                  <span className="font-mono-data text-xs text-[var(--ink-muted)] shrink-0">
                    {app.submittedAt}
                  </span>
                </div>

                <p className="text-sm text-[var(--ink-secondary)] leading-relaxed bg-[var(--color-1-mood)] border border-[var(--border-hairline)] rounded-[9px] p-4">
                  {app.statement}
                </p>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-end pt-2 border-t border-[var(--border-hairline)]">
                  <div className="lg:col-span-8">
                    <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">
                      Internal Advisor / Director Review Notes
                    </label>
                    <input
                      type="text"
                      value={currentNote}
                      onChange={(e) =>
                        setNotesDraft((prev) => ({ ...prev, [app.id]: e.target.value }))
                      }
                      placeholder="Add interview score, trial task verdict, or onboarding notes..."
                      className="studio-input text-xs"
                    />
                  </div>
                  <div className="lg:col-span-4 flex items-center justify-end gap-2">
                    <StudioButton
                      type="button"
                      variant="secondary"
                      size="sm"
                      onClick={() => reviewMembershipApplication(app.id, 'Rejected', currentNote)}
                    >
                      <X className="h-3.5 w-3.5 text-[#C01E30] dark:text-[#F87171]" />
                      <span>Reject</span>
                    </StudioButton>
                    <StudioButton
                      type="button"
                      variant="primary"
                      size="sm"
                      onClick={() => reviewMembershipApplication(app.id, 'Approved', currentNote)}
                    >
                      <UserCheck className="h-3.5 w-3.5" />
                      <span>Approve &amp; Promote</span>
                    </StudioButton>
                  </div>
                </div>
              </article>
            );
          })
        )}
      </AnimatedContent>
    </div>
  );
};
