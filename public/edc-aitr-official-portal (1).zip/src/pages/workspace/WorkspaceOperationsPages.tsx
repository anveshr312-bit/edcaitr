import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Award,
  Camera,
  Check,
  CheckCircle2,
  Download,
  ExternalLink,
  FileSpreadsheet,
  Lock,
  MessageSquare,
  Paperclip,
  Plus,
  QrCode,
  ScanLine,
  Search,
  Send,
  Unlock,
  X,
  XCircle,
} from 'lucide-react';
import { downloadCsvFile, usePortal } from '../../context/PortalContext';
import { OPERATIONAL_TEAMS } from '../../data/seedData';
import {
  OperationalTeamCode,
  Registration,
  TaskItem,
  TaskStatus,
  UploadedFileRef,
} from '../../types/portal';
import {
  ModalDialog,
  MonogramAvatar,
  StatusBadge,
  StudioButton,
} from '../../components/ui/Primitives';
import { GooeySearch } from '../../components/ui/GooeySearch';
import { SelectDropdown } from '../../components/ui/dropdown-menu';
import { AnimatedContent } from '../../components/ui/AnimatedContent';
import { formatRegistrationAnswer, getEffectiveTracks } from '../../utils/eventTracks';
import { downloadStoredDocument, formatBytes } from '../../utils/mediaStorage';

const KANBAN_COLUMNS: { status: TaskStatus; label: string }[] = [
  { status: 'To Do', label: 'To Do' },
  { status: 'In Progress', label: 'In Progress' },
  { status: 'Submitted', label: 'Submitted' },
  { status: 'Approved', label: 'Approved' },
];

export const TaskBoardPage: React.FC<{ eventId: string }> = ({ eventId }) => {
  const { events, tasks, users, createTask, updateTaskStatus, addTaskComment } = usePortal();
  const evt = events.find((e) => e.id === eventId) ?? events[0];
  const isLocked = evt?.status === 'Closed';
  const coreUsers = users.filter((u) => u.role !== 'participant');

  const [teamFilter, setTeamFilter] = useState<'ALL' | OperationalTeamCode>('ALL');
  const [showChangesOnly, setShowChangesOnly] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');
  const [createOpen, setCreateOpen] = useState(false);

  // Create form state
  const [newTitle, setNewTitle] = useState('');
  const [newBrief, setNewBrief] = useState('');
  const [newTeam, setNewTeam] = useState<OperationalTeamCode>('RD');
  const [newAssignee, setNewAssignee] = useState(coreUsers[0]?.id ?? '');
  const [newDeadline, setNewDeadline] = useState('2026-03-17');
  const [newAttachment, setNewAttachment] = useState('');

  const eventTasks = useMemo(() => {
    return tasks.filter((t) => {
      if (t.eventId !== evt?.id) return false;
      if (teamFilter !== 'ALL' && t.teamCode !== teamFilter) return false;
      if (showChangesOnly && t.status !== 'Changes Requested') return false;
      return true;
    });
  }, [tasks, evt?.id, teamFilter, showChangesOnly]);

  const selectedTask: TaskItem | undefined = tasks.find((t) => t.id === selectedTaskId);

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !evt) return;
    createTask({
      eventId: evt.id,
      title: newTitle.trim(),
      brief: newBrief.trim() || 'Deliverable tracked via EDC AITR Team Workspace.',
      teamCode: newTeam,
      assigneeId: newAssignee,
      deadline: newDeadline,
      status: 'To Do',
      attachmentUrl: newAttachment.trim() || undefined,
    });
    setNewTitle('');
    setNewBrief('');
    setNewAttachment('');
    setCreateOpen(false);
  };

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask || !commentText.trim()) return;
    addTaskComment(selectedTask.id, commentText);
    setCommentText('');
  };

  const changesRequestedCount = tasks.filter(
    (t) => t.eventId === evt?.id && t.status === 'Changes Requested'
  ).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Deliverables &amp; Reviews</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Task Management Board · {evt?.title}
          </h1>
        </div>
        <StudioButton
          variant="primary"
          size="sm"
          disabled={isLocked}
          onClick={() => setCreateOpen(true)}
        >
          <Plus className="h-4 w-4" />
          <span>Assign Task</span>
        </StudioButton>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <SelectDropdown
            value={teamFilter}
            onChange={(val) => setTeamFilter(val as 'ALL' | OperationalTeamCode)}
            size="xs"
            className="w-auto min-w-[205px]"
            groups={[
              {
                label: 'Scope',
                options: [{ value: 'ALL', label: 'All 12 Operational Teams' }],
              },
              {
                label: 'Operational Units',
                options: OPERATIONAL_TEAMS.map((t) => ({
                  value: t.code,
                  label: `${t.code} — ${t.name}`,
                })),
              },
            ]}
          />

          <button
            type="button"
            onClick={() => setShowChangesOnly((prev) => !prev)}
            className={`px-3 py-1.5 rounded-[9px] border text-xs font-medium transition-colors cursor-pointer ${
              showChangesOnly
                ? 'bg-[var(--accent-soft)] text-[#C01E30] dark:text-[#F87171] border-[var(--accent-border)]'
                : 'bg-[var(--surface)] text-[var(--ink-secondary)] border-[var(--border-strong)] hover:bg-[var(--surface-subtle)]'
            }`}
          >
            Changes Requested ({changesRequestedCount})
          </button>
        </div>

        <span className="font-mono-data text-xs text-[var(--ink-muted)]">
          {eventTasks.length} deliverable(s) shown
        </span>
      </div>

      {/* 4-Column Kanban Board */}
      <AnimatedContent
        trigger="mount"
        distance={26}
        duration={0.58}
        stagger={0.07}
        className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 items-start"
      >
        {KANBAN_COLUMNS.map((col) => {
          const colTasks = eventTasks.filter((t) =>
            col.status === 'In Progress'
              ? t.status === 'In Progress' || t.status === 'Changes Requested'
              : t.status === col.status
          );
          return (
            <div key={col.status} className="studio-subtle p-3.5 space-y-3 min-h-[260px]">
              <div className="flex items-center justify-between px-1">
                <h2 className="text-xs font-semibold text-[var(--color-2-mood)]">{col.label}</h2>
                <span className="font-mono-data text-xs text-[var(--ink-muted)]">{colTasks.length}</span>
              </div>

              <div className="space-y-2.5">
                {colTasks.length === 0 ? (
                  <div className="p-4 rounded-[9px] border border-dashed border-[var(--border-strong)] text-center text-xs text-[var(--ink-muted)]">
                    No tasks in {col.label}
                  </div>
                ) : (
                  colTasks.map((task) => {
                    const assignee = users.find((u) => u.id === task.assigneeId);
                    return (
                      <button
                        key={task.id}
                        type="button"
                        onClick={() => setSelectedTaskId(task.id)}
                        className="w-full text-left bg-[var(--surface)] border border-[var(--border-hairline)] hover:border-[#C01E30] hover:-translate-y-0.5 rounded-[9px] p-3.5 space-y-2.5 transition-all duration-150 cursor-pointer"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-mono-data text-[11px] font-semibold text-[var(--color-2-mood)] bg-[var(--surface-subtle)] rounded-[4px] px-1.5 py-0.5">
                            {task.teamCode}
                          </span>
                          {task.status === 'Changes Requested' && (
                            <StatusBadge label="Changes Requested" tone="amber" />
                          )}
                        </div>
                        <p className="text-sm font-semibold text-[var(--color-2-mood)] leading-snug">
                          {task.title}
                        </p>
                        <div className="pt-2 border-t border-[var(--border-hairline)] flex items-center justify-between gap-2 text-[11px] text-[var(--ink-muted)]">
                          <span className="truncate">{assignee?.name ?? 'Unassigned'}</span>
                          <div className="flex items-center gap-2 shrink-0 font-mono-data">
                            {task.comments.length > 0 && (
                              <span className="inline-flex items-center gap-0.5">
                                <MessageSquare className="h-3 w-3" />
                                {task.comments.length}
                              </span>
                            )}
                            <span>{task.deadline}</span>
                          </div>
                        </div>
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </AnimatedContent>

      {/* Task Detail & Threaded Comments Modal */}
      <ModalDialog
        open={Boolean(selectedTask)}
        onClose={() => setSelectedTaskId(null)}
        title={selectedTask?.title ?? ''}
        subtitle={selectedTask ? `${selectedTask.teamCode} Operational Unit · Due ${selectedTask.deadline}` : ''}
        maxWidthClass="max-w-2xl"
      >
        {selectedTask && (
          <div className="space-y-5">
            <div className="space-y-2">
              <p className="text-xs font-semibold text-[var(--color-2-mood)]">Deliverable Brief</p>
              <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">{selectedTask.brief}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4 border-y border-[var(--border-hairline)]">
              <div>
                <p className="text-xs text-[var(--ink-muted)]">Assigned Member</p>
                <div className="mt-1.5 flex items-center gap-2">
                  <MonogramAvatar
                    name={users.find((u) => u.id === selectedTask.assigneeId)?.name ?? 'ED'}
                    size="sm"
                  />
                  <span className="text-sm font-medium text-[var(--color-2-mood)]">
                    {users.find((u) => u.id === selectedTask.assigneeId)?.name ?? 'Core Team'}
                  </span>
                </div>
              </div>
              <div>
                <p className="text-xs text-[var(--ink-muted)] mb-1.5">Workflow Stage</p>
                <SelectDropdown
                  disabled={isLocked}
                  value={selectedTask.status}
                  onChange={(val) => updateTaskStatus(selectedTask.id, val as TaskStatus)}
                  size="sm"
                  align="end"
                  className="w-full"
                  menuLabel="Task Status"
                  options={[
                    { value: 'To Do', label: 'To Do' },
                    { value: 'In Progress', label: 'In Progress' },
                    { value: 'Submitted', label: 'Submitted' },
                    { value: 'Changes Requested', label: 'Changes Requested' },
                    { value: 'Approved', label: 'Approved' },
                  ]}
                />
              </div>
            </div>

            {selectedTask.attachmentUrl && (
              <a
                href={selectedTask.attachmentUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-xs font-medium text-[#C01E30] dark:text-[#F87171] hover:underline"
              >
                <Paperclip className="h-3.5 w-3.5" />
                <span className="truncate">{selectedTask.attachmentUrl}</span>
                <ExternalLink className="h-3 w-3" />
              </a>
            )}

            {/* Threaded Comments */}
            <div className="space-y-3">
              <p className="text-xs font-semibold text-[var(--color-2-mood)]">
                Threaded Review Comments ({selectedTask.comments.length})
              </p>
              <div className="space-y-2.5 max-h-[200px] overflow-y-auto">
                {selectedTask.comments.length === 0 ? (
                  <p className="text-xs text-[var(--ink-muted)]">No review comments posted yet.</p>
                ) : (
                  selectedTask.comments.map((cmt) => (
                    <div
                      key={cmt.id}
                      className="p-3 rounded-[9px] bg-[var(--color-1-mood)] border border-[var(--border-hairline)] space-y-1"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-[var(--color-2-mood)]">
                          {cmt.authorName} · <span className="font-normal text-[var(--ink-muted)]">{cmt.authorRole}</span>
                        </span>
                        <span className="font-mono-data text-[11px] text-[var(--ink-muted)]">{cmt.createdAt}</span>
                      </div>
                      <p className="text-xs text-[var(--ink-secondary)] leading-relaxed">{cmt.text}</p>
                    </div>
                  ))
                )}
              </div>

              {!isLocked && (
                <form onSubmit={handlePostComment} className="flex gap-2">
                  <input
                    type="text"
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Add review feedback or deliverable update..."
                    className="studio-input text-xs flex-1"
                  />
                  <StudioButton type="submit" variant="obsidian" size="sm">
                    <Send className="h-3.5 w-3.5" />
                    <span>Post</span>
                  </StudioButton>
                </form>
              )}
            </div>
          </div>
        )}
      </ModalDialog>

      {/* Assign New Task Modal */}
      <ModalDialog
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        isDirty={Boolean(newTitle.trim() || newBrief.trim() || newAttachment.trim())}
        dirtyWarningText="This deliverable draft has unsaved entries. Discard and close?"
        title="Assign Operational Deliverable"
        subtitle={`Create a tracked task inside ${evt?.title}`}
      >
        <form onSubmit={handleCreateTask} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Task Title</label>
            <input
              type="text"
              required
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="e.g. Setup Registration Desk QR tablets"
              className="studio-input"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Operational Team</label>
              <SelectDropdown
                value={newTeam}
                onChange={(val) => setNewTeam(val as OperationalTeamCode)}
                size="sm"
                className="w-full"
                menuLabel="Operational Units"
                options={OPERATIONAL_TEAMS.map((t) => ({
                  value: t.code,
                  label: `${t.code} — ${t.name}`,
                }))}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Assigned Member</label>
              <SelectDropdown
                value={newAssignee}
                onChange={setNewAssignee}
                size="sm"
                align="end"
                className="w-full"
                menuLabel="Core Team"
                options={coreUsers.map((u) => ({
                  value: u.id,
                  label: u.name,
                }))}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Deliverable Deadline</label>
              <input
                type="date"
                value={newDeadline}
                onChange={(e) => setNewDeadline(e.target.value)}
                className="studio-input font-mono-data text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Attachment Link (Optional)</label>
              <input
                type="url"
                value={newAttachment}
                onChange={(e) => setNewAttachment(e.target.value)}
                placeholder="https://drive.google.com/..."
                className="studio-input text-xs"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Detailed Brief</label>
            <textarea
              rows={3}
              value={newBrief}
              onChange={(e) => setNewBrief(e.target.value)}
              placeholder="Specify acceptance criteria and handoff notes..."
              className="studio-input"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <StudioButton type="button" variant="secondary" onClick={() => setCreateOpen(false)}>
              Cancel
            </StudioButton>
            <StudioButton type="submit" variant="primary">
              Create Task
            </StudioButton>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
};

export const QrCheckinConsolePage: React.FC<{ eventId: string }> = ({ eventId }) => {
  const { events, registrations, processQrCheckIn } = usePortal();
  const evt = events.find((e) => e.id === eventId) ?? events[0];
  const eventRegs = registrations.filter((r) => r.eventId === evt?.id);
  const checkedInCount = eventRegs.filter((r) => r.checkInStatus === 'Checked In').length;

  const [tokenInput, setTokenInput] = useState('');
  const [cameraActive, setCameraActive] = useState(true);
  const [lastResult, setLastResult] = useState<{
    outcome: 'VALID' | 'ALREADY' | 'INVALID';
    registration?: Registration;
    message: string;
  } | null>(null);
  const [scanHistory, setScanHistory] = useState<
    {
      token: string;
      outcome: 'VALID' | 'ALREADY' | 'INVALID';
      attendee: string;
      category?: string;
      time: string;
    }[]
  >([]);

  const runScan = (token: string) => {
    if (!evt) return;
    const res = processQrCheckIn(evt.id, token);
    setLastResult(res);
    setScanHistory((prev) => [
      {
        token: token.trim(),
        outcome: res.outcome,
        attendee: res.registration?.attendeeName ?? 'Unknown Ticket',
        category: res.registration?.trackName,
        time: new Date().toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }),
      },
      ...prev.slice(0, 7),
    ]);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    runScan(tokenInput);
    setTokenInput('');
  };

  const sampleVerifiedUnchecked = eventRegs.find(
    (r) => (r.paymentStatus === 'Verified' || r.paymentStatus === 'Free') && r.checkInStatus === 'Not Checked In'
  );
  const sampleCheckedIn = eventRegs.find((r) => r.checkInStatus === 'Checked In');
  const samplePendingUtr = eventRegs.find((r) => r.paymentStatus === 'Pending Payment Verification');

  return (
    <div className="space-y-6">
      {/* Header + Live Counter */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">RD (Registration &amp; Check-in) Desk</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            QR Check-in Console · {evt?.title}
          </h1>
        </div>

        <div className="studio-card px-5 py-3 flex items-center gap-6">
          <div>
            <p className="text-[11px] text-[var(--ink-muted)]">Checked In</p>
            <p className="font-mono-data text-2xl font-semibold text-[#15803D] dark:text-emerald-400">{checkedInCount}</p>
          </div>
          <div className="h-8 w-px bg-[var(--border-hairline)]" />
          <div>
            <p className="text-[11px] text-[var(--ink-muted)]">Total Registered</p>
            <p className="font-mono-data text-2xl font-semibold text-[var(--color-2-mood)]">{eventRegs.length}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Camera Scanner Viewfinder + Manual Lookup */}
        <div className="lg:col-span-7 studio-card p-6 space-y-5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-[var(--color-2-mood)]">
              <Camera className="h-4 w-4 text-[#C01E30] dark:text-[#F87171]" />
              <span>Gate Camera Scanner Preview</span>
            </div>
            <button
              type="button"
              onClick={() => setCameraActive((p) => !p)}
              className="text-xs font-medium text-[var(--ink-secondary)] border border-[var(--border-strong)] rounded-[9px] px-3 py-1 hover:bg-[var(--surface-subtle)] cursor-pointer"
            >
              {cameraActive ? 'Pause Viewfinder' : 'Resume Viewfinder'}
            </button>
          </div>

          {/* Crisp Studio Scanner Frame */}
          <div className="relative h-64 rounded-[9px] border border-[var(--border-strong)] bg-[var(--surface-subtle)] overflow-hidden flex flex-col items-center justify-center p-6 text-center">
            <div className="relative h-40 w-40 border-2 border-[var(--color-2-mood)] rounded-[9px] flex flex-col items-center justify-center bg-[var(--surface)]/85">
              <QrCode className="h-10 w-10 text-[var(--color-2-mood)]/70 mb-2" strokeWidth={1.4} />
              <span className="font-mono-data text-[11px] text-[var(--ink-secondary)]">
                {cameraActive ? 'READY FOR QR' : 'VIEWFINDER PAUSED'}
              </span>
              {cameraActive && (
                <div className="absolute inset-x-2 top-1/2 h-[2px] bg-[#C01E30]" />
              )}
            </div>
            <p className="text-xs text-[var(--ink-muted)] mt-3">
              Align attendee’s digital pass QR inside the reticle or trigger a test scan below.
            </p>
          </div>

          {/* Quick RD Desk Test Triggers */}
          <div className="space-y-2">
            <p className="text-xs font-medium text-[var(--ink-muted)]">Simulate Hardware Scan:</p>
            <div className="flex flex-wrap gap-2">
              {sampleVerifiedUnchecked && (
                <StudioButton
                  variant="secondary"
                  size="sm"
                  onClick={() => runScan(sampleVerifiedUnchecked.ticketToken)}
                >
                  <ScanLine className="h-3.5 w-3.5 text-[#15803D] dark:text-emerald-400" />
                  <span>Scan Valid ({sampleVerifiedUnchecked.ticketToken})</span>
                </StudioButton>
              )}
              {sampleCheckedIn && (
                <StudioButton
                  variant="secondary"
                  size="sm"
                  onClick={() => runScan(sampleCheckedIn.ticketToken)}
                >
                  <ScanLine className="h-3.5 w-3.5 text-[#B45309] dark:text-amber-400" />
                  <span>Scan Duplicate ({sampleCheckedIn.ticketToken})</span>
                </StudioButton>
              )}
              {samplePendingUtr && (
                <StudioButton
                  variant="secondary"
                  size="sm"
                  onClick={() => runScan(samplePendingUtr.ticketToken)}
                >
                  <ScanLine className="h-3.5 w-3.5 text-[#C01E30] dark:text-[#F87171]" />
                  <span>Scan Unverified UTR</span>
                </StudioButton>
              )}
              <StudioButton
                variant="secondary"
                size="sm"
                onClick={() => runScan('EDC-FAKE-0000-XXX')}
              >
                <ScanLine className="h-3.5 w-3.5 text-[#C01E30] dark:text-[#F87171]" />
                <span>Scan Invalid Token</span>
              </StudioButton>
            </div>
          </div>

          {/* Manual Token Search */}
          <form onSubmit={handleManualSubmit} className="pt-4 border-t border-[var(--border-hairline)] flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1">
              <Search className="h-4 w-4 text-[var(--ink-muted)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={tokenInput}
                onChange={(e) => setTokenInput(e.target.value)}
                placeholder="Enter ticket token (e.g. EDC-ES26-8419-KBR) or enrollment no."
                className="studio-input pl-9 font-mono-data text-xs"
              />
            </div>
            <StudioButton type="submit" variant="primary">
              Validate &amp; Check In
            </StudioButton>
          </form>
        </div>

        {/* Instant Validation Feedback & Recent Gate Log */}
        <div className="lg:col-span-5 space-y-5">
          <div className="studio-card p-6 space-y-4">
            <h2 className="text-sm font-display font-semibold text-[var(--color-2-mood)]">
              Instant Verification Output
            </h2>

            {!lastResult ? (
              <div className="p-6 rounded-[9px] bg-[var(--color-1-mood)] border border-dashed border-[var(--border-strong)] text-center text-xs text-[var(--ink-muted)]">
                Waiting for first scan. Use the manual token box or click any scan trigger on the left.
              </div>
            ) : (
              <div
                className={`p-5 rounded-[9px] border space-y-3 ${
                  lastResult.outcome === 'VALID'
                    ? 'bg-[#ECFDF3] dark:bg-emerald-950/40 border-[#86EFAC] dark:border-emerald-800/70'
                    : lastResult.outcome === 'ALREADY'
                      ? 'bg-[#FFFBEB] dark:bg-amber-950/40 border-[#FDE68A] dark:border-amber-800/70'
                      : 'bg-[var(--accent-soft)] border-[var(--accent-border)]'
                }`}
              >
                <div className="flex items-center gap-2">
                  {lastResult.outcome === 'VALID' && (
                    <CheckCircle2 className="h-5 w-5 text-[#15803D] dark:text-emerald-400 shrink-0" />
                  )}
                  {lastResult.outcome === 'ALREADY' && (
                    <AlertTriangle className="h-5 w-5 text-[#B45309] dark:text-amber-400 shrink-0" />
                  )}
                  {lastResult.outcome === 'INVALID' && (
                    <XCircle className="h-5 w-5 text-[#C01E30] dark:text-[#F87171] shrink-0" />
                  )}
                  <span
                    className={`font-mono-data text-sm font-semibold ${
                      lastResult.outcome === 'VALID'
                        ? 'text-[#15803D] dark:text-emerald-400'
                        : lastResult.outcome === 'ALREADY'
                          ? 'text-[#B45309] dark:text-amber-400'
                          : 'text-[#C01E30] dark:text-[#F87171]'
                    }`}
                  >
                    {lastResult.outcome === 'VALID'
                      ? 'VALID CHECK-IN'
                      : lastResult.outcome === 'ALREADY'
                        ? 'ALREADY CHECKED-IN'
                        : 'INVALID TICKET'}
                  </span>
                </div>

                {lastResult.registration && (
                  <div className="text-sm space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="font-semibold text-[var(--color-2-mood)]">
                        {lastResult.registration.attendeeName}
                      </p>
                      <StatusBadge
                        label={lastResult.registration.trackName || 'General Attendee'}
                        tone="obsidian"
                      />
                    </div>
                    <p className="text-xs font-mono-data text-[var(--ink-secondary)]">
                      {lastResult.registration.ticketToken} · {lastResult.registration.enrollmentNo}
                    </p>
                  </div>
                )}
                <p className="text-xs text-[var(--ink-secondary)] leading-relaxed">{lastResult.message}</p>
              </div>
            )}
          </div>

          <div className="studio-card p-6 space-y-3">
            <h3 className="text-sm font-display font-semibold text-[var(--color-2-mood)]">
              Session Scan Log
            </h3>
            {scanHistory.length === 0 ? (
              <p className="text-xs text-[var(--ink-muted)]">No scans recorded in this session yet.</p>
            ) : (
              <div className="divide-y divide-[var(--border-hairline)]">
                {scanHistory.map((item, i) => (
                  <div key={`${item.token}-${i}`} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                    <div className="min-w-0">
                      <p className="font-medium text-[var(--color-2-mood)] truncate">
                        {item.attendee}
                        {item.category ? ` · ${item.category}` : ''}
                      </p>
                      <p className="font-mono-data text-[11px] text-[var(--ink-muted)] truncate">{item.token}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <StatusBadge
                        label={item.outcome}
                        tone={
                          item.outcome === 'VALID'
                            ? 'green'
                            : item.outcome === 'ALREADY'
                              ? 'amber'
                              : 'crimson'
                        }
                      />
                      <p className="font-mono-data text-[10px] text-[var(--ink-muted)] mt-1">{item.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export const RegistrationsExportPage: React.FC<{ eventId: string }> = ({ eventId }) => {
  const { events, registrations, tasks, users, verifyRegistrationPayment, pushToast } = usePortal();
  const evt = events.find((e) => e.id === eventId) ?? events[0];
  const isLocked = evt?.status === 'Closed';

  const [search, setSearch] = useState('');
  const [trackFilter, setTrackFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [checkinFilter, setCheckinFilter] = useState<string>('ALL');
  const [inspectedReg, setInspectedReg] = useState<Registration | null>(null);

  const allEventRegs = useMemo(
    () => registrations.filter((r) => r.eventId === evt?.id),
    [registrations, evt?.id]
  );

  // Build category list from event tracks plus any legacy/historical registration categories
  const categoryOptions = useMemo(() => {
    const map = new Map<string, string>();
    if (evt) {
      getEffectiveTracks(evt).forEach((t) => map.set(t.name, t.name));
    }
    allEventRegs.forEach((r) => {
      const label = r.trackName || 'General Attendee';
      map.set(label, label);
    });
    return Array.from(map.values());
  }, [evt, allEventRegs]);

  // Live derived category summary ledger
  const categoryBreakdown = useMemo(() => {
    return categoryOptions.map((catName) => {
      const matching = allEventRegs.filter(
        (r) => (r.trackName || 'General Attendee') === catName
      );
      const pending = matching.filter(
        (r) => r.paymentStatus === 'Pending Payment Verification'
      ).length;
      const checkedIn = matching.filter((r) => r.checkInStatus === 'Checked In').length;
      const verifiedRevenue = matching
        .filter((r) => r.paymentStatus === 'Verified')
        .reduce((sum, r) => {
          const amt =
            r.pricingSnapshot?.amountInr ??
            r.amountInr ??
            (evt?.isPaid ? evt.feeInr : 0);
          return sum + amt;
        }, 0);
      return {
        name: catName,
        total: matching.length,
        pending,
        checkedIn,
        verifiedRevenue,
      };
    });
  }, [categoryOptions, allEventRegs, evt]);

  const eventRegs = useMemo(() => {
    const q = search.trim().toLowerCase();
    return allEventRegs.filter((r) => {
      const catLabel = r.trackName || 'General Attendee';
      if (trackFilter !== 'ALL' && catLabel !== trackFilter) return false;
      if (statusFilter !== 'ALL' && r.paymentStatus !== statusFilter) return false;
      if (checkinFilter !== 'ALL' && r.checkInStatus !== checkinFilter) return false;
      if (
        q &&
        !r.attendeeName.toLowerCase().includes(q) &&
        !r.ticketToken.toLowerCase().includes(q) &&
        !(r.utrNumber ?? '').toLowerCase().includes(q) &&
        !r.enrollmentNo.toLowerCase().includes(q) &&
        !catLabel.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [allEventRegs, search, trackFilter, statusFilter, checkinFilter]);

  const resolveFeeLabel = (r: Registration) => {
    const amt =
      r.pricingSnapshot?.amountInr ??
      r.amountInr ??
      (r.paymentStatus === 'Free' ? 0 : evt?.isPaid ? evt.feeInr : 0);
    return amt > 0 ? `₹${amt}` : 'Free';
  };

  const handleExportAttendees = () => {
    downloadCsvFile(
      `${evt?.slug ?? 'event'}-attendees.csv`,
      [
        'Ticket Token',
        'Attendee Name',
        'Email',
        'Enrollment No',
        'Participant Category',
        'Fee (INR)',
        'Payment Status',
        'UTR Reference',
        'Check-in Status',
        'Checked In At',
        'Seat Slot',
        'Category Form Responses',
      ],
      eventRegs.map((r) => {
        const feeVal =
          r.pricingSnapshot?.amountInr ??
          r.amountInr ??
          (r.paymentStatus === 'Free' ? 0 : evt?.isPaid ? evt.feeInr : 0);
        const serializedResponses = r.formResponses
          ? Object.values(r.formResponses)
              .map((resp) => `${resp.label}: ${formatRegistrationAnswer(resp.value)}`)
              .join(' | ')
          : '';
        return [
          r.ticketToken,
          r.attendeeName,
          r.attendeeEmail,
          r.enrollmentNo,
          r.trackName || 'General Attendee',
          String(feeVal),
          r.paymentStatus,
          r.utrNumber ?? '',
          r.checkInStatus,
          r.checkedInAt ?? '',
          r.seatSlot,
          serializedResponses,
        ];
      })
    );
    pushToast('Attendees CSV exported', `${eventRegs.length} records downloaded.`, 'success');
  };

  const handleExportTasks = () => {
    const eventTasks = tasks.filter((t) => t.eventId === evt?.id);
    downloadCsvFile(
      `${evt?.slug ?? 'event'}-task-allocations.csv`,
      ['Task ID', 'Operational Unit', 'Title', 'Assigned Member', 'Deadline', 'Status'],
      eventTasks.map((t) => [
        t.id,
        t.teamCode,
        t.title,
        users.find((u) => u.id === t.assigneeId)?.name ?? 'Unassigned',
        t.deadline,
        t.status,
      ])
    );
    pushToast('Task Allocations CSV exported', `${eventTasks.length} rows downloaded.`, 'success');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">
            Attendee Ledger &amp; Multi-Track Reconciliation
          </p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Registrations &amp; Exports · {evt?.title}
          </h1>
        </div>

        {/* Export Toolbar */}
        <div className="flex flex-wrap items-center gap-2.5">
          <StudioButton variant="secondary" size="sm" onClick={handleExportTasks}>
            <FileSpreadsheet className="h-4 w-4" />
            <span>Export Task Allocations (CSV)</span>
          </StudioButton>
          <StudioButton variant="primary" size="sm" onClick={handleExportAttendees}>
            <Download className="h-4 w-4" />
            <span>Export Attendees (CSV/Excel)</span>
          </StudioButton>
        </div>
      </div>

      {/* Category-Wise Operational Breakdown (Derived live from registrations) */}
      {categoryBreakdown.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {categoryBreakdown.map((item) => {
            const active = trackFilter === item.name;
            return (
              <button
                key={item.name}
                type="button"
                onClick={() => setTrackFilter(active ? 'ALL' : item.name)}
                className={`studio-card p-4 text-left transition-colors cursor-pointer ${
                  active ? 'border-[#C01E30] bg-[var(--accent-soft)]' : 'hover:border-[var(--border-strong)]'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs font-semibold text-[var(--color-2-mood)] truncate">
                    {item.name}
                  </p>
                  <span className="font-mono text-base font-semibold text-[var(--color-2-mood)]">
                    {item.total}
                  </span>
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-mono text-[var(--ink-muted)]">
                  <span>{item.checkedIn} checked in</span>
                  {item.pending > 0 && (
                    <span className="text-[#B45309] dark:text-amber-300">
                      {item.pending} pending UTR
                    </span>
                  )}
                  {item.verifiedRevenue > 0 && (
                    <span className="text-[#15803D] dark:text-emerald-400">
                      ₹{item.verifiedRevenue.toLocaleString('en-IN')} verified
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center">
          <GooeySearch
            items={allEventRegs.map((r) => `${r.attendeeName} · ${r.ticketToken}`)}
            value={search}
            onQueryChange={setSearch}
            buttonLabel="Find Attendee"
            placeholder="Name, token, category, or UTR..."
            onSelect={(item) => setSearch(item.split(' · ')[0] ?? item)}
          />
        </div>
        <SelectDropdown
          value={trackFilter}
          onChange={setTrackFilter}
          size="xs"
          align="end"
          className="w-auto min-w-[180px]"
          menuLabel="Participant Category"
          options={[
            { value: 'ALL', label: 'All Categories' },
            ...categoryOptions.map((cat) => ({ value: cat, label: cat })),
          ]}
        />
        <SelectDropdown
          value={statusFilter}
          onChange={setStatusFilter}
          size="xs"
          align="end"
          className="w-auto min-w-[195px]"
          menuLabel="Payment Status"
          options={[
            { value: 'ALL', label: 'All Payment Statuses' },
            { value: 'Pending Payment Verification', label: 'Pending Payment Verification' },
            { value: 'Verified', label: 'Verified' },
            { value: 'Free', label: 'Free' },
            { value: 'Rejected', label: 'Rejected' },
          ]}
        />
        <SelectDropdown
          value={checkinFilter}
          onChange={setCheckinFilter}
          size="xs"
          align="end"
          className="w-auto min-w-[160px]"
          menuLabel="Check-in Status"
          options={[
            { value: 'ALL', label: 'All Check-in States' },
            { value: 'Checked In', label: 'Checked In' },
            { value: 'Not Checked In', label: 'Not Checked In' },
          ]}
        />
      </div>

      {/* Searchable Table */}
      <div className="studio-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-[var(--surface-subtle)] border-b border-[var(--border-hairline)] text-[11px] font-semibold text-[var(--ink-muted)]">
                <th className="py-3 px-4">Attendee</th>
                <th className="py-3 px-4">Category &amp; Fee</th>
                <th className="py-3 px-4">Ticket / UTR</th>
                <th className="py-3 px-4">Payment Status</th>
                <th className="py-3 px-4">Check-in</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border-hairline)] text-sm">
              {eventRegs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-xs text-[var(--ink-muted)]">
                    No registrations match your filter criteria.
                  </td>
                </tr>
              ) : (
                eventRegs.map((reg) => {
                  const responseCount = reg.formResponses
                    ? Object.keys(reg.formResponses).length
                    : 0;
                  return (
                    <tr key={reg.id} className="hover:bg-[var(--surface-subtle)]/60">
                      <td className="py-3 px-4">
                        <p className="font-medium text-[var(--color-2-mood)]">{reg.attendeeName}</p>
                        <p className="text-xs text-[var(--ink-muted)]">
                          {reg.enrollmentNo} · {reg.attendeeEmail}
                        </p>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex flex-col items-start gap-1">
                          <StatusBadge
                            label={reg.trackName || 'General Attendee'}
                            tone="neutral"
                          />
                          <span className="font-mono-data text-[11px] text-[var(--ink-muted)]">
                            {resolveFeeLabel(reg)}
                            {responseCount > 0 ? ` · ${responseCount} responses` : ''}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono-data text-xs text-[var(--color-2-mood)]">
                        <div>{reg.ticketToken}</div>
                        <div className="text-[11px] text-[var(--ink-muted)]">
                          UTR: {reg.utrNumber ?? '—'}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <StatusBadge
                          label={reg.paymentStatus}
                          tone={
                            reg.paymentStatus === 'Verified' || reg.paymentStatus === 'Free'
                              ? 'green'
                              : reg.paymentStatus === 'Pending Payment Verification'
                                ? 'amber'
                                : 'crimson'
                          }
                        />
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-xs text-[var(--ink-secondary)]">
                          {reg.checkInStatus}
                          {reg.checkedInAt && (
                            <span className="block font-mono-data text-[11px] text-[var(--ink-muted)]">
                              {reg.checkedInAt}
                            </span>
                          )}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="inline-flex flex-wrap items-center justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setInspectedReg(reg)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-[6px] border border-[var(--border-hairline)] bg-[var(--surface)] text-xs font-medium text-[var(--color-2-mood)] hover:bg-[var(--surface-subtle)] cursor-pointer"
                          >
                            <span>Inspect</span>
                          </button>
                          {reg.paymentStatus !== 'Free' && (
                            <>
                              <button
                                type="button"
                                disabled={isLocked || reg.paymentStatus === 'Verified'}
                                onClick={() => verifyRegistrationPayment(reg.id, 'Verified')}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-[6px] border border-[#BBF7D0] dark:border-emerald-800/70 bg-[#ECFDF3] dark:bg-emerald-950/50 text-[#15803D] dark:text-emerald-400 text-xs font-medium hover:bg-[#DCFCE7] dark:hover:bg-emerald-900/60 disabled:opacity-40 cursor-pointer"
                              >
                                <Check className="h-3.5 w-3.5" />
                                <span>Approve</span>
                              </button>
                              <button
                                type="button"
                                disabled={isLocked || reg.paymentStatus === 'Rejected'}
                                onClick={() => verifyRegistrationPayment(reg.id, 'Rejected')}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-[6px] border border-[var(--accent-border)] bg-[var(--accent-soft)] text-[#C01E30] dark:text-[#F87171] text-xs font-medium hover:opacity-85 disabled:opacity-40 cursor-pointer"
                              >
                                <X className="h-3.5 w-3.5" />
                                <span>Reject</span>
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Registration Details & Category Form Response Inspector */}
      <ModalDialog
        open={Boolean(inspectedReg)}
        onClose={() => setInspectedReg(null)}
        title={inspectedReg ? `${inspectedReg.attendeeName} — Registration Record` : 'Record'}
        subtitle={
          inspectedReg
            ? `${inspectedReg.trackName || 'General Attendee'} · ${inspectedReg.ticketToken}`
            : undefined
        }
        maxWidthClass="max-w-xl"
      >
        {inspectedReg && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 p-3.5 rounded-[8px] bg-[var(--surface-subtle)] border border-[var(--border-hairline)] text-xs">
              <div>
                <p className="text-[var(--ink-muted)]">Category</p>
                <p className="font-semibold text-[var(--color-2-mood)] mt-0.5">
                  {inspectedReg.trackName || 'General Attendee'}
                </p>
              </div>
              <div>
                <p className="text-[var(--ink-muted)]">Fee Snapshot</p>
                <p className="font-mono font-semibold text-[var(--color-2-mood)] mt-0.5">
                  {resolveFeeLabel(inspectedReg)}
                </p>
              </div>
              <div>
                <p className="text-[var(--ink-muted)]">Email / Enrollment</p>
                <p className="text-[var(--color-2-mood)] mt-0.5 truncate">
                  {inspectedReg.attendeeEmail}
                </p>
                <p className="font-mono text-[11px] text-[var(--ink-muted)]">
                  {inspectedReg.enrollmentNo}
                </p>
              </div>
              <div>
                <p className="text-[var(--ink-muted)]">Payment / UTR</p>
                <p className="font-semibold text-[var(--color-2-mood)] mt-0.5">
                  {inspectedReg.paymentStatus}
                </p>
                {inspectedReg.utrNumber && (
                  <p className="font-mono text-[11px] text-[var(--ink-muted)]">
                    UTR {inspectedReg.utrNumber}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2.5">
              <p className="text-xs font-semibold text-[var(--color-2-mood)]">
                Category-Specific Form Responses
              </p>
              {inspectedReg.formResponses &&
              Object.keys(inspectedReg.formResponses).length > 0 ? (
                <dl className="divide-y divide-[var(--border-hairline)] border border-[var(--border-hairline)] rounded-[8px] px-4 text-xs">
                  {Object.values(inspectedReg.formResponses).map((resp) => {
                    const isFile =
                      resp.type === 'file' &&
                      typeof resp.value === 'object' &&
                      resp.value !== null &&
                      'assetRef' in resp.value;
                    const fileRef = isFile ? (resp.value as UploadedFileRef) : null;
                    return (
                      <div
                        key={resp.fieldId}
                        className="py-2.5 flex flex-col sm:flex-row sm:items-start justify-between gap-1 sm:gap-4"
                      >
                        <dt className="text-[var(--ink-muted)] shrink-0">{resp.label}</dt>
                        <dd className="text-[var(--color-2-mood)] font-medium sm:text-right break-words">
                          {fileRef ? (
                            <button
                              type="button"
                              onClick={async () => {
                                const ok = await downloadStoredDocument(fileRef);
                                if (!ok) {
                                  pushToast(
                                    'Attachment unavailable',
                                    'Uploaded file exists only in the browser IndexedDB where it was submitted.',
                                    'warning'
                                  );
                                }
                              }}
                              className="inline-flex items-center gap-1.5 text-[#C01E30] dark:text-[#E67C87] hover:underline cursor-pointer"
                            >
                              <Paperclip className="h-3.5 w-3.5" />
                              <span>
                                {fileRef.name} ({formatBytes(fileRef.size)})
                              </span>
                            </button>
                          ) : (
                            formatRegistrationAnswer(resp.value)
                          )}
                        </dd>
                      </div>
                    );
                  })}
                </dl>
              ) : (
                <p className="text-xs text-[var(--ink-muted)] p-3 rounded-[8px] bg-[var(--surface-subtle)] border border-dashed border-[var(--border-hairline)]">
                  No additional category-specific responses recorded for this registration.
                </p>
              )}
            </div>
          </div>
        )}
      </ModalDialog>
    </div>
  );
};

export const EventClosurePage: React.FC<{ eventId: string }> = ({ eventId }) => {
  const {
    events,
    updateClosureChecklist,
    issueEventCertificates,
    closeEventWithLock,
    reopenEventWithAudit,
  } = usePortal();

  const evt = events.find((e) => e.id === eventId) ?? events[0];
  const [reportUrl, setReportUrl] = useState(evt?.reportDriveUrl ?? '');
  const [reopenModalOpen, setReopenModalOpen] = useState(false);
  const [auditReason, setAuditReason] = useState('');

  if (!evt) return null;

  const isClosed = evt.status === 'Closed';
  const checklist = evt.closureChecklist;
  const allGatesPassed =
    checklist.attendanceFinalized &&
    checklist.paymentsVerified &&
    checklist.tasksResolved &&
    checklist.reportUploaded &&
    checklist.certificatesIssued;

  const checklistRows: {
    key: keyof typeof checklist;
    title: string;
    detail: string;
  }[] = [
    {
      key: 'attendanceFinalized',
      title: 'Finalize Attendance Records',
      detail: 'Confirm all RD desk QR check-ins and manual entries are reconciled.',
    },
    {
      key: 'paymentsVerified',
      title: 'Verify All UPI / UTR Payments',
      detail: 'Approve or reject every pending transaction reference in the registration ledger.',
    },
    {
      key: 'tasksResolved',
      title: 'Complete or Archive Outstanding Tasks',
      detail: 'Ensure all 12 operational units have signed off on final deliverables.',
    },
    {
      key: 'reportUploaded',
      title: 'Upload Final Event Report Link (Google Drive)',
      detail: 'Attach IIC & AIIH institutional archival report URL below.',
    },
    {
      key: 'certificatesIssued',
      title: 'Issue Verified Participant & Organizer Certificates',
      detail: 'Publish signed credentials into the Participant Portal.',
    },
  ];

  const handleSaveReport = () => {
    updateClosureChecklist(
      evt.id,
      { reportUploaded: Boolean(reportUrl.trim()) },
      reportUrl.trim()
    );
  };

  const handleReopenSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (auditReason.trim().length < 10) return;
    reopenEventWithAudit(evt.id, auditReason);
    setAuditReason('');
    setReopenModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Governance &amp; Archival Lock</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Event Closure &amp; Permanent Records · {evt.title}
          </h1>
        </div>
        <StatusBadge
          label={isClosed ? 'Locked · Read-Only Archive' : 'Active Operations'}
          tone={isClosed ? 'obsidian' : 'green'}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-8 studio-card p-6 space-y-6">
          <div>
            <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
              Pre-Closure Compliance Checklist
            </h2>
            <p className="text-xs text-[var(--ink-muted)] mt-0.5">
              Every compliance gate must be verified before activating the permanent read-only lock.
            </p>
          </div>

          <div className="divide-y divide-[var(--border-hairline)]">
            {checklistRows.map((row) => {
              const checked = checklist[row.key];
              return (
                <div key={row.key} className="py-4 first:pt-0 flex items-start justify-between gap-4">
                  <label className="flex items-start gap-3 cursor-pointer">
                    <input
                      type="checkbox"
                      disabled={isClosed}
                      checked={checked}
                      onChange={(e) =>
                        updateClosureChecklist(evt.id, { [row.key]: e.target.checked })
                      }
                      className="mt-1 h-4 w-4 accent-[#C01E30]"
                    />
                    <div>
                      <p className="text-sm font-medium text-[var(--color-2-mood)]">{row.title}</p>
                      <p className="text-xs text-[var(--ink-muted)] mt-0.5">{row.detail}</p>
                    </div>
                  </label>
                  <StatusBadge label={checked ? 'Done' : 'Pending'} tone={checked ? 'green' : 'neutral'} />
                </div>
              );
            })}
          </div>

          {/* Google Drive Final Report & Certificate Issuance */}
          <div className="pt-4 border-t border-[var(--border-hairline)] space-y-4">
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                Final Event Report Link (Google Drive)
              </label>
              <div className="flex flex-col sm:flex-row gap-2">
                <input
                  type="url"
                  disabled={isClosed}
                  value={reportUrl}
                  onChange={(e) => setReportUrl(e.target.value)}
                  placeholder="https://drive.google.com/drive/folders/..."
                  className="studio-input text-xs flex-1"
                />
                <StudioButton
                  type="button"
                  variant="secondary"
                  size="sm"
                  disabled={isClosed}
                  onClick={handleSaveReport}
                >
                  Save Link
                </StudioButton>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <StudioButton
                type="button"
                variant="secondary"
                size="sm"
                disabled={isClosed}
                onClick={() => issueEventCertificates(evt.id)}
              >
                <Award className="h-4 w-4 text-[#C01E30] dark:text-[#F87171]" />
                <span>Issue Verified Certificates</span>
              </StudioButton>

              {!isClosed ? (
                <StudioButton
                  type="button"
                  variant="primary"
                  disabled={!allGatesPassed}
                  onClick={() => closeEventWithLock(evt.id)}
                >
                  <Lock className="h-4 w-4" />
                  <span>Close &amp; Lock Event Record</span>
                </StudioButton>
              ) : (
                <StudioButton
                  type="button"
                  variant="obsidian"
                  onClick={() => setReopenModalOpen(true)}
                >
                  <Unlock className="h-4 w-4" />
                  <span>Reopen with Audit Reason</span>
                </StudioButton>
              )}
            </div>
            {!allGatesPassed && !isClosed && (
              <p className="text-xs text-[var(--ink-muted)]">
                Complete all 5 checklist gates above to enable the Closure Lock button.
              </p>
            )}
          </div>
        </div>

        {/* Permanent Audit Trail */}
        <aside className="lg:col-span-4 studio-card p-6 space-y-4">
          <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
            Permanent Audit Trail
          </h2>
          {evt.auditTrail.length === 0 ? (
            <p className="text-xs text-[var(--ink-muted)] leading-relaxed">
              No lock or reopen events logged yet. Closing or reopening this event writes an immutable entry here.
            </p>
          ) : (
            <div className="space-y-3">
              {evt.auditTrail.map((entry) => (
                <div
                  key={entry.id}
                  className="p-3.5 rounded-[9px] bg-[var(--color-1-mood)] border border-[var(--border-hairline)] space-y-1.5"
                >
                  <div className="flex items-center justify-between gap-2">
                    <StatusBadge
                      label={entry.action}
                      tone={entry.action === 'Closed' ? 'obsidian' : 'amber'}
                    />
                    <span className="font-mono-data text-[10px] text-[var(--ink-muted)]">{entry.timestamp}</span>
                  </div>
                  <p className="text-xs font-semibold text-[var(--color-2-mood)]">{entry.actorName}</p>
                  <p className="text-xs text-[var(--ink-secondary)] leading-relaxed">{entry.reason}</p>
                </div>
              ))}
            </div>
          )}
        </aside>
      </div>

      {/* Mandatory Audit Reason Modal */}
      <ModalDialog
        open={reopenModalOpen}
        onClose={() => setReopenModalOpen(false)}
        title="Reopen Closed Event Record"
        subtitle="Reopening a locked institutional record requires an official mandatory audit justification."
      >
        <form onSubmit={handleReopenSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
              Official Audit Reason (Minimum 10 characters)
            </label>
            <textarea
              rows={4}
              required
              minLength={10}
              value={auditReason}
              onChange={(e) => setAuditReason(e.target.value)}
              placeholder="e.g. Late UTR reconciliation approved by Faculty Advisor for 3 external college delegates."
              className="studio-input"
            />
          </div>
          <div className="flex justify-end gap-2">
            <StudioButton type="button" variant="secondary" onClick={() => setReopenModalOpen(false)}>
              Cancel
            </StudioButton>
            <StudioButton type="submit" variant="primary" disabled={auditReason.trim().length < 10}>
              Log Reason &amp; Reopen Event
            </StudioButton>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
};
