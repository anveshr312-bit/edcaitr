import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowUpRight,
  CalendarPlus,
  Check,
  ClipboardCheck,
  KanbanSquare,
  Lock,
  QrCode,
  Search,
  Upload,
  Users,
} from 'lucide-react';
import { usePortal } from '../../context/PortalContext';
import { EDITORIAL_IMAGES, OPERATIONAL_TEAMS } from '../../data/seedData';
import {
  EventCategory,
  EventRegistrationTrack,
  EventThumbnailMeta,
  OperationalTeamCode,
} from '../../types/portal';
import {
  EditorialImage,
  MonogramAvatar,
  StatusBadge,
  StudioButton,
} from '../../components/ui/Primitives';
import { RollingStat } from '../../components/ui/RollingStat';
import { GooeySearch } from '../../components/ui/GooeySearch';
import { SelectDropdown } from '../../components/ui/dropdown-menu';
import { AnimatedContent } from '../../components/ui/AnimatedContent';
import { EventThumbnailUploader } from '../../components/workspace/EventThumbnailUploader';
import { TrackRegistrationBuilder } from '../../components/workspace/TrackRegistrationBuilder';
import { validateTrackForBuilder } from '../../utils/eventTracks';

export const WorkspaceDashboardPage: React.FC = () => {
  const {
    events,
    registrations,
    tasks,
    applications,
    activeWorkspaceEventId,
    setActiveWorkspaceEventId,
    navigate,
  } = usePortal();

  const activeEvent = events.find((e) => e.id === activeWorkspaceEventId) ?? events[0];
  const eventRegs = registrations.filter((r) => r.eventId === activeEvent?.id);
  const checkedInCount = eventRegs.filter((r) => r.checkInStatus === 'Checked In').length;
  const checkedInPct = eventRegs.length > 0 ? Math.round((checkedInCount / eventRegs.length) * 100) : 0;
  const pendingUtr = eventRegs.filter((r) => r.paymentStatus === 'Pending Payment Verification').length;

  const eventTasks = tasks.filter((t) => t.eventId === activeEvent?.id);
  const overdueTasks = eventTasks.filter(
    (t) => t.status !== 'Approved' && t.deadline < '2026-03-15'
  ).length;
  const pendingTaskReviews = eventTasks.filter(
    (t) => t.status === 'Submitted' || t.status === 'Changes Requested'
  ).length;
  const pendingApps = applications.filter((a) => a.status === 'Pending').length;

  const kpis = [
    {
      label: 'Registrations Count',
      value: String(eventRegs.length),
      sub: activeEvent?.capacity ? `of ${activeEvent.capacity} max capacity` : 'Unlimited capacity',
    },
    {
      label: 'Checked-In Ratio',
      value: `${checkedInPct}%`,
      sub: `${checkedInCount} of ${eventRegs.length} delegates scanned`,
    },
    {
      label: 'Overdue / Critical Tasks',
      value: String(overdueTasks),
      sub: `${eventTasks.length} total tasks across 12 teams`,
    },
    {
      label: 'Pending Reviews',
      value: String(pendingUtr + pendingTaskReviews + pendingApps),
      sub: `${pendingUtr} UTR · ${pendingTaskReviews} tasks · ${pendingApps} apps`,
    },
  ];

  const workspaceModules = [
    {
      title: 'Event Builder & Settings',
      detail: 'Configure dates, venue, INR UPI fees, QR codes, and primary/secondary SPOCs.',
      href: `/workspace/events/${activeEvent?.id}`,
      icon: CalendarPlus,
    },
    {
      title: '12-Team Operational Roster',
      detail: 'Allocate Core Team leads and members across RD, AV, STAGE, LOGISTICS, and 8 more units.',
      href: `/workspace/events/${activeEvent?.id}/teams`,
      icon: Users,
    },
    {
      title: 'Task Management Kanban',
      detail: 'Track deliverables from To Do through Submitted and Approved with threaded comments.',
      href: `/workspace/events/${activeEvent?.id}/tasks`,
      icon: KanbanSquare,
    },
    {
      title: 'RD QR Check-in Console',
      detail: 'Live gate camera viewfinder, manual ticket lookup, and instant check-in validation.',
      href: `/workspace/events/${activeEvent?.id}/checkin`,
      icon: QrCode,
    },
    {
      title: 'Registrations, UTR & CSV Exports',
      detail: 'Approve or reject manual UPI transaction proofs and download attendee/task CSVs.',
      href: `/workspace/events/${activeEvent?.id}/registrations`,
      icon: ClipboardCheck,
    },
    {
      title: 'Event Closure & Audit Records',
      detail: 'Complete pre-closure checklist, issue verified certificates, and lock archival records.',
      href: `/workspace/events/${activeEvent?.id}/closure`,
      icon: Lock,
    },
  ];

  return (
    <div className="space-y-8">
      {/* Command Header + Active Event Selector */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Operational Command Center</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Team Workspace
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <label htmlFor="active-event-select" className="text-xs font-medium text-[var(--ink-muted)] whitespace-nowrap">
              Active Event:
            </label>
            <SelectDropdown
              id="active-event-select"
              value={activeEvent?.id ?? ''}
              onChange={setActiveWorkspaceEventId}
              size="sm"
              align="end"
              className="min-w-[230px]"
              menuLabel="Workspace Events"
              options={events.map((evt) => ({
                value: evt.id,
                label: `${evt.title} (${evt.status})`,
              }))}
            />
          </div>
          <StudioButton variant="primary" size="sm" onClick={() => navigate('/workspace/events/new')}>
            <CalendarPlus className="h-4 w-4" />
            <span>New Event</span>
          </StudioButton>
        </div>
      </div>

      {activeEvent?.status === 'Closed' && (
        <div className="bg-[#FFFBEB] dark:bg-amber-950/40 border border-[#FDE68A] dark:border-amber-800/70 rounded-[9px] px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 text-sm text-[#B45309] dark:text-amber-300">
            <Lock className="h-4 w-4 shrink-0" />
            <span>
              <strong>{activeEvent.title}</strong> is closed and locked in read-only archival mode.
            </span>
          </div>
          <StudioButton
            variant="secondary"
            size="sm"
            onClick={() => navigate(`/workspace/events/${activeEvent.id}/closure`)}
          >
            Inspect Closure Audit
          </StudioButton>
        </div>
      )}

      {/* KPI Strip */}
      <AnimatedContent
        trigger="mount"
        distance={24}
        duration={0.55}
        stagger={0.06}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {kpis.map((kpi) => (
          <div key={kpi.label} className="studio-card p-5 space-y-1.5 hover:border-[#C01E30]/40 hover:-translate-y-0.5 transition-all duration-200">
            <p className="text-xs font-medium text-[var(--ink-muted)]">{kpi.label}</p>
            <p className="font-mono-data text-3xl font-semibold text-[var(--color-2-mood)]">
              <RollingStat value={kpi.value} />
            </p>
            <p className="text-xs text-[var(--ink-secondary)]">{kpi.sub}</p>
          </div>
        ))}
      </AnimatedContent>

      {/* Operational Console Grid */}
      <AnimatedContent
        trigger="mount"
        distance={28}
        duration={0.6}
        delay={0.08}
        stagger={0.055}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
      >
        {workspaceModules.map((mod) => {
          const Icon = mod.icon;
          return (
            <button
              key={mod.title}
              type="button"
              onClick={() => navigate(mod.href)}
              className="studio-card p-5 text-left flex flex-col justify-between gap-4 hover:border-[#C01E30] hover:-translate-y-0.5 transition-all duration-200 cursor-pointer group"
            >
              <div className="flex items-center justify-between">
                <div className="h-9 w-9 rounded-[9px] bg-[var(--surface-subtle)] border border-[var(--border-hairline)] flex items-center justify-center text-[var(--color-2-mood)] group-hover:bg-[var(--accent-soft)] group-hover:text-[#C01E30] dark:group-hover:text-[#F87171] transition-colors">
                  <Icon className="h-4 w-4" strokeWidth={1.75} />
                </div>
                <ArrowUpRight className="h-4 w-4 text-[var(--ink-muted)] group-hover:text-[#C01E30] dark:group-hover:text-[#F87171] group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
              </div>
              <div>
                <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">{mod.title}</h2>
                <p className="text-xs text-[var(--ink-muted)] leading-relaxed mt-1">{mod.detail}</p>
              </div>
            </button>
          );
        })}
      </AnimatedContent>
    </div>
  );
};

export const EventBuilderPage: React.FC<{ eventId?: string }> = ({ eventId }) => {
  const { events, registrations, users, saveEvent, navigate, pushToast } = usePortal();
  const isNew = !eventId || eventId === 'new';
  const existing = !isNew ? events.find((e) => e.id === eventId) : undefined;
  const isLocked = existing?.status === 'Closed';

  const coreRoster = users.filter(
    (u) => u.role === 'core_team' || u.role === 'advisor' || u.role === 'director'
  );

  const [title, setTitle] = useState(existing?.title ?? '');
  const [subtitle, setSubtitle] = useState(existing?.subtitle ?? '');
  const [category, setCategory] = useState<EventCategory>(existing?.category ?? 'Conclaves');
  const [startDate, setStartDate] = useState(existing?.startDate ?? '2026-04-20');
  const [endDate, setEndDate] = useState(existing?.endDate ?? '2026-04-21');
  const [venue, setVenue] = useState(existing?.venue ?? 'Main Auditorium, AITR Indore');
  const [description, setDescription] = useState(existing?.description ?? '');
  const [unlimited, setUnlimited] = useState(existing ? existing.capacity === null : false);
  const [capacity, setCapacity] = useState(String(existing?.capacity ?? 300));

  // Thumbnail state (retains existing cover on edit without forcing re-upload)
  const [bannerImage, setBannerImage] = useState(
    existing?.bannerImage ?? EDITORIAL_IMAGES.summitStage
  );
  const [bannerAlt, setBannerAlt] = useState(existing?.bannerAlt ?? '');
  const [bannerPosition, setBannerPosition] = useState(existing?.bannerPosition ?? '50% 50%');
  const [thumbnailMeta, setThumbnailMeta] = useState<EventThumbnailMeta | undefined>(
    existing?.thumbnailMeta
  );

  // Registration architecture state
  const [registrationMode, setRegistrationMode] = useState<'single' | 'multi'>(
    existing?.registrationMode === 'multi' || (existing?.tracks && existing.tracks.length > 1)
      ? 'multi'
      : 'single'
  );
  const [tracks, setTracks] = useState<EventRegistrationTrack[]>(existing?.tracks ?? []);
  const [isPaid, setIsPaid] = useState(existing?.isPaid ?? false);
  const [feeInr, setFeeInr] = useState(existing?.feeInr ?? 299);
  const [upiId, setUpiId] = useState(existing?.upiId ?? 'edcaitr.events@icici');

  const [spocSearch, setSpocSearch] = useState('');
  const [spocPrimaryId, setSpocPrimaryId] = useState(
    existing?.spocPrimaryId ?? coreRoster[0]?.id ?? ''
  );
  const [spocSecondaryId, setSpocSecondaryId] = useState(
    existing?.spocSecondaryId ?? coreRoster[1]?.id ?? ''
  );
  const [saving, setSaving] = useState(false);

  const registeredCountByTrackId = useMemo(() => {
    if (!existing) return {} as Record<string, number>;
    const counts: Record<string, number> = {};
    registrations
      .filter((r) => r.eventId === existing.id && r.paymentStatus !== 'Rejected')
      .forEach((r) => {
        const key = r.trackId || `default-${existing.id}`;
        counts[key] = (counts[key] ?? 0) + 1;
      });
    return counts;
  }, [existing, registrations]);

  const filteredSpocs = useMemo(() => {
    const q = spocSearch.trim().toLowerCase();
    if (!q) return coreRoster;
    return coreRoster.filter(
      (u) => u.name.toLowerCase().includes(q) || u.designation.toLowerCase().includes(q)
    );
  }, [coreRoster, spocSearch]);

  const publishValidationIssues = useMemo(() => {
    const issues: string[] = [];
    if (!title.trim()) issues.push('Event title is required.');
    if (!venue.trim()) issues.push('Venue is required.');
    if (startDate && endDate && endDate < startDate) {
      issues.push('End date cannot be earlier than start date.');
    }
    if (!unlimited && (Number.isNaN(Number(capacity)) || Number(capacity) < 1)) {
      issues.push('Overall capacity must be a positive number or set to unlimited.');
    }

    if (registrationMode === 'single') {
      if (isPaid) {
        if (Number.isNaN(feeInr) || feeInr <= 0) {
          issues.push('Paid single-track event requires a positive registration fee.');
        }
        if (!upiId.trim()) {
          issues.push('Paid single-track event requires an official UPI ID.');
        }
      }
    } else {
      const enabledTracks = tracks.filter((t) => t.enabled);
      if (tracks.length === 0 || enabledTracks.length === 0) {
        issues.push('Multi-track mode requires at least one enabled participant category.');
      }
      tracks.forEach((track) => {
        if (!track.enabled) return;
        const result = validateTrackForBuilder(
          track,
          tracks,
          registeredCountByTrackId[track.id] ?? 0
        );
        result.issues.forEach((msg) => {
          issues.push(`${track.name || 'Untitled track'}: ${msg}`);
        });
      });
    }
    return issues;
  }, [
    title,
    venue,
    startDate,
    endDate,
    unlimited,
    capacity,
    registrationMode,
    isPaid,
    feeInr,
    upiId,
    tracks,
    registeredCountByTrackId,
  ]);

  const previewPriceLabel = useMemo(() => {
    if (registrationMode === 'single') {
      return isPaid ? `₹${feeInr}` : 'Free';
    }
    const enabled = tracks.filter((t) => t.enabled);
    if (enabled.length === 0) return 'No active tracks';
    const hasFree = enabled.some((t) => t.pricing.type === 'free');
    const paidPrices = enabled
      .filter((t) => t.pricing.type === 'paid' && t.pricing.amountInr > 0)
      .map((t) => t.pricing.amountInr);
    if (hasFree && paidPrices.length > 0) return 'Free & Paid Options';
    if (paidPrices.length > 0) {
      const min = Math.min(...paidPrices);
      return new Set(paidPrices).size > 1 ? `From ₹${min}` : `₹${min}`;
    }
    return 'Free';
  }, [registrationMode, isPaid, feeInr, tracks]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLocked) return;
    if (publishValidationIssues.length > 0) {
      pushToast('Configuration incomplete', publishValidationIssues[0], 'warning');
      return;
    }

    setSaving(true);
    window.setTimeout(() => {
      const saved = saveEvent({
        id: existing?.id,
        title: title.trim(),
        subtitle:
          subtitle.trim() || 'Official entrepreneurship event by EDC AITR & AIIH Foundation.',
        category,
        startDate,
        endDate,
        dateLabel: startDate === endDate ? startDate : `${startDate} to ${endDate}`,
        venue: venue.trim(),
        description: description.trim() || subtitle.trim(),
        capacity: unlimited ? null : Math.max(1, Number(capacity) || 100),
        isPaid: registrationMode === 'single' ? isPaid : tracks.some((t) => t.enabled && t.pricing.type === 'paid'),
        feeInr: registrationMode === 'single' ? (isPaid ? Math.max(1, feeInr) : 0) : 0,
        upiId: upiId.trim(),
        qrPreviewLabel: existing?.qrPreviewLabel ?? `EDC AITR · ${title.trim().toUpperCase()}`,
        spocPrimaryId,
        spocSecondaryId,
        speakers: existing?.speakers ?? [
          {
            name: 'Dr. Atul Bharat',
            role: 'Director',
            organization: 'EDC AITR & AIIH Foundation',
            topic: 'Opening Institutional Keynote',
          },
        ],
        bannerImage,
        bannerAlt: bannerAlt.trim() || `${title.trim()} cover image`,
        bannerPosition,
        thumbnailMeta,
        registrationMode,
        tracks: registrationMode === 'multi' ? tracks : undefined,
        reportDriveUrl: existing?.reportDriveUrl ?? '',
      });
      setSaving(false);
      navigate(`/workspace/events/${saved.id}`);
    }, 280);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">
            Event Builder 2.0 · Multi-Track Architecture
          </p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            {isNew ? 'Create New Event' : `Edit Event · ${existing?.title}`}
          </h1>
        </div>
        {existing && (
          <StudioButton
            variant="secondary"
            size="sm"
            onClick={() => navigate(`/events/${existing.slug}`)}
          >
            <span>Preview Public Page</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </StudioButton>
        )}
      </div>

      {isLocked && (
        <div className="bg-[#FFFBEB] dark:bg-amber-950/40 border border-[#FDE68A] dark:border-amber-800/70 rounded-[9px] p-4 flex items-center gap-3 text-sm text-[#B45309] dark:text-amber-300">
          <AlertTriangle className="h-4 w-4 shrink-0" />
          <span>
            This event is closed and read-only. Reopen it from the Closure Console to edit
            configuration.
          </span>
        </div>
      )}

      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-8 space-y-6">
          {/* SECTION 1: EVENT DETAILS */}
          <section className="studio-card p-6 space-y-5">
            <div className="flex items-center justify-between gap-2 pb-3 border-b border-[var(--border-hairline)]">
              <div>
                <p className="font-mono text-[11px] uppercase tracking-wider text-[var(--ink-muted)]">
                  Step 01
                </p>
                <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
                  Event Identity, Dates &amp; Venue
                </h2>
              </div>
              <StatusBadge label={category} tone="neutral" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                  Event Title *
                </label>
                <input
                  type="text"
                  required
                  disabled={isLocked}
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. FOKUS X E-Summit 2026"
                  className="studio-input"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                  Short Subtitle
                </label>
                <input
                  type="text"
                  disabled={isLocked}
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  placeholder="One-line executive summary shown on event cards"
                  className="studio-input"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                  Event Series Category
                </label>
                <SelectDropdown
                  disabled={isLocked}
                  value={category}
                  onChange={(val) => setCategory(val as EventCategory)}
                  size="default"
                  className="w-full"
                  menuLabel="Event Category"
                  options={[
                    { value: 'Conclaves', label: 'Conclaves' },
                    { value: 'Hackathons', label: 'Hackathons' },
                    { value: 'Bootcamps', label: 'Bootcamps' },
                  ]}
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                  Campus Venue *
                </label>
                <input
                  type="text"
                  required
                  disabled={isLocked}
                  value={venue}
                  onChange={(e) => setVenue(e.target.value)}
                  className="studio-input"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                  Start Date *
                </label>
                <input
                  type="date"
                  required
                  disabled={isLocked}
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="studio-input font-mono-data"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                  End Date *
                </label>
                <input
                  type="date"
                  required
                  disabled={isLocked}
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="studio-input font-mono-data"
                />
              </div>

              <div className="sm:col-span-2">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-medium text-[var(--color-2-mood)]">
                    Overall Event Capacity Cap
                  </label>
                  <label className="inline-flex items-center gap-1.5 text-xs text-[var(--ink-secondary)] cursor-pointer">
                    <input
                      type="checkbox"
                      disabled={isLocked}
                      checked={unlimited}
                      onChange={(e) => setUnlimited(e.target.checked)}
                      className="accent-[#C01E30]"
                    />
                    <span>Unlimited overall seats</span>
                  </label>
                </div>
                <input
                  type="number"
                  min={1}
                  disabled={isLocked || unlimited}
                  value={unlimited ? '' : capacity}
                  onChange={(e) => setCapacity(e.target.value)}
                  placeholder="Unlimited seats"
                  className="studio-input font-mono-data"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                Full Institutional Description
              </label>
              <textarea
                rows={4}
                disabled={isLocked}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Outline tracks, speaker criteria, AIIH backing, and schedule expectations..."
                className="studio-input resize-y"
              />
            </div>
          </section>

          {/* SECTION 2: EVENT THUMBNAIL UPLOAD */}
          <section className="studio-card p-6 space-y-4">
            <div className="pb-3 border-b border-[var(--border-hairline)]">
              <p className="font-mono text-[11px] uppercase tracking-wider text-[var(--ink-muted)]">
                Step 02
              </p>
              <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
                Event Cover Thumbnail
              </h2>
              <p className="text-xs text-[var(--ink-muted)] mt-0.5">
                Displayed across the Public Events directory, Event detail hero, and homepage cards.
              </p>
            </div>

            <div className={isLocked ? 'pointer-events-none opacity-65' : ''}>
              <EventThumbnailUploader
                bannerImage={bannerImage}
                bannerAlt={bannerAlt}
                bannerPosition={bannerPosition}
                thumbnailMeta={thumbnailMeta}
                eventTitle={title}
                onChange={(patch) => {
                  if (patch.bannerImage !== undefined) setBannerImage(patch.bannerImage);
                  if (patch.bannerAlt !== undefined) setBannerAlt(patch.bannerAlt);
                  if (patch.bannerPosition !== undefined) setBannerPosition(patch.bannerPosition);
                  if ('thumbnailMeta' in patch) setThumbnailMeta(patch.thumbnailMeta);
                }}
              />
            </div>
          </section>

          {/* SECTION 3: MULTI-TRACK REGISTRATION ARCHITECTURE */}
          <section className="studio-card p-6 space-y-4">
            <div className="pb-3 border-b border-[var(--border-hairline)]">
              <p className="font-mono text-[11px] uppercase tracking-wider text-[var(--ink-muted)]">
                Step 03
              </p>
              <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
                Participant Categories, Pricing &amp; Forms
              </h2>
              <p className="text-xs text-[var(--ink-muted)] mt-0.5">
                Configure either a simple single-track flow or independent participant categories
                with custom forms, fees, UPI settings, and seat caps.
              </p>
            </div>

            <div className={isLocked ? 'pointer-events-none opacity-65' : ''}>
              <TrackRegistrationBuilder
                registrationMode={registrationMode}
                onModeChange={setRegistrationMode}
                tracks={tracks}
                onTracksChange={setTracks}
                defaultUpiId={upiId}
                eventTitle={title}
                registeredCountByTrackId={registeredCountByTrackId}
                singleIsPaid={isPaid}
                singleFeeInr={feeInr}
                singleUpiId={upiId}
                onSinglePricingChange={(patch) => {
                  if (patch.isPaid !== undefined) setIsPaid(patch.isPaid);
                  if (patch.feeInr !== undefined) setFeeInr(patch.feeInr);
                  if (patch.upiId !== undefined) setUpiId(patch.upiId);
                }}
              />
            </div>
          </section>

          {/* PUBLISH BAR */}
          <div className="studio-card p-5 space-y-3">
            {publishValidationIssues.length > 0 && (
              <div className="p-3 rounded-[8px] bg-[#FFFBEB] dark:bg-amber-950/40 border border-[#FDE68A] dark:border-amber-800/70 space-y-1">
                <p className="text-xs font-semibold text-[#B45309] dark:text-amber-300">
                  Resolve before publishing ({publishValidationIssues.length}):
                </p>
                <ul className="list-disc pl-4 space-y-0.5 text-xs text-[#B45309] dark:text-amber-200">
                  {publishValidationIssues.slice(0, 4).map((issue) => (
                    <li key={issue}>{issue}</li>
                  ))}
                </ul>
              </div>
            )}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-xs text-[var(--ink-muted)]">
                {registrationMode === 'multi'
                  ? `${tracks.filter((t) => t.enabled).length} enabled registration categories · ${previewPriceLabel}`
                  : `Single-track registration · ${previewPriceLabel}`}
              </p>
              <div className="flex items-center gap-2.5">
                <StudioButton type="button" variant="secondary" onClick={() => navigate('/workspace')}>
                  Back
                </StudioButton>
                <StudioButton
                  type="submit"
                  variant="primary"
                  loading={saving}
                  disabled={isLocked || publishValidationIssues.length > 0}
                >
                  {isNew ? 'Publish Event' : 'Save Configuration'}
                </StudioButton>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT SIDEBAR: LIVE PUBLIC CARD PREVIEW + SPOC SELECTOR */}
        <aside className="lg:col-span-4 space-y-5">
          {/* Live Public Card Preview */}
          <div className="studio-card overflow-hidden">
            <div className="px-4 py-3 border-b border-[var(--border-hairline)] flex items-center justify-between">
              <span className="text-xs font-semibold text-[var(--color-2-mood)]">
                Public Listing Preview
              </span>
              <StatusBadge label={previewPriceLabel} tone="crimson" />
            </div>
            <div className="aspect-[16/9] bg-[var(--surface-subtle)] overflow-hidden">
              <EditorialImage
                src={bannerImage}
                alt={bannerAlt || title || 'Event preview'}
                objectPosition={bannerPosition}
                fallbackTitle="Event Cover"
              />
            </div>
            <div className="p-4 space-y-2">
              <div className="flex flex-wrap items-center gap-1.5">
                <StatusBadge label={category} tone="neutral" />
                {registrationMode === 'multi' && tracks.filter((t) => t.enabled).length > 0 && (
                  <StatusBadge
                    label={`${tracks.filter((t) => t.enabled).length} Categories`}
                    tone="obsidian"
                  />
                )}
              </div>
              <p className="text-sm font-display font-semibold text-[var(--color-2-mood)]">
                {title.trim() || 'Untitled EDC Event'}
              </p>
              <p className="text-xs text-[var(--ink-muted)] line-clamp-2">
                {subtitle.trim() || 'Add a concise subtitle to highlight this event on the portal.'}
              </p>
              <p className="text-[11px] font-mono text-[var(--ink-secondary)] pt-1">
                {startDate === endDate ? startDate : `${startDate} → ${endDate}`} · {venue || 'Venue'}
              </p>
            </div>
          </div>

          {/* Searchable Primary & Secondary SPOC Selector */}
          <div className="studio-card p-6 space-y-4">
          <div>
            <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
              Event SPOC Leads
            </h2>
            <p className="text-xs text-[var(--ink-muted)] mt-0.5">
              Search and assign Primary &amp; Secondary Single Points of Contact from the Core Team roster.
            </p>
          </div>

          <div className="flex items-center">
            <GooeySearch
              items={coreRoster.map((member) => member.name)}
              value={spocSearch}
              onQueryChange={setSpocSearch}
              buttonLabel="Search Roster"
              placeholder="Core team member..."
              onSelect={(name) => setSpocSearch(name)}
            />
          </div>

          <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
            {filteredSpocs.map((member) => {
              const isPrimary = spocPrimaryId === member.id;
              const isSecondary = spocSecondaryId === member.id;
              return (
                <div
                  key={member.id}
                  className="p-3 rounded-[9px] border border-[var(--border-hairline)] bg-[var(--color-1-mood)] space-y-2"
                >
                  <div className="flex items-center gap-2.5">
                    <MonogramAvatar name={member.name} size="sm" />
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-[var(--color-2-mood)] truncate">{member.name}</p>
                      <p className="text-[11px] text-[var(--ink-muted)] truncate">{member.designation}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      disabled={isLocked}
                      onClick={() => setSpocPrimaryId(member.id)}
                      className={`py-1 text-[11px] font-medium rounded-[6px] border cursor-pointer ${
                        isPrimary
                          ? 'bg-[#C01E30] text-white border-[#C01E30]'
                          : 'bg-[var(--surface)] text-[var(--ink-secondary)] border-[var(--border-strong)]'
                      }`}
                    >
                      {isPrimary ? 'Primary SPOC' : 'Set Primary'}
                    </button>
                    <button
                      type="button"
                      disabled={isLocked}
                      onClick={() => setSpocSecondaryId(member.id)}
                      className={`py-1 text-[11px] font-medium rounded-[6px] border cursor-pointer ${
                        isSecondary
                          ? 'bg-[#030405] dark:bg-[#F1F0ED] text-white dark:text-[#101011] border-[#030405] dark:border-[#F1F0ED]'
                          : 'bg-[var(--surface)] text-[var(--ink-secondary)] border-[var(--border-strong)]'
                      }`}
                    >
                      {isSecondary ? 'Secondary SPOC' : 'Set Secondary'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
          </div>
        </aside>
      </form>
    </div>
  );
};

export const TeamRosterPage: React.FC<{ eventId: string }> = ({ eventId }) => {
  const { events, users, teamAllocations, updateTeamAllocation } = usePortal();
  const evt = events.find((e) => e.id === eventId) ?? events[0];
  const isLocked = evt?.status === 'Closed';
  const coreMembers = users.filter(
    (u) => u.role === 'core_team' || u.role === 'advisor' || u.role === 'director'
  );

  const [selectedTeam, setSelectedTeam] = useState<OperationalTeamCode>('RD');

  const currentAlloc = teamAllocations.find(
    (a) => a.eventId === evt?.id && a.teamCode === selectedTeam
  ) ?? {
    eventId: evt?.id ?? '',
    teamCode: selectedTeam,
    leadId: coreMembers[0]?.id ?? '',
    memberIds: [coreMembers[0]?.id ?? ''],
  };

  const [draftLead, setDraftLead] = useState(currentAlloc.leadId);
  const [draftMembers, setDraftMembers] = useState<string[]>(currentAlloc.memberIds);

  const selectUnit = (code: OperationalTeamCode) => {
    setSelectedTeam(code);
    const found = teamAllocations.find((a) => a.eventId === evt?.id && a.teamCode === code);
    setDraftLead(found?.leadId ?? coreMembers[0]?.id ?? '');
    setDraftMembers(found?.memberIds ?? [coreMembers[0]?.id ?? '']);
  };

  const toggleMember = (userId: string) => {
    setDraftMembers((prev) =>
      prev.includes(userId) ? prev.filter((id) => id !== userId) : [...prev, userId]
    );
  };

  const selectedMeta = OPERATIONAL_TEAMS.find((t) => t.code === selectedTeam)!;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">12-Division Execution Matrix</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Operational Team Roster · {evt?.title}
          </h1>
        </div>
        <StatusBadge label="12 Operational Units" tone="obsidian" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* 12 Teams Grid Selector */}
        <AnimatedContent
          trigger="mount"
          distance={24}
          duration={0.55}
          stagger={0.035}
          className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-3"
        >
          {OPERATIONAL_TEAMS.map((team) => {
            const alloc = teamAllocations.find(
              (a) => a.eventId === evt?.id && a.teamCode === team.code
            );
            const lead = users.find((u) => u.id === alloc?.leadId);
            const active = selectedTeam === team.code;

            return (
              <button
                key={team.code}
                type="button"
                onClick={() => selectUnit(team.code)}
                className={`p-4 rounded-[9px] border text-left transition-all duration-150 hover:-translate-y-0.5 cursor-pointer space-y-2 ${
                  active
                    ? 'bg-[var(--accent-soft)] border-[#C01E30]'
                    : 'bg-[var(--surface)] border-[var(--border-hairline)] hover:border-[var(--border-strong)]'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-mono-data text-xs font-semibold text-[var(--color-2-mood)]">
                    {team.code}
                  </span>
                  <span className="font-mono-data text-[11px] text-[var(--ink-muted)]">
                    {alloc?.memberIds.length ?? 0} assigned
                  </span>
                </div>
                <p className="text-xs font-medium text-[var(--ink-secondary)] truncate">{team.name}</p>
                <p className="text-[11px] text-[var(--ink-muted)] truncate">
                  Lead: {lead?.name.split(' ')[0] ?? 'Unassigned'}
                </p>
              </button>
            );
          })}
        </AnimatedContent>

        {/* Unit Allocator Panel */}
        <div className="lg:col-span-5 studio-card p-6 space-y-5">
          <div className="pb-4 border-b border-[var(--border-hairline)]">
            <div className="flex items-center justify-between">
              <span className="font-mono-data text-xs font-semibold text-[#C01E30] dark:text-[#F87171]">
                UNIT · {selectedMeta.code}
              </span>
              <span className="font-mono-data text-xs text-[var(--ink-muted)]">
                {draftMembers.length} member(s)
              </span>
            </div>
            <h2 className="text-lg font-display font-semibold text-[var(--color-2-mood)] mt-1">
              {selectedMeta.name}
            </h2>
            <p className="text-xs text-[var(--ink-muted)] mt-1">{selectedMeta.mandate}</p>
          </div>

          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
              Designated Unit Lead
            </label>
            <SelectDropdown
              disabled={isLocked}
              value={draftLead}
              onChange={(val) => {
                setDraftLead(val);
                if (!draftMembers.includes(val)) {
                  setDraftMembers((prev) => [...prev, val]);
                }
              }}
              size="default"
              className="w-full"
              menuLabel="Core Team Leads"
              options={coreMembers.map((m) => ({
                value: m.id,
                label: `${m.name} — ${m.designation}`,
              }))}
            />
          </div>

          <div className="space-y-2">
            <p className="text-xs font-medium text-[var(--color-2-mood)]">
              Assign Core Team Members (Multi-Unit Allowed)
            </p>
            <div className="space-y-1.5 max-h-[260px] overflow-y-auto pr-1">
              {coreMembers.map((member) => {
                const checked = draftMembers.includes(member.id);
                return (
                  <button
                    key={member.id}
                    type="button"
                    disabled={isLocked}
                    onClick={() => toggleMember(member.id)}
                    className={`w-full p-2.5 rounded-[9px] border flex items-center justify-between gap-2 text-left transition-colors cursor-pointer ${
                      checked
                        ? 'bg-[var(--surface-subtle)] border-[var(--color-2-mood)]'
                        : 'bg-[var(--surface)] border-[var(--border-hairline)] hover:bg-[var(--surface-subtle)]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <MonogramAvatar name={member.name} size="sm" />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-[var(--color-2-mood)] truncate">{member.name}</p>
                        <p className="text-[11px] text-[var(--ink-muted)] truncate">{member.designation}</p>
                      </div>
                    </div>
                    <span
                      className={`h-5 w-5 rounded-[4px] border flex items-center justify-center shrink-0 ${
                        checked
                          ? 'bg-[#C01E30] border-[#C01E30] text-white'
                          : 'bg-[var(--surface)] border-[var(--border-strong)]'
                      }`}
                    >
                      {checked && <Check className="h-3.5 w-3.5" />}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <StudioButton
            variant="primary"
            className="w-full"
            disabled={isLocked}
            onClick={() => updateTeamAllocation(evt.id, selectedTeam, draftLead, draftMembers)}
          >
            Save {selectedTeam} Unit Roster
          </StudioButton>
        </div>
      </div>
    </div>
  );
};
