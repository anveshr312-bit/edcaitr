import React, { useMemo, useState } from 'react';
import {
  ArrowUpRight,
  Bus,
  CheckCircle2,
  Linkedin,
  Mail,
  MapPin,
  Phone,
  Send,
  Shield,
} from 'lucide-react';
import { usePortal } from '../../context/PortalContext';
import { EDITORIAL_IMAGES, OPERATIONAL_TEAMS } from '../../data/seedData';
import {
  EditorialImage,
  MonogramAvatar,
  StatusBadge,
  StudioButton,
} from '../../components/ui/Primitives';
import { LiquidButton } from '../../components/ui/LiquidButton';
import { AnimatedContent } from '../../components/ui/AnimatedContent';
import { GooeySearch } from '../../components/ui/GooeySearch';
import { SelectDropdown } from '../../components/ui/dropdown-menu';
import { KineticHeading } from '../../components/ui/KineticHeading';

const CORE_OBJECTIVES = [
  {
    index: '01',
    title: 'Cultivate Campus Venture Readiness',
    detail:
      'Equip undergraduate and postgraduate students at AITR Indore with practical customer discovery, financial modeling, and legal incorporation literacy.',
  },
  {
    index: '02',
    title: 'Bridge Lab Prototyping to AIIH Pre-Incubation',
    detail:
      'Provide zero-equity access to the AIIH Foundation fablabs, 3D printing suites, AWS/Google Cloud credits, and structured 8-month CSI cohorts.',
  },
  {
    index: '03',
    title: 'Unlock State & National Grant Pipelines',
    detail:
      'Guide eligible student teams through DPIIT Startup India recognition, Madhya Pradesh Startup Policy benefits, and DST NIDHI-EIR fellowships.',
  },
  {
    index: '04',
    title: 'Connect Founders Directly to Regional Capital',
    detail:
      'Operate PitchBiz Investment Arena alongside TiE MP, Lead Angels Network, and MP Angel Network so vetted teams raise early checks from Indore.',
  },
  {
    index: '05',
    title: 'Build Student-Led Operational Excellence',
    detail:
      'Train future operators through 12 disciplined student execution divisions managing national conclaves, hackathons, and archival governance.',
  },
];

const INCUBATION_STAGES = [
  {
    stage: 'Stage 01 · Ideation & Problem Discovery',
    window: 'Months 1–2',
    outcome: 'Customer interviews, PMx workshops, and faculty-advisor validation.',
  },
  {
    stage: 'Stage 02 · Prototyping & Cloud Sandbox',
    window: 'Months 3–5',
    outcome: 'AIIH FabLab access, hardware/software MVP build, and AWS/GCP credits.',
  },
  {
    stage: 'Stage 03 · DPIIT & Grant Filing',
    window: 'Months 6–7',
    outcome: 'Entity incorporation, IP clinic with IIC, MP Startup Policy & NIDHI-EIR applications.',
  },
  {
    stage: 'Stage 04 · PitchBiz & Angel Syndicate Demo',
    window: 'Month 8+',
    outcome: 'Closed-door pitch floor with TiE MP, Lead Angels Network, and alumni founders.',
  },
];

export const AboutPage: React.FC = () => {
  const { navigate } = usePortal();

  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-14">
      {/* Header Narrative */}
      <AnimatedContent
        trigger="mount"
        distance={32}
        duration={0.75}
        stagger={0.08}
        className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pb-10 border-b border-[var(--border-hairline)]"
      >
        <div className="lg:col-span-7 space-y-4">
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Institutional Charter</p>
          <div style={{ fontSize: 'clamp(2rem, 3.6vw, 3rem)', textWrap: 'balance' }}>
            <KineticHeading
              as="h1"
              text="Building Central India’s Most Disciplined"
              accentText="Campus Venture Ecosystem"
              replayKey="about-hero-headline"
              immediate
              className="font-display font-semibold text-[var(--color-2-mood)] leading-tight"
            />
          </div>
          <p className="text-base text-[var(--ink-secondary)] leading-relaxed max-w-[65ch]">
            The Entrepreneurship Development Cell at Acropolis Institute of Technology &amp; Research (EDC AITR), Indore works hand-in-hand with the <strong className="font-semibold text-[var(--color-2-mood)]">AIIH Foundation</strong> (Acropolis Institutional Incubation Hub) and the Ministry of Education’s Institution’s Innovation Council (IIC).
          </p>
          <p className="text-base text-[var(--ink-secondary)] leading-relaxed max-w-[65ch]">
            Rather than treating entrepreneurship as one-off speaker events, EDC AITR operates as an end-to-end institutional pipeline—combining student-run conclave operations with structured venture pre-incubation, laboratory infrastructure, and permanent alumni mentorship.
          </p>
        </div>

        <div className="lg:col-span-5">
          <div className="h-[260px] lg:h-full rounded-[9px] overflow-hidden border border-[var(--border-hairline)]">
            <EditorialImage
              src={EDITORIAL_IMAGES.summitStage}
              alt="EDC AITR auditorium keynote session"
              fallbackTitle="AITR Main Auditorium"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </AnimatedContent>

      {/* Governance & Institutional Backbone */}
      <AnimatedContent
        distance={44}
        duration={0.7}
        stagger={0.08}
        threshold={0.1}
        className="grid grid-cols-1 md:grid-cols-3 gap-5"
      >
        <div className="studio-card p-6 space-y-2">
          <Shield className="h-5 w-5 text-[#C01E30]" strokeWidth={1.7} />
          <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
            Institutional Governance
          </h2>
          <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">
            Directed by Dr. Atul Bharat alongside dedicated Faculty Advisors and an audited student core leadership board with TOTP-protected records and permanent event closure trails.
          </p>
        </div>

        <div className="studio-card p-6 space-y-2">
          <Bus className="h-5 w-5 text-[#C01E30]" strokeWidth={1.7} />
          <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
            4-City Campus Transit Network
          </h2>
          <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">
            Acropolis operates dedicated institutional bus corridors connecting <strong className="font-medium text-[var(--color-2-mood)]">Indore, Dewas, Ujjain, and Maksi</strong>, enabling seamless daily participation for student founders and external conclave delegations.
          </p>
        </div>

        <div className="studio-card p-6 space-y-2">
          <CheckCircle2 className="h-5 w-5 text-[#C01E30]" strokeWidth={1.7} />
          <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
            AIIH Foundation Partnership
          </h2>
          <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">
            Joint stewardship of ₹1.5 Cr+ in cumulative DPIIT, MP Startup Policy, and NIDHI-EIR grant pipelines with dedicated co-working desks and hardware prototyping labs.
          </p>
        </div>
      </AnimatedContent>

      {/* 5 Core Objectives */}
      <section className="space-y-6">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171] mb-1">Strategic Mandate</p>
          <h2 className="text-2xl font-display font-semibold text-[var(--color-2-mood)]">
            Five Core Objectives
          </h2>
        </div>

        <AnimatedContent
          distance={36}
          duration={0.7}
          stagger={0.06}
          threshold={0.1}
          className="studio-card divide-y divide-[var(--border-hairline)]"
        >
          {CORE_OBJECTIVES.map((obj) => (
            <div key={obj.index} className="p-5 sm:p-6 grid grid-cols-1 md:grid-cols-12 gap-3 md:gap-6">
              <div className="md:col-span-1 font-mono-data text-sm font-semibold text-[#C01E30] dark:text-[#F87171]">
                {obj.index}
              </div>
              <div className="md:col-span-4">
                <h3 className="text-base font-display font-semibold text-[var(--color-2-mood)]">{obj.title}</h3>
              </div>
              <div className="md:col-span-7">
                <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">{obj.detail}</p>
              </div>
            </div>
          ))}
        </AnimatedContent>
      </section>

      {/* Incubation Pipelines */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171] mb-1">Venture Lifecycle</p>
            <h2 className="text-2xl font-display font-semibold text-[var(--color-2-mood)]">
              AIIH &amp; CSI Pre-Incubation Pipeline
            </h2>
          </div>
          <LiquidButton variant="crimson" size="sm" onClick={() => navigate('/contact?tab=csi')}>
            <span>Pitch Your Venture</span>
          </LiquidButton>
        </div>

        <AnimatedContent
          distance={44}
          duration={0.7}
          stagger={0.08}
          threshold={0.1}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
        >
          {INCUBATION_STAGES.map((item) => (
            <div key={item.stage} className="studio-card p-5 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <p className="font-mono-data text-xs text-[#C01E30] dark:text-[#F87171] font-medium">{item.window}</p>
                <h3 className="text-sm font-display font-semibold text-[var(--color-2-mood)]">{item.stage}</h3>
              </div>
              <p className="text-xs text-[var(--ink-secondary)] leading-relaxed">{item.outcome}</p>
            </div>
          ))}
        </AnimatedContent>
      </section>
    </div>
  );
};

export const TeamPage: React.FC = () => {
  const { users, navigate } = usePortal();
  const [tenureFilter, setTenureFilter] = useState<'current' | 'past'>('current');
  const [unitFilter, setUnitFilter] = useState<string>('ALL');
  const [teamQuery, setTeamQuery] = useState('');

  const tenureMembers = useMemo(
    () => users.filter((u) => u.role !== 'participant' && u.tenure === tenureFilter),
    [users, tenureFilter]
  );

  const directoryMembers = useMemo(() => {
    const q = teamQuery.trim().toLowerCase();
    return tenureMembers.filter((u) => {
      const matchUnit =
        unitFilter === 'ALL' || u.operationalTeam === unitFilter || (!u.operationalTeam && unitFilter === 'GOV');
      const matchSearch =
        !q ||
        u.name.toLowerCase().includes(q) ||
        u.designation.toLowerCase().includes(q) ||
        u.department.toLowerCase().includes(q) ||
        (u.company ?? '').toLowerCase().includes(q);
      return matchUnit && matchSearch;
    });
  }, [tenureMembers, unitFilter, teamQuery]);

  const leadership = directoryMembers.filter((u) => u.role === 'director' || u.role === 'advisor');
  const studentAndAlumni = directoryMembers.filter((u) => u.role !== 'director' && u.role !== 'advisor');

  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 sm:py-14 space-y-10">
      <AnimatedContent
        trigger="mount"
        distance={28}
        duration={0.65}
        className="flex flex-col md:flex-row md:items-end justify-between gap-5 pb-8 border-b border-[var(--border-hairline)]"
      >
        <div className="space-y-2">
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Leadership &amp; Core Roster</p>
          <h1 className="text-3xl sm:text-4xl font-display font-semibold text-[var(--color-2-mood)]">
            Team Directory
          </h1>
          <p className="text-sm sm:text-base text-[var(--ink-secondary)] max-w-2xl">
            Faculty leadership, current student division heads, and past tenures who shaped EDC AITR’s institutional legacy.
          </p>
        </div>

        <LiquidButton variant="crimson" size="sm" onClick={() => navigate('/account/apply')}>
          <span>Apply for Core Team</span>
        </LiquidButton>
      </AnimatedContent>

      {/* Tenure Toggle + Unit Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="inline-flex p-1 bg-[var(--surface-subtle)] border border-[var(--border-hairline)] rounded-[9px] self-start">
          <button
            type="button"
            onClick={() => {
              setTenureFilter('current');
              setUnitFilter('ALL');
            }}
            className={`px-4 py-1.5 text-xs font-medium rounded-[6px] transition-colors cursor-pointer ${
              tenureFilter === 'current'
                ? 'bg-[var(--surface)] text-[var(--color-2-mood)] border border-[var(--border-hairline)]'
                : 'text-[var(--ink-muted)] hover:text-[var(--color-2-mood)]'
            }`}
          >
            Current Team (2025–26)
          </button>
          <button
            type="button"
            onClick={() => {
              setTenureFilter('past');
              setUnitFilter('ALL');
            }}
            className={`px-4 py-1.5 text-xs font-medium rounded-[6px] transition-colors cursor-pointer ${
              tenureFilter === 'past'
                ? 'bg-[var(--surface)] text-[var(--color-2-mood)] border border-[var(--border-hairline)]'
                : 'text-[var(--ink-muted)] hover:text-[var(--color-2-mood)]'
            }`}
          >
            Past Tenures &amp; Alumni
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <GooeySearch
            items={tenureMembers.map((m) => m.name)}
            value={teamQuery}
            onQueryChange={setTeamQuery}
            buttonLabel="Find Member"
            placeholder="Name, role, or unit..."
            onSelect={(name) => setTeamQuery(name)}
          />
          <div className="flex items-center gap-2">
            <label htmlFor="unit-filter" className="text-xs text-[var(--ink-muted)]">
              Operational Unit:
            </label>
            <SelectDropdown
              id="unit-filter"
              value={unitFilter}
              onChange={setUnitFilter}
              align="end"
              size="xs"
              className="w-auto min-w-[180px]"
              groups={[
                {
                  label: 'Overview',
                  options: [
                    { value: 'ALL', label: 'All Divisions' },
                    { value: 'GOV', label: 'Director & Faculty' },
                  ],
                },
                {
                  label: '12 Operational Units',
                  options: OPERATIONAL_TEAMS.map((t) => ({
                    value: t.code,
                    label: `${t.code} — ${t.name}`,
                  })),
                },
              ]}
            />
          </div>
        </div>
      </div>

      {/* Director & Faculty Advisors */}
      {leadership.length > 0 && (
        <section className="space-y-4">
          <h2 className="text-lg font-display font-semibold text-[var(--color-2-mood)]">
            Director &amp; Faculty Advisors
          </h2>
          <AnimatedContent
            key={`lead-${tenureFilter}-${unitFilter}`}
            trigger="mount"
            distance={36}
            duration={0.65}
            stagger={0.08}
            className="grid grid-cols-1 md:grid-cols-2 gap-5"
          >
            {leadership.map((member) => (
              <div key={member.id} className="studio-card p-6 flex items-start justify-between gap-4">
                <div className="flex items-start gap-4 min-w-0">
                  <MonogramAvatar name={member.name} size="lg" tone="obsidian" />
                  <div className="min-w-0 space-y-1">
                    <h3 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
                      {member.name}
                    </h3>
                    <p className="text-sm text-[#C01E30] dark:text-[#F87171] font-medium">{member.designation}</p>
                    <p className="text-xs text-[var(--ink-muted)]">{member.department}</p>
                  </div>
                </div>
                <a
                  href={member.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={`${member.name} LinkedIn profile`}
                  className="h-9 w-9 rounded-[9px] border border-[var(--border-strong)] flex items-center justify-center text-[var(--ink-secondary)] hover:border-[#C01E30] hover:text-[#C01E30] shrink-0"
                >
                  <Linkedin className="h-4 w-4" />
                </a>
              </div>
            ))}
          </AnimatedContent>
        </section>
      )}

      {/* Student Core Leads / Alumni */}
      <section className="space-y-4">
        <h2 className="text-lg font-display font-semibold text-[var(--color-2-mood)]">
          {tenureFilter === 'current' ? 'Student Core Team Leads' : 'Past Tenures & Alumni Founders'}
        </h2>
        {studentAndAlumni.length === 0 ? (
          <div className="studio-card p-8 text-center text-sm text-[var(--ink-muted)]">
            No roster entries match the selected operational unit filter.
          </div>
        ) : (
          <AnimatedContent
            key={`roster-${tenureFilter}-${unitFilter}`}
            trigger="mount"
            distance={32}
            duration={0.65}
            stagger={0.05}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5"
          >
            {studentAndAlumni.map((member) => (
              <div key={member.id} className="studio-card p-5 flex flex-col justify-between space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3.5 min-w-0">
                    <MonogramAvatar
                      name={member.name}
                      size="md"
                      tone={tenureFilter === 'past' ? 'crimson' : 'neutral'}
                    />
                    <div className="min-w-0">
                      <h3 className="text-sm font-semibold text-[var(--color-2-mood)] truncate">{member.name}</h3>
                      <p className="text-xs text-[var(--ink-secondary)] mt-0.5 leading-snug">{member.designation}</p>
                      {member.company && tenureFilter === 'past' && (
                        <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171] mt-1">{member.company}</p>
                      )}
                    </div>
                  </div>
                  <a
                    href={member.linkedin}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={`${member.name} LinkedIn`}
                    className="h-8 w-8 rounded-[9px] border border-[var(--border-hairline)] flex items-center justify-center text-[var(--ink-secondary)] hover:border-[#C01E30] hover:text-[#C01E30] shrink-0"
                  >
                    <Linkedin className="h-3.5 w-3.5" />
                  </a>
                </div>

                <div className="pt-3 border-t border-[var(--border-hairline)] flex items-center justify-between gap-2 text-xs text-[var(--ink-muted)]">
                  <span>{member.department}</span>
                  {member.operationalTeam && (
                    <span className="font-mono-data font-semibold text-[var(--color-2-mood)] bg-[var(--surface-subtle)] border border-[var(--border-hairline)] rounded-[4px] px-1.5 py-0.5">
                      {member.operationalTeam}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </AnimatedContent>
        )}
      </section>
    </div>
  );
};

type ContactTab =
  | 'General Inquiry'
  | 'Startup Incubation & CSI'
  | 'Conclave Sponsorship & Partnerships';

export const ContactPage: React.FC = () => {
  const { path, submitContactForm } = usePortal();

  const initialTab: ContactTab = path.includes('tab=csi')
    ? 'Startup Incubation & CSI'
    : path.includes('tab=sponsorship')
      ? 'Conclave Sponsorship & Partnerships'
      : 'General Inquiry';

  const [activeTab, setActiveTab] = useState<ContactTab>(initialTab);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [organization, setOrganization] = useState('');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  const tabs: ContactTab[] = [
    'General Inquiry',
    'Startup Incubation & CSI',
    'Conclave Sponsorship & Partnerships',
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !message.trim()) return;
    setSubmitting(true);
    window.setTimeout(() => {
      submitContactForm({
        tab: activeTab,
        name: name.trim(),
        email: email.trim(),
        organization: organization.trim() || 'Independent / AITR Student',
        message: message.trim(),
      });
      setSubmitting(false);
      setSubmittedSuccess(true);
      setName('');
      setEmail('');
      setOrganization('');
      setMessage('');
    }, 400);
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 sm:py-14">
      <AnimatedContent
        trigger="mount"
        distance={28}
        duration={0.65}
        className="pb-8 border-b border-[var(--border-hairline)] space-y-2"
      >
        <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Institutional Desk</p>
        <h1 className="text-3xl sm:text-4xl font-display font-semibold text-[var(--color-2-mood)]">
          Contact EDC AITR
        </h1>
        <p className="text-sm sm:text-base text-[var(--ink-secondary)] max-w-2xl">
          Route your inquiry directly to our student secretariat, AIIH Foundation incubation leads, or FOKUS X E-Summit sponsorship partners.
        </p>
      </AnimatedContent>

      <AnimatedContent
        trigger="mount"
        distance={36}
        duration={0.7}
        delay={0.06}
        stagger={0.08}
        className="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-8 items-start"
      >
        {/* 3-Tab Inquiry Form */}
        <div className="lg:col-span-8 studio-card p-6 sm:p-8 space-y-6">
          <div className="flex flex-wrap gap-2 pb-4 border-b border-[var(--border-hairline)]">
            {tabs.map((tab) => {
              const active = activeTab === tab;
              return (
                <button
                  key={tab}
                  type="button"
                  onClick={() => {
                    setActiveTab(tab);
                    setSubmittedSuccess(false);
                  }}
                  className={`px-3.5 py-2 text-xs font-medium rounded-[9px] border transition-colors cursor-pointer ${
                    active
                      ? 'bg-[var(--accent-soft)] text-[#C01E30] dark:text-[#F87171] border-[var(--accent-border)]'
                      : 'bg-[var(--surface)] text-[var(--ink-secondary)] border-[var(--border-hairline)] hover:bg-[var(--surface-subtle)]'
                  }`}
                >
                  {tab}
                </button>
              );
            })}
          </div>

          {submittedSuccess && (
            <div className="bg-[#ECFDF3] dark:bg-emerald-950/50 border border-[#BBF7D0] dark:border-emerald-800/70 rounded-[9px] p-4 flex items-start justify-between gap-3">
              <div className="text-sm text-[#15803D] dark:text-emerald-300">
                <p className="font-semibold">Inquiry logged with EDC AITR Desk</p>
                <p className="text-xs mt-0.5">
                  Our SPOC team will respond to your email within 24 working hours.
                </p>
              </div>
              <StatusBadge label="Recorded" tone="green" />
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your full name"
                  className="studio-input"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@domain.com"
                  className="studio-input"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                {activeTab === 'Startup Incubation & CSI'
                  ? 'Startup Name & Current Stage'
                  : activeTab === 'Conclave Sponsorship & Partnerships'
                    ? 'Company / Venture Fund / Organization'
                    : 'Department / Institution'}
              </label>
              <input
                type="text"
                value={organization}
                onChange={(e) => setOrganization(e.target.value)}
                placeholder={
                  activeTab === 'Startup Incubation & CSI'
                    ? 'e.g. VedaGrid Systems · Prototype Stage'
                    : activeTab === 'Conclave Sponsorship & Partnerships'
                      ? 'e.g. Lead Angels Network / Corporate Partner'
                      : 'e.g. AITR Indore · B.Tech CSE'
                }
                className="studio-input"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
                {activeTab === 'Startup Incubation & CSI'
                  ? 'Venture Brief, Prototyping Needs & Deck Link'
                  : activeTab === 'Conclave Sponsorship & Partnerships'
                    ? 'Partnership Tier / Speaking / Judging Interest'
                    : 'Message'}
              </label>
              <textarea
                rows={5}
                required
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Share concise context so the relevant EDC AITR lead can follow up..."
                className="studio-input resize-y"
              />
            </div>

            <div className="pt-2">
              <StudioButton type="submit" variant="primary" loading={submitting}>
                <Send className="h-4 w-4" />
                <span>Submit {activeTab}</span>
              </StudioButton>
            </div>
          </form>
        </div>

        {/* Physical Campus Address & Direct Contacts */}
        <aside className="lg:col-span-4 space-y-5">
          <div className="studio-card p-6 space-y-4">
            <h2 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
              Campus Secretariat
            </h2>
            <div className="space-y-3 text-sm text-[var(--ink-secondary)]">
              <div className="flex items-start gap-2.5">
                <MapPin className="h-4 w-4 text-[#C01E30] mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium text-[var(--color-2-mood)]">
                    Acropolis Institute of Technology &amp; Research
                  </p>
                  <p className="text-xs text-[var(--ink-muted)] leading-relaxed mt-0.5">
                    EDC Cell &amp; AIIH Foundation Hub, Bypass Road, Manglia Square, Indore, Madhya Pradesh 453771
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 text-[#C01E30] shrink-0" />
                <a href="mailto:edc@acropolis.in" className="hover:text-[#C01E30]">
                  edc@acropolis.in
                </a>
              </div>
              <div className="flex items-center gap-2.5">
                <Phone className="h-4 w-4 text-[#C01E30] shrink-0" />
                <span className="font-mono-data text-xs">+91 731 473 0000 / Ext. 412</span>
              </div>
            </div>
          </div>

          <div className="studio-subtle p-6 space-y-2.5">
            <p className="text-xs font-semibold text-[var(--color-2-mood)]">Visiting Hours</p>
            <p className="text-xs text-[var(--ink-secondary)] leading-relaxed">
              Monday – Saturday · 09:00 IST to 17:30 IST. Prototyping FabLab mentor clinics operate until 20:00 IST for active CSI cohort founders.
            </p>
            <a
              href="https://instagram.com/edc_acropolis"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-xs font-semibold text-[#C01E30] dark:text-[#F87171] hover:underline pt-1"
            >
              <span>Follow @edc_acropolis on Instagram</span>
              <ArrowUpRight className="h-3.5 w-3.5" />
            </a>
          </div>
        </aside>
      </AnimatedContent>
    </div>
  );
};
