import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowRight,
  ArrowUpRight,
  Cloud,
  Cpu,
  Handshake,
  Instagram,
  MapPin,
  Users,
} from 'lucide-react';
import { usePortal } from '../../context/PortalContext';
import { useThemeToggle } from '../../context/ThemeContext';
import {
  hasRevealedKey,
  markRevealedKey,
  MOTION_TRACKS,
  useMotionSystem,
} from '../../context/MotionContext';
import {
  DRIFT_WALL_TILES,
  EDITORIAL_IMAGES,
  IMPACT_METRICS,
  INITIATIVES,
  MARQUEE_GUESTS,
  PARTNER_ORGANIZATIONS,
} from '../../data/seedData';
import { EditorialImage, StudioButton } from '../../components/ui/Primitives';
import { LiquidButton } from '../../components/ui/LiquidButton';
import { RollingStat } from '../../components/ui/RollingStat';
import { AnimatedContent } from '../../components/ui/AnimatedContent';
import { DriftWall } from '../../components/ui/DriftWall';
import { AccordionGallery } from '../../components/ui/AccordionGallery';
import { LogoLoop, type LogoNodeItem } from '../../components/ui/LogoLoop';
import { KineticHeading } from '../../components/ui/KineticHeading';
import { GuestCoverflow } from '../../components/ui/GuestCoverflow';

export const HomePage: React.FC = () => {
  const { navigate, events } = usePortal();
  const { isDark } = useThemeToggle();
  const { introReady, reducedMotion } = useMotionSystem();
  const [activeInitiativeIdx, setActiveInitiativeIdx] = useState(0);

  const fokusEvent = useMemo(
    () => events.find((e) => e.slug === 'fokus-x-e-summit-2026'),
    [events]
  );
  const fokusIsClosed = fokusEvent?.status === 'Closed';
  const fokusDateLabel = fokusEvent?.dateLabel || '18th–20th March 2026';
  const [heroViewport, setHeroViewport] = useState<'mobile' | 'tablet' | 'desktop'>(() => {
    if (typeof window === 'undefined') return 'desktop';
    if (window.innerWidth >= 1024) return 'desktop';
    if (window.innerWidth >= 640) return 'tablet';
    return 'mobile';
  });

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const desktopMq = window.matchMedia('(min-width: 1024px)');
    const tabletMq = window.matchMedia('(min-width: 640px)');

    const syncViewport = () => {
      if (desktopMq.matches) {
        setHeroViewport('desktop');
      } else if (tabletMq.matches) {
        setHeroViewport('tablet');
      } else {
        setHeroViewport('mobile');
      }
    };

    syncViewport();
    desktopMq.addEventListener('change', syncViewport);
    tabletMq.addEventListener('change', syncViewport);
    return () => {
      desktopMq.removeEventListener('change', syncViewport);
      tabletMq.removeEventListener('change', syncViewport);
    };
  }, []);

  const heroWallConfig = useMemo(() => {
    if (heroViewport === 'mobile') {
      return {
        columns: 3,
        tileWidth: 148,
        tileHeight: 100,
        gap: 12,
        radius: 7,
        tilt: 6,
        turn: -4,
        perspective: 1000,
        depth: 40,
        speed: 15,
        variance: 0.25,
        parallax: 0,
        lift: 24,
        fade: 0.4,
        dim: isDark ? 0.22 : 0.18,
      };
    }
    if (heroViewport === 'tablet') {
      return {
        columns: 4,
        tileWidth: 192,
        tileHeight: 128,
        gap: 16,
        radius: 8,
        tilt: 10,
        turn: -8,
        perspective: 1200,
        depth: 68,
        speed: 18,
        variance: 0.32,
        parallax: 0.26,
        lift: 32,
        fade: 0.36,
        dim: isDark ? 0.18 : 0.14,
      };
    }
    return {
      columns: 6,
      tileWidth: 214,
      tileHeight: 142,
      gap: 18,
      radius: 8,
      tilt: 13,
      turn: -11,
      perspective: 1300,
      depth: 90,
      speed: 20,
      variance: 0.35,
      parallax: 0.36,
      lift: 40,
      fade: 0.32,
      dim: isDark ? 0.14 : 0.1,
    };
  }, [heroViewport, isDark]);

  const heroScrimBackground = useMemo(() => {
    if (heroViewport === 'mobile') {
      return isDark
        ? 'radial-gradient(ellipse 78% 64% at 50% 46%, rgba(16, 16, 17, 0.96) 0%, rgba(16, 16, 17, 0.89) 48%, rgba(16, 16, 17, 0.58) 76%, rgba(16, 16, 17, 0.2) 100%)'
        : 'radial-gradient(ellipse 78% 64% at 50% 46%, rgba(250, 250, 252, 0.97) 0%, rgba(250, 250, 252, 0.91) 48%, rgba(250, 250, 252, 0.62) 76%, rgba(250, 250, 252, 0.18) 100%)';
    }
    return isDark
      ? 'radial-gradient(ellipse 46% 58% at 50% 47%, rgba(16, 16, 17, 0.96) 0%, rgba(16, 16, 17, 0.88) 42%, rgba(16, 16, 17, 0.52) 68%, rgba(16, 16, 17, 0.08) 100%)'
      : 'radial-gradient(ellipse 46% 58% at 50% 47%, rgba(250, 250, 252, 0.97) 0%, rgba(250, 250, 252, 0.91) 42%, rgba(250, 250, 252, 0.56) 68%, rgba(250, 250, 252, 0.06) 100%)';
  }, [heroViewport, isDark]);

  const heroAlreadyRevealed = useRef(hasRevealedKey('home-hero-block'));
  const heroReady = heroAlreadyRevealed.current || reducedMotion || introReady;

  useEffect(() => {
    if (heroReady) {
      markRevealedKey('home-hero-block');
    }
  }, [heroReady]);

  const featuredInitiatives = useMemo(() => INITIATIVES.slice(0, 5), []);
  const activeInitiative = featuredInitiatives[activeInitiativeIdx] ?? featuredInitiatives[0];

  const galleryItems = useMemo(
    () =>
      featuredInitiatives.map((item) => ({
        image: item.image,
        label: item.title,
        subtitle: item.cadence,
        code: item.code,
        link: `/events/${item.linkedSlug}`,
        alt: `${item.title} — EDC AITR`,
      })),
    [featuredInitiatives]
  );

  const partnerLogos: LogoNodeItem[] = useMemo(
    () =>
      PARTNER_ORGANIZATIONS.map((partner) => ({
        title: partner.name,
        ariaLabel: `${partner.name} — ${partner.role}`,
        hoverColor: '#C01E30',
        node: (
          <div className="group border-l border-[var(--border-hairline)] pl-6 pr-2 py-1.5 text-left">
            <p className="text-base sm:text-[17px] font-display font-semibold tracking-[-0.015em] text-[var(--color-2-mood)] group-hover:text-[#C01E30] dark:group-hover:text-[#D93848] leading-tight whitespace-nowrap transition-colors">
              {partner.name}
            </p>
            <p className="text-xs text-[var(--ink-muted)] mt-1 whitespace-nowrap">
              {partner.role}
            </p>
          </div>
        ),
      })),
    []
  );

  return (
    <div>
      {/* 1. Centered Hero Section over DriftWall */}
      <section className="relative overflow-hidden border-b border-[var(--border-hairline)]">
        {/* Background 3D DriftWall with Outermost-10% Horizontal Edge Dissolve */}
        <div
          className="absolute inset-0 pointer-events-none select-none opacity-100"
          style={{
            maskImage:
              'linear-gradient(to right, transparent 0%, rgba(0, 0, 0, 0.45) 4%, black 10%, black 90%, rgba(0, 0, 0, 0.45) 96%, transparent 100%)',
            WebkitMaskImage:
              'linear-gradient(to right, transparent 0%, rgba(0, 0, 0, 0.45) 4%, black 10%, black 90%, rgba(0, 0, 0, 0.45) 96%, transparent 100%)',
          }}
        >
          <DriftWall
            items={DRIFT_WALL_TILES}
            columns={heroWallConfig.columns}
            tileWidth={heroWallConfig.tileWidth}
            tileHeight={heroWallConfig.tileHeight}
            gap={heroWallConfig.gap}
            radius={heroWallConfig.radius}
            tilt={heroWallConfig.tilt}
            turn={heroWallConfig.turn}
            perspective={heroWallConfig.perspective}
            depth={heroWallConfig.depth}
            speed={heroWallConfig.speed}
            direction="up"
            variance={heroWallConfig.variance}
            parallax={heroWallConfig.parallax}
            lift={heroWallConfig.lift}
            fade={heroWallConfig.fade}
            dim={heroWallConfig.dim}
            overlayColor={isDark ? '#101011' : '#fafafc'}
          />
        </div>

        {/* Centre-Focused Elliptical Readability Scrim — Preserves Peripheral Photography */}
        <div
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none"
          style={{ background: heroScrimBackground }}
        />

        <div className="relative z-10 max-w-[1200px] mx-auto px-4 sm:px-6 pt-16 pb-16 sm:pt-20 sm:pb-20 lg:pt-24 lg:pb-24">
          <motion.div
            initial={
              heroAlreadyRevealed.current || reducedMotion
                ? false
                : { opacity: 0, y: 18 }
            }
            animate={heroReady ? { opacity: 1, y: 0 } : { opacity: 0, y: 18 }}
            transition={{
              duration: reducedMotion ? 0.01 : 0.48,
              ease: MOTION_TRACKS.publicEditorial.ease,
            }}
            className="max-w-[1080px] mx-auto text-center flex flex-col items-center"
          >
            {/* Editorial Institutional Eyebrow */}
            <div className="inline-flex items-center gap-2.5 sm:gap-3 text-xs sm:text-[13px] font-medium tracking-[0.02em] text-[var(--ink-secondary)]">
              <span
                aria-hidden="true"
                className="hidden sm:inline-block w-5 h-px bg-[#C01E30]/65"
              />
              <span>Entrepreneurship Development Cell</span>
              <span aria-hidden="true" className="text-[#C01E30]">·</span>
              <span>Acropolis Indore</span>
              <span
                aria-hidden="true"
                className="hidden sm:inline-block w-5 h-px bg-[#C01E30]/65"
              />
            </div>

            {/* Centred Display Headline — Independent Wide Measure for Clean Two-Line Desktop Break */}
            <div
              className="mt-5 sm:mt-6 w-full max-w-[1060px] [text-wrap:balance] md:[text-wrap:unset]"
              style={{ fontSize: 'clamp(2.35rem, 4.9vw, 4.35rem)' }}
            >
              <KineticHeading
                as="h1"
                text="Empowering the Next Wave of"
                accentText="Student Founders"
                breakBeforeAccent="md"
                replayKey="home-hero-headline"
                immediate
                className="font-display font-bold tracking-[-0.03em] text-[var(--color-2-mood)] leading-[1.03]"
                accentClassName="text-[#C01E30] dark:text-[#D93848]"
              />
            </div>

            {/* Supporting Institutional Lead */}
            <p className="mt-5 sm:mt-6 text-base sm:text-[1.0625rem] text-[var(--ink-secondary)] leading-[1.65] max-w-[56ch] mx-auto">
              Operating in partnership with the <strong className="font-semibold text-[var(--color-2-mood)]">AIIH Foundation</strong> (Acropolis Institutional Incubation Hub), EDC AITR guides student builders from first hardware prototype to DPIIT recognition, pre-incubation grants, and angel investment across Central India.
            </p>

            {/* Primary & Secondary CTA Hierarchy */}
            <div className="mt-7 sm:mt-8 flex flex-wrap items-center justify-center gap-3.5">
              <LiquidButton
                variant="crimson-solid"
                onClick={() => navigate('/events')}
              >
                <span>Explore Live Events</span>
                <ArrowRight className="h-4 w-4" />
              </LiquidButton>
              <LiquidButton
                variant="outline"
                className="bg-[var(--surface)]/80 dark:bg-[#171719]/80 backdrop-blur-[2px]"
                onClick={() => navigate('/account')}
              >
                <span>Sign In to Portal</span>
              </LiquidButton>
            </div>

            {/* Institutional Trust Line */}
            <div className="mt-7 sm:mt-8 flex flex-wrap items-center justify-center gap-x-3.5 gap-y-1.5 text-xs sm:text-[13px] font-medium text-[var(--ink-secondary)] pt-5 border-t border-[var(--border-strong)]/70 dark:border-[#303032] w-full max-w-xl">
              <span>Manglia Square, Indore</span>
              <span aria-hidden="true" className="text-[#C01E30]/75 dark:text-[#D93848]/80">·</span>
              <span>Backed by AIIH Foundation</span>
              <span aria-hidden="true" className="text-[#C01E30]/75 dark:text-[#D93848]/80">·</span>
              <span>IIC (MoE Innovation Cell) Affiliated</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 2. Flagship Conclave Showcase */}
      <section className="border-b border-[var(--border-hairline)] bg-[var(--surface)] dark:bg-[#151517]">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-12 sm:py-16 lg:py-20">
          <AnimatedContent distance={32} duration={0.7} threshold={0.1}>
            <div>
              {/* Top Editorial Rule & Monograph Identifier */}
              <div className="flex flex-wrap items-center justify-between gap-3 pb-4 sm:pb-5 border-b border-[var(--border-hairline)]">
                <p className="font-mono-data text-[11px] sm:text-xs font-medium uppercase tracking-[0.14em] text-[#C01E30] dark:text-[#D93848]">
                  {fokusIsClosed ? 'FLAGSHIP CONCLAVE / ARCHIVE · 2026' : 'FLAGSHIP CONCLAVE / 2026'}
                </p>
                <p className="font-mono-data text-[11px] tracking-[0.06em] text-[var(--ink-muted)]">
                  EDC AITR · Acropolis Indore
                </p>
              </div>

              {/* Asymmetric Typography-Led Editorial Body */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 pt-7 sm:pt-9 items-start">
                {/* Left Register: Dominant Event Identity & Structured Metadata */}
                <div className="lg:col-span-6">
                  <h2 className="m-0">
                    <span
                      className="block font-display font-bold tracking-[-0.035em] leading-[0.98] text-[var(--color-2-mood)]"
                      style={{ fontSize: 'clamp(2.5rem, 4.6vw, 3.6rem)' }}
                    >
                      FOKUS <span className="text-[#C01E30] dark:text-[#D93848]">X</span>
                    </span>
                    <span className="sr-only"> </span>
                    <span className="mt-2.5 block font-display font-medium tracking-[-0.015em] text-lg sm:text-xl lg:text-[1.375rem] text-[var(--ink-secondary)]">
                      E-Summit 2026
                    </span>
                  </h2>

                  <dl className="mt-6 sm:mt-8 pt-5 border-t border-[var(--border-hairline)] grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                    <div>
                      <dt className="font-mono-data text-[11px] uppercase tracking-[0.1em] text-[var(--ink-muted)]">
                        Schedule
                      </dt>
                      <dd className="mt-1 text-sm sm:text-[15px] font-medium text-[var(--color-2-mood)]">
                        {fokusDateLabel}
                      </dd>
                    </div>
                    <div>
                      <dt className="font-mono-data text-[11px] uppercase tracking-[0.1em] text-[var(--ink-muted)]">
                        Venue
                      </dt>
                      <dd className="mt-1 text-sm sm:text-[15px] font-medium text-[var(--color-2-mood)]">
                        AITR Main Auditorium, Indore
                      </dd>
                    </div>
                  </dl>
                </div>

                {/* Right Register: Factual Event Summary & Integrated Action */}
                <div className="lg:col-span-6 lg:border-l lg:border-[var(--border-hairline)] lg:pl-10 xl:pl-12 flex flex-col justify-between">
                  <p className="text-base sm:text-[1.0625rem] text-[var(--ink-secondary)] leading-[1.7] max-w-[52ch]">
                    Three days of keynote firesides, PitchBiz live investor evaluations, startup expo pavilions, and operator workshops at AITR Main Auditorium, Indore.
                  </p>

                  <div className="mt-7 sm:mt-8 flex flex-wrap items-center gap-4">
                    <LiquidButton
                      variant="obsidian"
                      onClick={() => navigate('/events/fokus-x-e-summit-2026')}
                    >
                      <span>View Summit Details</span>
                      <ArrowUpRight className="h-4 w-4" />
                    </LiquidButton>
                  </div>
                </div>
              </div>
            </div>
          </AnimatedContent>
        </div>
      </section>

      {/* 3. Numbers That We Hit (Editorial Impact Ledger) */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-6 py-16 sm:py-20 lg:py-24">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 sm:pb-8 border-b border-[var(--border-hairline)]">
          <div>
            <p className="font-mono-data text-[11px] sm:text-xs font-medium uppercase tracking-[0.14em] text-[#C01E30] dark:text-[#D93848] mb-2">
              Institutional Track Record
            </p>
            <h2
              className="font-display font-bold tracking-[-0.025em] leading-[1.08] text-[var(--color-2-mood)]"
              style={{ fontSize: 'clamp(1.75rem, 3vw, 2.5rem)' }}
            >
              Numbers That We Hit
            </h2>
          </div>
          <p className="text-sm sm:text-[15px] text-[var(--ink-secondary)] leading-relaxed max-w-[44ch]">
            Audited ecosystem outcomes across Acropolis Indore, AIIH Foundation cohorts, and state-backed innovation pipelines.
          </p>
        </div>

        <AnimatedContent distance={36} duration={0.7} threshold={0.1}>
          {(() => {
            const [primaryMetric, ...remainingMetrics] = IMPACT_METRICS;
            const secondaryMetrics = remainingMetrics.slice(0, 2);
            const supportingMetrics = remainingMetrics.slice(2);

            return (
              <div className="border-b border-[var(--border-hairline)]">
                {/* Upper Tier: Primary Anchor Metric + Secondary Pillar Metrics */}
                <div className="grid grid-cols-1 lg:grid-cols-12">
                  {primaryMetric && (
                    <div className="lg:col-span-6 bg-[var(--surface)] dark:bg-[#171719] px-5 sm:px-8 lg:px-10 py-8 sm:py-10 lg:py-12 border-b lg:border-b-0 lg:border-r border-[var(--border-hairline)] flex flex-col justify-between">
                      <div className="flex items-center justify-between gap-3">
                        <span className="font-mono-data text-[11px] font-medium tracking-[0.12em] text-[#C01E30] dark:text-[#D93848]">
                          01
                        </span>
                        <span className="h-px flex-1 max-w-12 bg-[#C01E30]/35 dark:bg-[#D93848]/40" aria-hidden="true" />
                      </div>

                      <div className="mt-6 sm:mt-8">
                        <p
                          className="leading-[0.98] text-[#C01E30] dark:text-[#D93848] whitespace-nowrap"
                          style={{ fontSize: 'clamp(3.1rem, 5.2vw, 4.65rem)' }}
                        >
                          <RollingStat
                            value={primaryMetric.value}
                            editorial
                            replayOnHover={false}
                            duration={1.15}
                            delay={0}
                          />
                        </p>
                        <p className="mt-4 sm:mt-5 text-lg sm:text-xl font-semibold tracking-[-0.01em] text-[var(--color-2-mood)]">
                          {primaryMetric.label}
                        </p>
                        <p className="mt-2 text-sm sm:text-[15px] text-[var(--ink-secondary)] leading-[1.6] max-w-[38ch]">
                          {primaryMetric.detail}
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 divide-y sm:divide-y-0 sm:divide-x lg:divide-x-0 lg:divide-y divide-[var(--border-hairline)]">
                    {secondaryMetrics.map((metric, idx) => (
                      <div
                        key={metric.label}
                        className="px-5 sm:px-7 lg:px-10 py-7 sm:py-8 lg:py-9 flex flex-col justify-center"
                      >
                        <span className="font-mono-data text-[11px] font-medium tracking-[0.12em] text-[var(--ink-muted)]">
                          0{idx + 2}
                        </span>
                        <p
                          className="mt-3 leading-[1.02] text-[var(--color-2-mood)] whitespace-nowrap"
                          style={{ fontSize: 'clamp(2.25rem, 3.3vw, 3.05rem)' }}
                        >
                          <RollingStat
                            value={metric.value}
                            editorial
                            replayOnHover={false}
                            duration={1.15}
                            delay={0.08 + idx * 0.06}
                          />
                        </p>
                        <p className="mt-2.5 text-base font-semibold text-[var(--color-2-mood)]">
                          {metric.label}
                        </p>
                        <p className="mt-1.5 text-sm text-[var(--ink-secondary)] leading-[1.58] max-w-[44ch]">
                          {metric.detail}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Lower Tier: Supporting Institutional Metrics */}
                <div className="border-t border-[var(--border-hairline)] grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-[var(--border-hairline)]">
                  {supportingMetrics.map((metric, idx) => (
                    <div
                      key={metric.label}
                      className="px-5 sm:px-6 lg:px-8 py-7 sm:py-8 flex flex-col justify-between"
                    >
                      <div>
                        <span className="font-mono-data text-[11px] font-medium tracking-[0.12em] text-[var(--ink-muted)]">
                          0{idx + 4}
                        </span>
                        <p
                          className="mt-3 leading-[1.06] text-[var(--color-2-mood)] whitespace-nowrap"
                          style={{ fontSize: 'clamp(1.75rem, 2.3vw, 2.25rem)' }}
                        >
                          <RollingStat
                            value={metric.value}
                            editorial
                            replayOnHover={false}
                            duration={1.05}
                            delay={0.18 + idx * 0.05}
                          />
                        </p>
                        <p className="mt-2.5 text-sm sm:text-[15px] font-semibold text-[var(--color-2-mood)]">
                          {metric.label}
                        </p>
                      </div>
                      <p className="mt-2 text-xs sm:text-[13px] text-[var(--ink-muted)] leading-[1.6] max-w-[34ch]">
                        {metric.detail}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            );
          })()}
        </AnimatedContent>
      </section>

      {/* 4. Our Initiatives (Interactive AccordionGallery) */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-6 pb-16 sm:pb-20 lg:pb-24">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 sm:pb-8 border-b border-[var(--border-hairline)] mb-7 sm:mb-8">
          <div>
            <p className="font-mono-data text-[11px] sm:text-xs font-medium uppercase tracking-[0.14em] text-[#C01E30] dark:text-[#D93848] mb-2">
              Year-Round Programs
            </p>
            <h2
              className="font-display font-bold tracking-[-0.025em] leading-[1.08] text-[var(--color-2-mood)]"
              style={{ fontSize: 'clamp(1.75rem, 3vw, 2.5rem)' }}
            >
              Our Initiatives
            </h2>
          </div>
          <button
            type="button"
            onClick={() => navigate('/events')}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-[var(--color-2-mood)] hover:text-[#C01E30] dark:hover:text-[#D93848] transition-colors cursor-pointer self-start sm:self-auto whitespace-nowrap"
          >
            <span>View Full Event Calendar</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <AnimatedContent distance={36} duration={0.7} threshold={0.1}>
          <div>
            <AccordionGallery
              items={galleryItems}
              defaultIndex={0}
              orientation={heroViewport === 'mobile' ? 'vertical' : 'horizontal'}
              accentColor="#C01E30"
              overlayColor="#101011"
              textColor="#ffffff"
              height={heroViewport === 'mobile' ? 540 : heroViewport === 'tablet' ? 390 : 440}
              gap={heroViewport === 'mobile' ? 8 : 10}
              radius={8}
              expandRatio={heroViewport === 'mobile' ? 0.44 : 0.52}
              tilt={0}
              parallax={0.3}
              trigger={heroViewport === 'mobile' ? 'click' : 'hover'}
              grayscale
              inactiveGrayscale={0.32}
              inactiveDim={0.28}
              onActiveChange={(idx) => setActiveInitiativeIdx(idx)}
            />

            {/* Synchronized Editorial Detail Strip Connected Directly to Active Panel */}
            {activeInitiative && (
              <div
                aria-live="polite"
                className="mt-6 sm:mt-7 pt-6 sm:pt-7 border-t border-b border-[var(--border-hairline)] pb-6 sm:pb-7"
              >
                <AnimatePresence mode="wait" initial={false}>
                  <motion.div
                    key={activeInitiative.code}
                    initial={reducedMotion ? false : { opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={reducedMotion ? { opacity: 1 } : { opacity: 0, y: -4 }}
                    transition={{
                      duration: reducedMotion ? 0.01 : 0.22,
                      ease: MOTION_TRACKS.publicEditorial.ease,
                    }}
                    className="grid grid-cols-1 lg:grid-cols-12 gap-5 lg:gap-8 items-start lg:items-center"
                  >
                    <div className="lg:col-span-9">
                      <div className="flex flex-wrap items-center gap-2.5 text-xs">
                        <span className="font-mono-data font-medium uppercase tracking-[0.12em] text-[#C01E30] dark:text-[#D93848]">
                          {String(activeInitiativeIdx + 1).padStart(2, '0')} · {activeInitiative.code}
                        </span>
                        <span aria-hidden="true" className="text-[var(--border-strong)]">/</span>
                        <span className="font-mono-data text-[11px] tracking-[0.04em] text-[var(--ink-muted)]">
                          {activeInitiative.cadence}
                        </span>
                      </div>
                      <h3 className="mt-2 text-xl sm:text-2xl font-display font-bold tracking-[-0.02em] text-[var(--color-2-mood)]">
                        {activeInitiative.title}
                      </h3>
                      <p className="mt-2 text-sm sm:text-[15px] text-[var(--ink-secondary)] leading-[1.65] max-w-[64ch]">
                        {activeInitiative.summary}
                      </p>
                    </div>
                    <div className="lg:col-span-3 flex lg:justify-end">
                      <StudioButton
                        variant="secondary"
                        size="sm"
                        onClick={() => navigate(`/events/${activeInitiative.linkedSlug}`)}
                      >
                        <span>Inspect Program</span>
                        <ArrowUpRight className="h-3.5 w-3.5" />
                      </StudioButton>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>
            )}
          </div>
        </AnimatedContent>
      </section>

      {/* 5. Campus Startup Initiative (CSI) Deep-Dive Feature */}
      <section className="border-y border-[var(--border-hairline)] bg-[var(--surface)] dark:bg-[#151517]">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-16 sm:py-20 lg:py-24">
          <AnimatedContent distance={40} duration={0.72} threshold={0.1}>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
              {/* Left: Prominent Editorial Photography */}
              <div className="lg:col-span-5 flex flex-col">
                <div className="flex-1 min-h-[280px] sm:min-h-[340px] lg:min-h-[450px] rounded-[6px] overflow-hidden border border-[var(--border-hairline)] bg-[var(--surface-subtle)]">
                  <EditorialImage
                    src={EDITORIAL_IMAGES.csiFablab}
                    alt="AIIH Foundation & CSI Hardware Prototyping FabLab"
                    fallbackTitle="CSI Prototyping FabLab"
                    className="w-full h-full object-cover"
                  />
                </div>
                <p className="mt-3 font-mono-data text-[11px] tracking-[0.06em] text-[var(--ink-muted)]">
                  AIIH Foundation Prototyping Lab · Acropolis Indore
                </p>
              </div>

              {/* Right: Institutional Program Narrative & Structured Capabilities */}
              <div className="lg:col-span-7 flex flex-col justify-between">
                <div>
                  <div className="flex flex-wrap items-center gap-2.5 text-xs">
                    <span className="font-mono-data text-[11px] sm:text-xs font-medium uppercase tracking-[0.14em] text-[#C01E30] dark:text-[#D93848]">
                      CSI · 8-Month Cohort
                    </span>
                    <span aria-hidden="true" className="text-[var(--border-strong)]">/</span>
                    <span className="font-mono-data text-[11px] tracking-[0.05em] text-[var(--ink-muted)]">
                      AIIH Foundation Pre-Incubation
                    </span>
                  </div>

                  <h2
                    className="mt-3 font-display font-bold tracking-[-0.025em] leading-[1.08] text-[var(--color-2-mood)]"
                    style={{ fontSize: 'clamp(1.75rem, 3vw, 2.5rem)' }}
                  >
                    Campus Startup Initiative (CSI)
                  </h2>

                  <p className="mt-4 text-base sm:text-[1.0625rem] text-[var(--ink-secondary)] leading-[1.68] max-w-[56ch]">
                    Structured venture pre-incubation taking student ideas from lab bench to incorporation, DPIIT registration, and investor demo day without taking founder equity at entry.
                  </p>
                </div>

                {/* Hairline-Separated 3-Capability Ledger */}
                <div className="mt-8 pt-7 border-t border-[var(--border-hairline)] grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-[var(--border-hairline)]">
                  <div className="pb-5 sm:pb-0 sm:pr-6">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono-data text-[11px] tracking-[0.12em] text-[var(--ink-muted)]">
                        01
                      </span>
                      <Cpu className="h-4 w-4 text-[#C01E30] dark:text-[#D93848]" strokeWidth={1.75} />
                    </div>
                    <h3 className="mt-3 text-sm sm:text-[15px] font-semibold text-[var(--color-2-mood)]">
                      Prototyping FabLabs
                    </h3>
                    <p className="mt-1.5 text-xs sm:text-[13px] text-[var(--ink-secondary)] leading-[1.6]">
                      Direct access to 3D printers, PCB workbenches, and IoT testing bays inside AIIH.
                    </p>
                  </div>

                  <div className="py-5 sm:py-0 sm:px-6">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono-data text-[11px] tracking-[0.12em] text-[var(--ink-muted)]">
                        02
                      </span>
                      <Cloud className="h-4 w-4 text-[#C01E30] dark:text-[#D93848]" strokeWidth={1.75} />
                    </div>
                    <h3 className="mt-3 text-sm sm:text-[15px] font-semibold text-[var(--color-2-mood)]">
                      Cloud Credits
                    </h3>
                    <p className="mt-1.5 text-xs sm:text-[13px] text-[var(--ink-secondary)] leading-[1.6]">
                      Verified startup sandboxes via AWS Activate and Google Cloud for Startups.
                    </p>
                  </div>

                  <div className="pt-5 sm:pt-0 sm:pl-6">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono-data text-[11px] tracking-[0.12em] text-[var(--ink-muted)]">
                        03
                      </span>
                      <Users className="h-4 w-4 text-[#C01E30] dark:text-[#D93848]" strokeWidth={1.75} />
                    </div>
                    <h3 className="mt-3 text-sm sm:text-[15px] font-semibold text-[var(--color-2-mood)]">
                      1-on-1 Mentorship
                    </h3>
                    <p className="mt-1.5 text-xs sm:text-[13px] text-[var(--ink-secondary)] leading-[1.6]">
                      Bi-weekly founder clinics with TiE MP operators, IP attorneys, and alumni CTOs.
                    </p>
                  </div>
                </div>

                {/* Program Actions */}
                <div className="mt-8 pt-6 border-t border-[var(--border-hairline)] flex flex-wrap items-center gap-3.5">
                  <LiquidButton
                    variant="crimson"
                    onClick={() => navigate('/contact?tab=csi')}
                  >
                    <span>Apply for CSI Pre-Incubation</span>
                  </LiquidButton>
                  <StudioButton
                    variant="secondary"
                    onClick={() => navigate('/about')}
                  >
                    <span>Read AIIH Incubation Pipeline</span>
                  </StudioButton>
                </div>
              </div>
            </div>
          </AnimatedContent>
        </div>
      </section>

      {/* 6. Guests We Hosted (Interactive Coverflow Speaker Archive) */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-6 py-16 sm:py-20 lg:py-24">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 sm:pb-8 border-b border-[var(--border-hairline)] mb-8">
          <div>
            <p className="font-mono-data text-[11px] sm:text-xs font-medium uppercase tracking-[0.14em] text-[#C01E30] dark:text-[#D93848] mb-2">
              Speaker Archive
            </p>
            <h2
              className="font-display font-bold tracking-[-0.025em] leading-[1.08] text-[var(--color-2-mood)]"
              style={{ fontSize: 'clamp(1.75rem, 3vw, 2.5rem)' }}
            >
              Guests We Hosted
            </h2>
          </div>
          <p className="text-xs sm:text-[13px] text-[var(--ink-muted)]">
            Drag, click, or use arrow keys to explore past keynote speakers
          </p>
        </div>

        <AnimatedContent distance={32} duration={0.7} threshold={0.1}>
          <GuestCoverflow guests={MARQUEE_GUESTS} />
        </AnimatedContent>
      </section>

      {/* 7. Organisations That Back Us (Editorial Partner Wordmark Marquee) */}
      <section className="border-y border-[var(--border-hairline)] bg-[var(--surface)]/55 dark:bg-[#141416] mb-12 sm:mb-16">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-14 sm:py-16 lg:py-20">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pb-6 border-b border-[var(--border-hairline)] mb-8">
            <div>
              <p className="font-mono-data text-[11px] sm:text-xs font-medium uppercase tracking-[0.14em] text-[#C01E30] dark:text-[#D93848] mb-2">
                Institutional &amp; Investor Backing
              </p>
              <h2
                className="font-display font-bold tracking-[-0.025em] leading-[1.08] text-[var(--color-2-mood)]"
                style={{ fontSize: 'clamp(1.75rem, 3vw, 2.5rem)' }}
              >
                Organisations That Back Us
              </h2>
            </div>
            {!reducedMotion && (
              <p className="text-xs text-[var(--ink-muted)]">
                Hover to pause · Drag to explore ecosystem partners
              </p>
            )}
          </div>

          <AnimatedContent distance={28} duration={0.65} threshold={0.1}>
            {reducedMotion ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-y-6 gap-x-8">
                {PARTNER_ORGANIZATIONS.map((partner) => (
                  <div
                    key={partner.name}
                    className="border-l border-[var(--border-hairline)] pl-5 py-1"
                  >
                    <p className="text-base font-display font-semibold tracking-[-0.015em] text-[var(--color-2-mood)]">
                      {partner.name}
                    </p>
                    <p className="text-xs text-[var(--ink-secondary)] mt-1">
                      {partner.role}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-2">
                <LogoLoop
                  logos={partnerLogos}
                  speed={30}
                  gap={44}
                  logoHeight={56}
                  hoverSpeed={0}
                  fadeOut
                  fadeOutWidth={0.1}
                  scaleOnHover={false}
                  draggable
                  ariaLabel="Institutional and investor partner organizations"
                />
              </div>
            )}
          </AnimatedContent>
        </div>
      </section>

      {/* 8. Reach Out to Us (3-Way Intake) */}
      <section className="max-w-[1200px] mx-auto px-4 sm:px-6 pb-8">
        <AnimatedContent distance={48} duration={0.75} threshold={0.1}>
          <div className="studio-card p-6 sm:p-8 lg:p-10">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-[var(--border-hairline)]">
              <div>
                <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171] mb-1.5">Direct Institutional Intake</p>
                <h2 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)]">
                  Reach Out to Us
                </h2>
              </div>
              <a
                href="https://instagram.com/edc_acropolis"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-sm font-medium text-[var(--color-2-mood)] border border-[var(--border-strong)] rounded-[9px] px-3.5 py-2 hover:border-[#C01E30] hover:text-[#C01E30] transition-colors self-start md:self-auto"
              >
                <Instagram className="h-4 w-4" />
                <span>@edc_acropolis</span>
                <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
              <div className="space-y-3 flex flex-col justify-between">
                <div className="space-y-1.5">
                  <p className="text-xs font-mono-data text-[var(--ink-muted)]">01 · Founders</p>
                  <h3 className="text-base font-display font-semibold text-[var(--color-2-mood)]">Student Founders</h3>
                  <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">
                    Pitch for CSI Cohort 06 pre-incubation, AIIH prototyping fablab hours, or DPIIT &amp; NIDHI-EIR grant guidance.
                  </p>
                </div>
                <StudioButton
                  variant="secondary"
                  size="sm"
                  onClick={() => navigate('/contact?tab=csi')}
                  className="self-start"
                >
                  <span>Submit Startup Brief</span>
                </StudioButton>
              </div>

              <div className="space-y-3 flex flex-col justify-between md:border-l md:border-[var(--border-hairline)] md:pl-6">
                <div className="space-y-1.5">
                  <p className="text-xs font-mono-data text-[var(--ink-muted)]">02 · Partners</p>
                  <h3 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
                    Corporate Sponsors &amp; VCs
                  </h3>
                  <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">
                    Partner with FOKUS X E-Summit 2026, judge PitchBiz Investment Arena, or sponsor Kriyeta hackathon tracks.
                  </p>
                </div>
                <StudioButton
                  variant="secondary"
                  size="sm"
                  onClick={() => navigate('/contact?tab=sponsorship')}
                  className="self-start"
                >
                  <Handshake className="h-3.5 w-3.5" />
                  <span>Request Partnership Deck</span>
                </StudioButton>
              </div>

              <div className="space-y-3 flex flex-col justify-between md:border-l md:border-[var(--border-hairline)] md:pl-6">
                <div className="space-y-1.5">
                  <p className="text-xs font-mono-data text-[var(--ink-muted)]">03 · Recruitment</p>
                  <h3 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
                    Student Team Applicants
                  </h3>
                  <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">
                    Join one of the 12 operational divisions powering Acropolis Indore’s flagship entrepreneurship events.
                  </p>
                </div>
                <LiquidButton
                  variant="crimson"
                  size="sm"
                  onClick={() => navigate('/account/apply')}
                  className="self-start"
                >
                  <span>Apply to Join EDC</span>
                </LiquidButton>
              </div>
            </div>

            <div className="mt-8 pt-5 border-t border-[var(--border-hairline)] flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-[var(--ink-muted)]">
              <span className="inline-flex items-center gap-1.5">
                <MapPin className="h-3.5 w-3.5 text-[#C01E30]" />
                <span>Acropolis Institute of Technology &amp; Research, Manglia Square, Indore</span>
              </span>
            </div>
          </div>
        </AnimatedContent>
      </section>
    </div>
  );
};
