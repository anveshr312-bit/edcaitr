import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowUpRight,
  Calendar,
  Layers,
  MapPin,
  Ticket,
  Users,
} from 'lucide-react';
import { usePortal } from '../../context/PortalContext';
import { EventCategory, EventItem } from '../../types/portal';
import {
  EditorialImage,
  MonogramAvatar,
  StatusBadge,
  StudioButton,
} from '../../components/ui/Primitives';
import { LiquidButton } from '../../components/ui/LiquidButton';
import { AnimatedContent } from '../../components/ui/AnimatedContent';
import { GooeySearch } from '../../components/ui/GooeySearch';
import { KineticHeading } from '../../components/ui/KineticHeading';
import { SpotlightCard } from '../../components/ui/SpotlightCard';
import { DynamicTrackRegistrationModal } from '../../components/events/DynamicTrackRegistrationModal';
import {
  getActiveTrackPrice,
  getEffectiveTracks,
  getEventPricingSummary,
  getTrackAvailability,
  isMultiTrackEvent,
} from '../../utils/eventTracks';

const EVENT_FILTERS: ('All' | EventCategory)[] = ['All', 'Conclaves', 'Hackathons', 'Bootcamps'];

export const EventsListPage: React.FC = () => {
  const { events, registrations, navigate } = usePortal();
  const [category, setCategory] = useState<'All' | EventCategory>('All');
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    return events.filter((evt) => {
      const matchCat = category === 'All' || evt.category === category;
      const q = query.trim().toLowerCase();
      const matchSearch =
        !q ||
        evt.title.toLowerCase().includes(q) ||
        evt.venue.toLowerCase().includes(q) ||
        evt.subtitle.toLowerCase().includes(q);
      return matchCat && matchSearch;
    });
  }, [events, category, query]);

  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 sm:py-12">
      <AnimatedContent
        trigger="mount"
        distance={28}
        duration={0.65}
        className="flex flex-col md:flex-row md:items-end justify-between gap-5 pb-8 border-b border-[var(--border-hairline)]"
      >
        <div className="space-y-2">
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Official Campus Calendar</p>
          <KineticHeading
            as="h1"
            text="Events & Flagship"
            accentText="Conclaves"
            replayKey="events-hero-headline"
            immediate
            className="text-3xl sm:text-4xl font-display font-semibold text-[var(--color-2-mood)]"
          />
          <p className="text-sm sm:text-base text-[var(--ink-secondary)] max-w-2xl">
            Register for upcoming conclaves, national hackathons, and founder bootcamps organized by EDC AITR and AIIH Foundation.
          </p>
        </div>

        <div className="flex items-center md:justify-end shrink-0">
          <GooeySearch
            items={events.map((evt) => evt.title)}
            value={query}
            onQueryChange={setQuery}
            buttonLabel="Search Events"
            placeholder="Event or venue..."
            onSelect={(title) => {
              const matched = events.find((evt) => evt.title === title);
              if (matched) {
                navigate(`/events/${matched.slug}`);
              } else {
                setQuery(title);
              }
            }}
          />
        </div>
      </AnimatedContent>

      {/* Interactive Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 py-6">
        {EVENT_FILTERS.map((item) => {
          const active = category === item;
          return (
            <button
              key={item}
              type="button"
              onClick={() => setCategory(item)}
              className={`px-3.5 py-2 text-xs font-medium rounded-[9px] border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                active
                  ? 'bg-[#030405] dark:bg-[#F1F0ED] text-white dark:text-[#101011] border-[#030405] dark:border-[#F1F0ED]'
                  : 'bg-[var(--surface)] text-[var(--ink-secondary)] border-[var(--border-hairline)] hover:border-[var(--border-strong)]'
              }`}
            >
              {item}
            </button>
          );
        })}
      </div>

      {filtered.length === 0 ? (
        <div className="studio-card p-10 text-center space-y-3">
          <p className="text-base font-semibold text-[var(--color-2-mood)]">No matching events found</p>
          <p className="text-sm text-[var(--ink-muted)]">
            Try clearing your search query or switching to the All category.
          </p>
          <StudioButton
            variant="secondary"
            size="sm"
            onClick={() => {
              setCategory('All');
              setQuery('');
            }}
          >
            Reset Filters
          </StudioButton>
        </div>
      ) : (
        <AnimatedContent
          key={`${category}-${query}`}
          trigger="mount"
          distance={40}
          duration={0.7}
          stagger={0.07}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          {filtered.map((evt) => {
            const count = registrations.filter(
              (r) => r.eventId === evt.id && r.paymentStatus !== 'Rejected'
            ).length;
            const ratio = evt.capacity ? Math.min(100, Math.round((count / evt.capacity) * 100)) : null;
            const summary = getEventPricingSummary(evt, registrations);

            return (
              <SpotlightCard
                key={evt.id}
                className="studio-card overflow-hidden flex flex-col justify-between hover:border-[var(--border-strong)] transition-colors"
              >
                <div>
                  <div className="relative aspect-[16/9] bg-[var(--surface-subtle)] border-b border-[var(--border-hairline)] overflow-hidden">
                    <EditorialImage
                      src={evt.bannerImage}
                      alt={evt.bannerAlt || evt.title}
                      objectPosition={evt.bannerPosition}
                      fallbackTitle={evt.title}
                      className="w-full h-full object-cover"
                    />
                    {summary.isMultiTrack && summary.enabledTrackCount > 1 && (
                      <div className="absolute top-3 left-3">
                        <StatusBadge
                          label={`${summary.enabledTrackCount} Registration Categories`}
                          tone="obsidian"
                        />
                      </div>
                    )}
                  </div>
                  <div className="p-6 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[var(--ink-muted)]">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-[#C01E30] dark:text-[#F87171]">
                          {evt.category}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono-data">{evt.dateLabel}</span>
                      </div>
                      <span className="font-mono-data font-semibold text-[var(--color-2-mood)]">
                        {summary.label}
                      </span>
                    </div>

                    <h2 className="text-xl font-display font-semibold text-[var(--color-2-mood)] leading-snug">
                      {evt.title}
                    </h2>
                    <p className="text-sm text-[var(--ink-secondary)] leading-relaxed">
                      {evt.subtitle}
                    </p>

                    {summary.isMultiTrack && summary.trackNamesPreview.length > 0 && (
                      <p className="text-[11px] text-[var(--ink-muted)] flex items-center gap-1.5">
                        <Layers className="h-3.5 w-3.5 shrink-0 text-[#C01E30]" />
                        <span className="truncate">
                          Tracks: {summary.trackNamesPreview.join(' · ')}
                          {summary.enabledTrackCount > summary.trackNamesPreview.length
                            ? ` +${summary.enabledTrackCount - summary.trackNamesPreview.length} more`
                            : ''}
                        </span>
                      </p>
                    )}

                    <div className="pt-2 space-y-2 text-xs text-[var(--ink-muted)]">
                      <p className="inline-flex items-center gap-1.5">
                        <MapPin className="h-3.5 w-3.5 shrink-0 text-[var(--ink-secondary)]" />
                        <span>{evt.venue}</span>
                      </p>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between font-mono-data">
                          <span>Registered: {count}</span>
                          <span>{evt.capacity ? `Capacity: ${evt.capacity}` : 'Unlimited seats'}</span>
                        </div>
                        {ratio !== null && (
                          <div className="h-1.5 w-full bg-[var(--surface-subtle)] rounded-[4px] overflow-hidden">
                            <div
                              className="h-full bg-[#C01E30]"
                              style={{ width: `${Math.max(6, ratio)}%` }}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="px-6 py-4 bg-[var(--color-1-mood)] border-t border-[var(--border-hairline)] flex items-center justify-between gap-3">
                  <StatusBadge
                    label={
                      evt.status === 'Closed' || summary.openTrackCount === 0
                        ? 'Registration Closed'
                        : 'Registrations Open'
                    }
                    tone={
                      evt.status === 'Closed' || summary.openTrackCount === 0 ? 'neutral' : 'crimson'
                    }
                  />
                  <StudioButton
                    variant="secondary"
                    size="sm"
                    onClick={() => navigate(`/events/${evt.slug}`)}
                  >
                    <span>View Details</span>
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </StudioButton>
                </div>
              </SpotlightCard>
            );
          })}
        </AnimatedContent>
      )}
    </div>
  );
};

export const EventDetailPage: React.FC<{ slug: string }> = ({ slug }) => {
  const { events, registrations, users, currentUser, navigate, registerForEvent, pushToast } =
    usePortal();
  const evt: EventItem | undefined = events.find((e) => e.slug === slug) ?? events[0];

  const [modalOpen, setModalOpen] = useState(false);
  const [preselectedTrackId, setPreselectedTrackId] = useState<string | undefined>(undefined);

  if (!evt) return null;

  const eventRegs = registrations.filter(
    (r) => r.eventId === evt.id && r.paymentStatus !== 'Rejected'
  );
  const capacityPct = evt.capacity
    ? Math.min(100, Math.round((eventRegs.length / evt.capacity) * 100))
    : 0;
  const spocPrimary = users.find((u) => u.id === evt.spocPrimaryId);
  const spocSecondary = users.find((u) => u.id === evt.spocSecondaryId);

  const effectiveTracks = getEffectiveTracks(evt);
  const visibleTracks = effectiveTracks.filter((t) => t.visible !== false);
  const multiTrack = isMultiTrackEvent(evt);
  const pricingSummary = getEventPricingSummary(evt, registrations);

  const openRegistrationModal = (trackId?: string) => {
    setPreselectedTrackId(trackId);
    setModalOpen(true);
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-8 sm:py-12">
      <button
        type="button"
        onClick={() => navigate('/events')}
        className="inline-flex items-center gap-1.5 text-sm font-medium text-[var(--ink-secondary)] hover:text-[#C01E30] mb-6 cursor-pointer"
      >
        <ArrowLeft className="h-4 w-4" />
        <span>Back to Events</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Main Event Editorial Column */}
        <div className="lg:col-span-8 space-y-8">
          <AnimatedContent trigger="mount" distance={32} duration={0.7}>
            <div className="studio-card overflow-hidden">
              <div className="aspect-[16/9] bg-[var(--surface-subtle)] border-b border-[var(--border-hairline)] overflow-hidden">
                <EditorialImage
                  src={evt.bannerImage}
                  alt={evt.bannerAlt || evt.title}
                  objectPosition={evt.bannerPosition}
                  fallbackTitle={evt.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6 sm:p-8 space-y-4">
                <div className="flex flex-wrap items-center gap-2.5 text-xs text-[var(--ink-muted)]">
                  <span className="font-medium text-[#C01E30] dark:text-[#F87171]">
                    {evt.category}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-data">{evt.dateLabel}</span>
                  <span aria-hidden="true">·</span>
                  <span>
                    {evt.status === 'Closed' ? 'Archived' : 'Open for Registration'}
                  </span>
                </div>
                <h1 className="text-2xl sm:text-4xl font-display font-semibold text-[var(--color-2-mood)] leading-tight">
                  {evt.title}
                </h1>
                <p className="text-base text-[var(--ink-secondary)] leading-relaxed">
                  {evt.description}
                </p>
              </div>
            </div>
          </AnimatedContent>

          {/* Multi-Track Participation Categories Showcase */}
          {multiTrack && visibleTracks.length > 0 && (
            <AnimatedContent distance={36} duration={0.65} threshold={0.1}>
              <div className="studio-card p-6 sm:p-8 space-y-5">
                <div className="flex flex-wrap items-end justify-between gap-3 pb-4 border-b border-[var(--border-hairline)]">
                  <div>
                    <p className="font-mono text-[11px] uppercase tracking-wider text-[#C01E30] dark:text-[#E67C87]">
                      Participant Tracks
                    </p>
                    <h2 className="text-xl font-display font-semibold text-[var(--color-2-mood)] mt-0.5">
                      How would you like to participate?
                    </h2>
                    <p className="text-xs text-[var(--ink-muted)] mt-1">
                      Select the category matching your role. Each category uses its own tailored form,
                      pricing, and seat allocation.
                    </p>
                  </div>
                  <StatusBadge
                    label={`${pricingSummary.openTrackCount} of ${visibleTracks.length} Open`}
                    tone={pricingSummary.openTrackCount > 0 ? 'green' : 'neutral'}
                  />
                </div>

                <div className="grid grid-cols-1 gap-3.5">
                  {visibleTracks.map((track) => {
                    const avail = getTrackAvailability(evt, track, registrations);
                    const price = getActiveTrackPrice(track);
                    const isPaidTrack = track.pricing.type === 'paid' && price.amountInr > 0;
                    return (
                      <div
                        key={track.id}
                        className={`p-5 rounded-[10px] border transition-colors ${
                          avail.canRegister
                            ? 'border-[var(--border-hairline)] bg-[var(--surface-subtle)] hover:border-[var(--border-strong)]'
                            : 'border-[var(--border-hairline)] bg-[var(--surface-subtle)] opacity-65'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                          <div className="space-y-1.5 min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <h3 className="text-base font-display font-semibold text-[var(--color-2-mood)]">
                                {track.name}
                              </h3>
                              <StatusBadge label={avail.statusLabel} tone={avail.statusTone} />
                            </div>
                            <p className="text-xs sm:text-sm text-[var(--ink-secondary)] leading-relaxed">
                              {track.description}
                            </p>
                            {track.eligibility && (
                              <p className="text-xs text-[var(--ink-muted)] pt-1">
                                <span className="font-medium text-[var(--ink-secondary)]">
                                  Eligibility:
                                </span>{' '}
                                {track.eligibility}
                              </p>
                            )}
                            {track.pricing.feeDescription && (
                              <p className="text-xs text-[var(--ink-muted)]">
                                <span className="font-medium text-[var(--ink-secondary)]">
                                  Includes:
                                </span>{' '}
                                {track.pricing.feeDescription}
                              </p>
                            )}
                          </div>

                          <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2.5 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-[var(--border-hairline)]">
                            <div className="sm:text-right">
                              <p className="font-mono text-xl font-semibold text-[var(--color-2-mood)]">
                                {isPaidTrack ? `₹${price.amountInr}` : 'Free'}
                              </p>
                              <p className="font-mono text-[11px] text-[var(--ink-muted)]">
                                {avail.remainingSeats === null
                                  ? `${avail.registeredCount} registered · Unlimited`
                                  : `${avail.remainingSeats} of ${track.capacity} left`}
                              </p>
                            </div>
                            <StudioButton
                              variant={avail.canRegister ? 'primary' : 'secondary'}
                              size="sm"
                              disabled={!avail.canRegister}
                              onClick={() => openRegistrationModal(track.id)}
                            >
                              <Ticket className="h-3.5 w-3.5" />
                              <span>
                                {avail.canRegister ? 'Select & Register' : avail.statusLabel}
                              </span>
                            </StudioButton>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </AnimatedContent>
          )}

          {/* Speakers Section */}
          <AnimatedContent distance={44} duration={0.7} threshold={0.1}>
            <div className="studio-card p-6 sm:p-8 space-y-5">
              <div>
                <h2 className="text-xl font-display font-semibold text-[var(--color-2-mood)]">
                  Featured Speakers &amp; Jury
                </h2>
                <p className="text-xs text-[var(--ink-muted)] mt-1">
                  Confirmed founders, operators, and institutional investors for this program.
                </p>
              </div>
              <div className="divide-y divide-[var(--border-hairline)]">
                {evt.speakers.map((speaker) => (
                  <div
                    key={speaker.name}
                    className="py-4 first:pt-0 last:pb-0 flex items-start gap-4"
                  >
                    <MonogramAvatar name={speaker.name} size="md" tone="obsidian" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[var(--color-2-mood)]">
                        {speaker.name}
                      </p>
                      <p className="text-xs text-[var(--ink-muted)]">
                        {speaker.role} · {speaker.organization}
                      </p>
                      <p className="text-sm text-[var(--ink-secondary)] mt-1.5">{speaker.topic}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </AnimatedContent>
        </div>

        {/* Sticky Registration & SPOC Sidebar */}
        <aside className="lg:col-span-4 space-y-5 lg:sticky lg:top-[88px]">
          <div className="studio-card p-6 space-y-5">
            <div className="flex items-baseline justify-between gap-2 pb-4 border-b border-[var(--border-hairline)]">
              <div>
                <p className="text-xs text-[var(--ink-muted)]">
                  {multiTrack ? 'Registration Options' : 'Delegate Pass Fee'}
                </p>
                <p className="font-mono-data text-xl sm:text-2xl font-semibold text-[var(--color-2-mood)] mt-0.5">
                  {pricingSummary.label}
                </p>
              </div>
              <StatusBadge
                label={
                  multiTrack
                    ? `${pricingSummary.enabledTrackCount} Categories`
                    : evt.isPaid
                      ? 'UPI Proof Required'
                      : 'Instant Pass'
                }
                tone={pricingSummary.hasPaid ? 'crimson' : 'green'}
              />
            </div>

            <div className="space-y-3 text-sm text-[var(--ink-secondary)]">
              <div className="flex items-start gap-2.5">
                <Calendar className="h-4 w-4 text-[#C01E30] mt-0.5 shrink-0" />
                <div>
                  <p className="font-medium text-[var(--color-2-mood)]">{evt.dateLabel}</p>
                  <p className="text-xs text-[var(--ink-muted)]">Check-in opens 08:30 IST</p>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <MapPin className="h-4 w-4 text-[#C01E30] mt-0.5 shrink-0" />
                <p>{evt.venue}</p>
              </div>
              <div className="flex items-start gap-2.5">
                <Users className="h-4 w-4 text-[#C01E30] mt-0.5 shrink-0" />
                <div className="w-full space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-mono-data">
                    <span>{eventRegs.length} Registered</span>
                    <span>{evt.capacity ? `${evt.capacity} Max` : 'Unlimited'}</span>
                  </div>
                  {evt.capacity && (
                    <div className="h-1.5 w-full bg-[var(--surface-subtle)] rounded-[4px] overflow-hidden">
                      <div
                        className="h-full bg-[#C01E30]"
                        style={{ width: `${Math.max(8, capacityPct)}%` }}
                      />
                    </div>
                  )}
                </div>
              </div>
            </div>

            <LiquidButton
              variant="crimson"
              className="w-full"
              disabled={evt.status === 'Closed' || pricingSummary.openTrackCount === 0}
              onClick={() => openRegistrationModal(undefined)}
            >
              <Ticket className="h-4 w-4" />
              <span>
                {evt.status === 'Closed'
                  ? 'Event Closed'
                  : pricingSummary.openTrackCount === 0
                    ? 'Registrations Full'
                    : multiTrack
                      ? 'Choose Category & Register'
                      : 'Register Now'}
              </span>
            </LiquidButton>

            {pricingSummary.hasPaid && (
              <p className="text-xs text-[var(--ink-muted)] leading-relaxed">
                Paid categories display the category-specific EDC AITR UPI payment QR and require a
                UTR reference. Entry QR codes unlock once verified by the RD desk.
              </p>
            )}
          </div>

          {/* SPOC Contacts */}
          <div className="studio-card p-6 space-y-4">
            <h3 className="text-sm font-display font-semibold text-[var(--color-2-mood)]">
              Event SPOC Contacts
            </h3>
            <div className="space-y-3">
              {[spocPrimary, spocSecondary].filter(Boolean).map((spoc, i) => (
                <div key={spoc!.id} className="flex items-center gap-3">
                  <MonogramAvatar name={spoc!.name} size="sm" />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-[var(--color-2-mood)] truncate">
                      {spoc!.name} ({i === 0 ? 'Primary SPOC' : 'Secondary SPOC'})
                    </p>
                    <p className="text-[11px] text-[var(--ink-muted)] truncate">{spoc!.email}</p>
                    {spoc!.phone && (
                      <p className="text-[11px] font-mono-data text-[var(--ink-secondary)]">
                        {spoc!.phone}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>

      {/* Progressive Multi-Track / Single-Track Registration Modal */}
      <DynamicTrackRegistrationModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        event={evt}
        registrations={registrations}
        initialTrackId={preselectedTrackId}
        defaultName={currentUser?.name ?? ''}
        defaultEmail={currentUser?.email ?? ''}
        onSubmitRegistration={registerForEvent}
        onCompleted={(reg) => navigate(`/portal/registrations/${reg.id}`)}
        onNotify={pushToast}
      />
    </div>
  );
};
