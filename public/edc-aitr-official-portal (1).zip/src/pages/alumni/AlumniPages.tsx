import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  AlertCircle,
  ArrowDown,
  ArrowUpRight,
  Briefcase,
  Building2,
  Check,
  CheckCircle2,
  ExternalLink,
  FileText,
  GraduationCap,
  Linkedin,
  Loader2,
  MapPin,
  MessageSquare,
  Plus,
  Rocket,
  RotateCw,
  Search,
  Send,
  ShieldCheck,
  Users,
  X,
} from 'lucide-react';
import { usePortal } from '../../context/PortalContext';
import { useThemeToggle } from '../../context/ThemeContext';
import { MOTION_TRACKS, useMotionSystem } from '../../context/MotionContext';
import { OpportunityListing, StartupListing, UserProfile } from '../../types/portal';
import {
  ModalDialog,
  MonogramAvatar,
  StatusBadge,
  StudioButton,
} from '../../components/ui/Primitives';
import {
  createEditorialCrestDataUrl,
  EDC_FOIL_PATTERN_DATA_URL,
  ProfileCard,
} from '../../components/ui/ProfileCard';
import { MemberAvatar } from '../../components/identity/MemberAvatar';
import { canUserAppearInDirectory, getPublicProfilePath } from '../../utils/identityProfile';
import { useResolvedMediaUrl } from '../../utils/mediaStorage';
import { SelectDropdown } from '../../components/ui/dropdown-menu';
import { AnimatedContent } from '../../components/ui/AnimatedContent';
import { SpotlightCard } from '../../components/ui/SpotlightCard';
import {
  type QuickAction,
  type SearchFile,
  SearchModal,
  type SearchResult,
  type SearchTag,
} from '../../components/ui/SearchModal';

export const AlumniDirectoryPage: React.FC = () => {
  const { currentUser, users, startups, navigate, startOrOpenConversationWithUser, pushToast } = usePortal();
  const { isDark } = useThemeToggle();

  const [memberType, setMemberType] = useState<'all' | 'current' | 'alumni'>('all');
  const [batch, setBatch] = useState('ALL');
  const [city, setCity] = useState('ALL');
  const [industry, setIndustry] = useState('ALL');
  const [stage, setStage] = useState('ALL');
  const [query, setQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<UserProfile | null>(null);
  const { resolvedUrl: selectedAvatarUrl } = useResolvedMediaUrl(selectedProfile?.avatarUrl);

  useEffect(() => {
    if (!selectedProfile) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedProfile(null);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selectedProfile]);

  const allDirectoryUsers = useMemo(
    () =>
      users.filter(
        (u) =>
          u.role !== 'director' &&
          u.role !== 'advisor' &&
          canUserAppearInDirectory(u, currentUser)
      ),
    [currentUser, users]
  );

  const networkMembers = useMemo(() => {
    return allDirectoryUsers.filter((u) => {
      if (memberType === 'alumni' && u.role !== 'alumni') return false;
      if (memberType === 'current' && u.role === 'alumni') return false;
      if (batch !== 'ALL' && u.batch !== batch) return false;
      if (city !== 'ALL' && u.city !== city) return false;
      if (industry !== 'ALL' && u.industry !== industry) return false;
      if (stage !== 'ALL' && (u.startupStage ?? 'None') !== stage) return false;
      const q = query.trim().toLowerCase();
      if (
        q &&
        !u.name.toLowerCase().includes(q) &&
        !(u.company ?? '').toLowerCase().includes(q) &&
        !u.designation.toLowerCase().includes(q)
      ) {
        return false;
      }
      return true;
    });
  }, [allDirectoryUsers, memberType, batch, city, industry, stage, query]);

  const searchTags: SearchTag[] = useMemo(
    () => [
      { id: 'alumni', label: 'Alumni', icon: <GraduationCap className="h-3.5 w-3.5" /> },
      { id: 'member', label: 'Current Members', icon: <Users className="h-3.5 w-3.5" /> },
      { id: 'startup', label: 'Startups', icon: <Rocket className="h-3.5 w-3.5" /> },
    ],
    []
  );

  const searchResults: SearchResult[] = useMemo(() => {
    const memberResults: SearchResult[] = allDirectoryUsers.map((member) => ({
      id: `user:${member.id}`,
      name: member.name,
      meta: `${member.designation}${member.company ? ` · ${member.company}` : ''} · Batch ${member.batch}`,
      tagId: member.role === 'alumni' ? 'alumni' : 'member',
      initials: member.name
        .split(/\s+/)
        .slice(0, 2)
        .map((p) => p[0]?.toUpperCase() ?? '')
        .join(''),
      actions: [
        {
          icon: <MessageSquare className="h-3.5 w-3.5" />,
          label: `Message ${member.name}`,
          onClick: () => {
            setSearchOpen(false);
            startOrOpenConversationWithUser(member);
          },
        },
      ],
    }));

    const startupResults: SearchResult[] = startups.map((st) => ({
      id: `startup:${st.id}`,
      name: st.name,
      meta: `${st.industry} · ${st.fundingStage} · ${st.founderName}`,
      tagId: 'startup',
      initials: st.name.slice(0, 2).toUpperCase(),
    }));

    return [...memberResults, ...startupResults];
  }, [allDirectoryUsers, startups, startOrOpenConversationWithUser]);

  const searchQuickActions: QuickAction[] = useMemo(
    () => [
      {
        label: 'Open Startup Showcase',
        icon: <Building2 className="h-4 w-4" />,
        shortcut: 'S',
        onClick: () => {
          setSearchOpen(false);
          navigate('/alumni/startups');
        },
      },
      {
        label: 'Browse Opportunities Board',
        icon: <Briefcase className="h-4 w-4" />,
        shortcut: 'O',
        onClick: () => {
          setSearchOpen(false);
          navigate('/alumni/opportunities');
        },
      },
      {
        label: 'Open Direct Messages',
        icon: <MessageSquare className="h-4 w-4" />,
        shortcut: 'M',
        onClick: () => {
          setSearchOpen(false);
          navigate('/alumni/messages');
        },
      },
    ],
    [navigate]
  );

  const searchFiles: SearchFile[] = useMemo(
    () => [
      {
        name: 'CSI_Cohort_06_Playbook.pdf',
        ext: 'PDF',
        verified: true,
        onShare: () =>
          pushToast('Resource link copied', 'CSI Cohort 06 Playbook link ready to share.', 'success'),
      },
      {
        name: 'PitchBiz_2026_Investor_Brief.pdf',
        ext: 'PDF',
        verified: true,
        onShare: () =>
          pushToast('Resource link copied', 'PitchBiz Investor Brief link copied.', 'success'),
      },
      {
        name: 'EDC_AITR_Alumni_Charter.pdf',
        ext: 'PDF',
        verified: true,
        onShare: () =>
          pushToast('Resource link copied', 'EDC AITR Alumni Charter link copied.', 'success'),
      },
    ],
    [pushToast]
  );

  const selectedProfileArtwork = useMemo(() => {
    if (!selectedProfile) return null;
    return createEditorialCrestDataUrl({
      name: selectedProfile.name,
      batch: selectedProfile.batch,
      company: selectedProfile.company || selectedProfile.department,
      roleBadge:
        selectedProfile.role === 'alumni' ? 'VERIFIED ALUMNI' : 'ACTIVE CORE MEMBER',
    });
  }, [selectedProfile]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Alumni Connect · Private Network</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Verified Member &amp; Alumni Directory
          </h1>
          <p className="text-sm text-[var(--ink-muted)] mt-1">
            Discover EDC AITR founders, operators, and student builders. Select any profile to inspect their verified credential card.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setSearchOpen(true)}
          className="inline-flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-[9px] bg-[var(--surface)] border border-[var(--border-strong)] hover:border-[#C01E30] text-xs text-[var(--ink-secondary)] transition-colors cursor-pointer shrink-0 min-w-[230px]"
        >
          <span className="inline-flex items-center gap-2">
            <Search className="h-3.5 w-3.5 text-[#C01E30]" />
            <span>Quick Search Network...</span>
          </span>
          <kbd className="font-mono-data text-[10px] px-1.5 py-0.5 rounded-[4px] bg-[var(--surface-subtle)] border border-[var(--border-hairline)] text-[var(--ink-muted)]">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Global Cmd+K Command Palette for Alumni Connect */}
      <SearchModal
        modal
        open={searchOpen}
        onOpenChange={setSearchOpen}
        hotkey="k"
        placeholder="Search alumni, core members, startups, or briefs..."
        tags={searchTags}
        results={searchResults}
        quickActions={searchQuickActions}
        files={searchFiles}
        onSelectResult={(result) => {
          if (result.id?.startsWith('user:')) {
            const uid = result.id.slice(5);
            const matched = allDirectoryUsers.find((u) => u.id === uid);
            if (matched) {
              setSearchOpen(false);
              setSelectedProfile(matched);
            }
          } else if (result.id?.startsWith('startup:')) {
            setSearchOpen(false);
            navigate('/alumni/startups');
          }
        }}
      />

      {/* Multi-Facet Filter Bar */}
      <div className="studio-card p-4 space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="h-4 w-4 text-[var(--ink-muted)] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Filter directory by name, company, or role (or press ⌘K)..."
              className="studio-input pl-9 text-xs"
            />
          </div>

          <div className="inline-flex p-1 bg-[var(--surface-subtle)] border border-[var(--border-hairline)] rounded-[9px] self-start">
            {(
              [
                { id: 'all', label: 'All Verified' },
                { id: 'alumni', label: 'Alumni' },
                { id: 'current', label: 'Current Members' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setMemberType(opt.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-[6px] cursor-pointer ${
                  memberType === opt.id
                    ? 'bg-[var(--surface)] text-[var(--color-2-mood)] border border-[var(--border-hairline)]'
                    : 'text-[var(--ink-muted)] hover:text-[var(--color-2-mood)]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <SelectDropdown
            value={batch}
            onChange={setBatch}
            size="xs"
            className="w-full"
            menuLabel="Graduation Batch"
            options={[
              { value: 'ALL', label: 'All Batches' },
              { value: '2022', label: 'Batch 2022' },
              { value: '2023', label: 'Batch 2023' },
              { value: '2024', label: 'Batch 2024' },
              { value: '2025', label: 'Batch 2025' },
              { value: '2026', label: 'Batch 2026' },
              { value: '2027', label: 'Batch 2027' },
              { value: '2028', label: 'Batch 2028' },
            ]}
          />
          <SelectDropdown
            value={city}
            onChange={setCity}
            size="xs"
            className="w-full"
            menuLabel="City"
            options={[
              { value: 'ALL', label: 'All Cities' },
              { value: 'Indore', label: 'Indore' },
              { value: 'Bangalore', label: 'Bangalore' },
              { value: 'Dewas', label: 'Dewas' },
            ]}
          />
          <SelectDropdown
            value={industry}
            onChange={setIndustry}
            size="xs"
            className="w-full"
            menuLabel="Industry Sector"
            options={[
              { value: 'ALL', label: 'All Industries' },
              { value: 'Fintech', label: 'Fintech' },
              { value: 'AI', label: 'AI' },
              { value: 'D2C', label: 'D2C' },
              { value: 'EdTech', label: 'EdTech' },
              { value: 'SaaS', label: 'SaaS' },
              { value: 'Hardware & IoT', label: 'Hardware & IoT' },
            ]}
          />
          <SelectDropdown
            value={stage}
            onChange={setStage}
            size="xs"
            align="end"
            className="w-full"
            menuLabel="Startup Stage"
            options={[
              { value: 'ALL', label: 'All Startup Stages' },
              { value: 'Idea', label: 'Idea' },
              { value: 'Pre-Seed', label: 'Pre-Seed' },
              { value: 'Bootstrapped', label: 'Bootstrapped' },
              { value: 'Seed', label: 'Seed' },
              { value: 'Series A', label: 'Series A' },
            ]}
          />
        </div>
      </div>

      {/* Member Cards Grid */}
      {networkMembers.length === 0 ? (
        <div className="studio-card p-10 text-center text-sm text-[var(--ink-muted)]">
          No members match the selected directory filters.
        </div>
      ) : (
        <AnimatedContent
          key={`dir-${memberType}-${batch}-${city}-${industry}-${stage}`}
          trigger="mount"
          distance={26}
          duration={0.55}
          stagger={0.045}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {networkMembers.map((member) => (
            <article
              key={member.id}
              onClick={() => setSelectedProfile(member)}
              className="studio-card p-5 flex flex-col justify-between space-y-4 hover:border-[#C01E30]/60 hover:-translate-y-0.5 transition-all duration-200 cursor-pointer group"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <MemberAvatar
                      name={member.preferredName || member.name}
                      avatarUrl={member.avatarUrl}
                      avatarPosition={member.avatarPosition}
                      size="md"
                      tone={member.role === 'alumni' ? 'obsidian' : 'neutral'}
                    />
                    <div className="min-w-0">
                      <h2 className="text-sm font-semibold text-[var(--color-2-mood)] group-hover:text-[#C01E30] dark:group-hover:text-[#F87171] transition-colors truncate">
                        {member.preferredName || member.name}
                      </h2>
                      <p className="text-xs text-[var(--ink-secondary)] leading-snug mt-0.5">{member.designation}</p>
                      {member.company && (
                        <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171] mt-0.5 truncate">
                          {member.company}
                        </p>
                      )}
                    </div>
                  </div>
                  <a
                    href={member.linkedin}
                    target="_blank"
                    rel="noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    aria-label={`${member.name} LinkedIn`}
                    className="h-8 w-8 rounded-[9px] border border-[var(--border-hairline)] flex items-center justify-center text-[var(--ink-secondary)] hover:border-[#C01E30] hover:text-[#C01E30] dark:hover:text-[#F87171] shrink-0"
                  >
                    <Linkedin className="h-3.5 w-3.5" />
                  </a>
                </div>

                <div className="text-xs text-[var(--ink-muted)] space-y-1">
                  {member.pastEdcRole && (
                    <p className="text-[var(--ink-secondary)]">Past EDC Role: {member.pastEdcRole}</p>
                  )}
                  <p>
                    Batch {member.batch} · {member.city} · {member.industry}
                    {member.startupStage && member.startupStage !== 'None'
                      ? ` · ${member.startupStage}`
                      : ''}
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-[var(--border-hairline)] flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedProfile(member);
                  }}
                  className="text-[11px] font-medium text-[var(--ink-muted)] hover:text-[#C01E30] dark:hover:text-[#F87171] transition-colors cursor-pointer"
                >
                  {member.role === 'alumni' ? 'View Alumni Card' : 'View Member Card'}
                </button>
                <StudioButton
                  variant="secondary"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    startOrOpenConversationWithUser(member);
                  }}
                >
                  <MessageSquare className="h-3.5 w-3.5" />
                  <span>Send Message</span>
                </StudioButton>
              </div>
            </article>
          ))}
        </AnimatedContent>
      )}

      {/* 3D Holographic ProfileCard Modal */}
      {selectedProfile && selectedProfileArtwork && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`${selectedProfile.name} Alumni Credential Card`}
          onClick={() => setSelectedProfile(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative flex flex-col items-center gap-4"
          >
            <button
              type="button"
              onClick={() => setSelectedProfile(null)}
              aria-label="Close profile card"
              className="self-end h-9 w-9 rounded-full bg-[var(--surface)]/95 border border-[var(--border-strong)] flex items-center justify-center text-[var(--color-2-mood)] hover:border-[#C01E30] hover:text-[#C01E30] transition-colors cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>

            <ProfileCard
              theme={isDark ? 'dark' : 'light'}
              avatarUrl={selectedAvatarUrl || selectedProfileArtwork}
              miniAvatarUrl={selectedAvatarUrl || selectedProfileArtwork}
              iconUrl={EDC_FOIL_PATTERN_DATA_URL}
              name={selectedProfile.preferredName || selectedProfile.name}
              title={
                selectedProfile.company
                  ? `${selectedProfile.designation} · ${selectedProfile.company}`
                  : selectedProfile.designation
              }
              handle={selectedProfile.name.toLowerCase().replace(/[^a-z0-9]+/g, '.')}
              status={
                selectedProfile.role === 'alumni'
                  ? `Verified Alumni · Batch ${selectedProfile.batch}`
                  : `Active Member · Batch ${selectedProfile.batch}`
              }
              statusColor="#C01E30"
              contactText="Message"
              showUserInfo
              enableTilt
              onContactClick={() => {
                const target = selectedProfile;
                setSelectedProfile(null);
                startOrOpenConversationWithUser(target);
              }}
            />

            <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-white/80">
              <span>{selectedProfile.city}</span>
              <span aria-hidden="true">·</span>
              <span>{selectedProfile.industry}</span>
              <span aria-hidden="true">·</span>
              <button
                type="button"
                onClick={() => {
                  const path = getPublicProfilePath(selectedProfile.id);
                  setSelectedProfile(null);
                  navigate(path);
                }}
                className="inline-flex items-center gap-1 text-white underline underline-offset-4 hover:text-[#F87171] cursor-pointer"
              >
                <span>Open Full Profile</span>
                <ArrowUpRight className="h-3.5 w-3.5" />
              </button>
              {selectedProfile.startupStage && selectedProfile.startupStage !== 'None' && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{selectedProfile.startupStage}</span>
                </>
              )}
              {selectedProfile.linkedin && (
                <>
                  <span aria-hidden="true">·</span>
                  <a
                    href={selectedProfile.linkedin}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 underline hover:text-white"
                  >
                    <span>LinkedIn</span>
                    <ArrowUpRight className="h-3 w-3" />
                  </a>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export const StartupShowcasePage: React.FC = () => {
  const { startups, currentUser, addStartupListing } = usePortal();
  const [industryFilter, setIndustryFilter] = useState<string>('ALL');
  const [stageFilter, setStageFilter] = useState<string>('ALL');
  const [modalOpen, setModalOpen] = useState(false);

  const [name, setName] = useState('');
  const [tagline, setTagline] = useState('');
  const [industry, setIndustry] = useState<StartupListing['industry']>('SaaS');
  const [fundingStage, setFundingStage] = useState<StartupListing['fundingStage']>('Bootstrapped');
  const [pitchDeckUrl, setPitchDeckUrl] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [city, setCity] = useState('Indore');
  const [description, setDescription] = useState('');

  const filtered = startups.filter((s) => {
    const matchInd = industryFilter === 'ALL' || s.industry === industryFilter;
    const matchStg = stageFilter === 'ALL' || s.fundingStage === stageFilter;
    return matchInd && matchStg;
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !tagline.trim()) return;
    addStartupListing({
      name: name.trim(),
      tagline: tagline.trim(),
      founderName: currentUser?.name ?? 'EDC Founder',
      founderBatch: `Batch ${currentUser?.batch ?? '2026'}`,
      industry,
      fundingStage,
      pitchDeckUrl: pitchDeckUrl.trim() || 'https://docsend.com',
      websiteUrl: websiteUrl.trim() || 'https://acropolis.in',
      city: city.trim() || 'Indore',
      description: description.trim() || tagline.trim(),
    });
    setName('');
    setTagline('');
    setPitchDeckUrl('');
    setWebsiteUrl('');
    setDescription('');
    setModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Campus &amp; Alumni Ventures</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Startup Showcase
          </h1>
        </div>
        <StudioButton variant="primary" size="sm" onClick={() => setModalOpen(true)}>
          <Plus className="h-4 w-4" />
          <span>List Your Startup</span>
        </StudioButton>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2.5">
        {(['ALL', 'Fintech', 'EdTech', 'D2C', 'SaaS', 'AI'] as const).map((ind) => (
          <button
            key={ind}
            type="button"
            onClick={() => setIndustryFilter(ind)}
            className={`px-3 py-1.5 text-xs font-medium rounded-[9px] border cursor-pointer ${
              industryFilter === ind
                ? 'bg-[#030405] dark:bg-[#F1F0ED] text-white dark:text-[#101011] border-[#030405] dark:border-[#F1F0ED]'
                : 'bg-[var(--surface)] text-[var(--ink-secondary)] border-[var(--border-strong)] hover:bg-[var(--surface-subtle)]'
            }`}
          >
            {ind === 'ALL' ? 'All Industries' : ind}
          </button>
        ))}

        <SelectDropdown
          value={stageFilter}
          onChange={setStageFilter}
          size="xs"
          align="end"
          className="w-auto min-w-[165px] ml-auto"
          menuLabel="Funding Stage"
          options={[
            { value: 'ALL', label: 'All Funding Stages' },
            { value: 'Bootstrapped', label: 'Bootstrapped' },
            { value: 'Seed', label: 'Seed' },
            { value: 'Series A', label: 'Series A' },
          ]}
        />
      </div>

      {/* Ventures Grid */}
      <AnimatedContent
        key={`startups-${industryFilter}-${stageFilter}`}
        trigger="mount"
        distance={28}
        duration={0.58}
        stagger={0.06}
        className="grid grid-cols-1 md:grid-cols-2 gap-5"
      >
        {filtered.map((startup) => (
          <SpotlightCard
            key={startup.id}
            className="studio-card p-6 flex flex-col justify-between space-y-4 hover:border-[#C01E30]/50 transition-colors duration-200"
          >
            <div className="relative z-10 space-y-3">
              <div className="flex items-center justify-between gap-2 text-xs text-[var(--ink-muted)]">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-[#C01E30] dark:text-[#F87171]">{startup.industry}</span>
                  <span aria-hidden="true">·</span>
                  <span>{startup.city}</span>
                </div>
                <StatusBadge
                  label={startup.fundingStage}
                  tone={startup.fundingStage === 'Series A' ? 'obsidian' : startup.fundingStage === 'Seed' ? 'crimson' : 'neutral'}
                />
              </div>

              <div>
                <h2 className="text-xl font-display font-semibold text-[var(--color-2-mood)]">{startup.name}</h2>
                <p className="text-sm font-medium text-[var(--ink-secondary)] mt-1">{startup.tagline}</p>
              </div>
              <p className="text-xs text-[var(--ink-muted)] leading-relaxed">{startup.description}</p>
              <p className="text-xs text-[var(--ink-secondary)]">
                Founded by <strong className="text-[var(--color-2-mood)]">{startup.founderName}</strong> ·{' '}
                {startup.founderBatch}
              </p>
            </div>

            <div className="relative z-10 pt-4 border-t border-[var(--border-hairline)] flex flex-wrap items-center gap-2.5">
              <a
                href={startup.pitchDeckUrl}
                target="_blank"
                rel="noreferrer"
                className="btn-secondary px-3 py-1.5 text-xs font-medium inline-flex items-center gap-1.5"
              >
                <FileText className="h-3.5 w-3.5 text-[#C01E30] dark:text-[#F87171]" />
                <span>Secure Pitch Deck</span>
              </a>
              <a
                href={startup.websiteUrl}
                target="_blank"
                rel="noreferrer"
                className="btn-secondary px-3 py-1.5 text-xs font-medium inline-flex items-center gap-1.5"
              >
                <span>Website</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </div>
          </SpotlightCard>
        ))}
      </AnimatedContent>

      {/* List Your Startup Modal */}
      <ModalDialog
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        isDirty={Boolean(name.trim() || tagline.trim() || description.trim() || pitchDeckUrl.trim())}
        dirtyWarningText="Your startup listing draft has unsaved entries. Discard and close?"
        title="List Your Startup"
        subtitle="Add your student or alumni venture to the verified EDC AITR Showcase."
      >
        <form onSubmit={handleCreate} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Startup Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. VedaGrid Systems"
                className="studio-input"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">City</label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="studio-input"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">One-Line Tagline</label>
            <input
              type="text"
              required
              value={tagline}
              onChange={(e) => setTagline(e.target.value)}
              placeholder="Concise value proposition"
              className="studio-input"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Industry</label>
              <SelectDropdown
                value={industry}
                onChange={(val) => setIndustry(val as StartupListing['industry'])}
                size="sm"
                className="w-full"
                menuLabel="Industry"
                options={[
                  { value: 'Fintech', label: 'Fintech' },
                  { value: 'EdTech', label: 'EdTech' },
                  { value: 'D2C', label: 'D2C' },
                  { value: 'SaaS', label: 'SaaS' },
                  { value: 'AI', label: 'AI' },
                ]}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Funding Stage</label>
              <SelectDropdown
                value={fundingStage}
                onChange={(val) => setFundingStage(val as StartupListing['fundingStage'])}
                size="sm"
                align="end"
                className="w-full"
                menuLabel="Funding Stage"
                options={[
                  { value: 'Bootstrapped', label: 'Bootstrapped' },
                  { value: 'Seed', label: 'Seed' },
                  { value: 'Series A', label: 'Series A' },
                ]}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Pitch Deck URL</label>
              <input
                type="url"
                value={pitchDeckUrl}
                onChange={(e) => setPitchDeckUrl(e.target.value)}
                placeholder="https://docsend.com/..."
                className="studio-input text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Website URL</label>
              <input
                type="url"
                value={websiteUrl}
                onChange={(e) => setWebsiteUrl(e.target.value)}
                placeholder="https://..."
                className="studio-input text-xs"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Overview</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="studio-input"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <StudioButton type="button" variant="secondary" onClick={() => setModalOpen(false)}>
              Cancel
            </StudioButton>
            <StudioButton type="submit" variant="primary">
              Publish Startup
            </StudioButton>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
};

export const OpportunitiesBoardPage: React.FC = () => {
  const { opportunities, currentUser, addOpportunityListing, pushToast } = usePortal();
  const [typeFilter, setTypeFilter] = useState<string>('ALL');
  const [locFilter, setLocFilter] = useState<string>('ALL');
  const [postOpen, setPostOpen] = useState(false);
  const [applyTarget, setApplyTarget] = useState<OpportunityListing | null>(null);
  const [applyNote, setApplyNote] = useState('');

  // Post form
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState(currentUser?.company ?? '');
  const [type, setType] = useState<OpportunityListing['type']>('Full-time');
  const [location, setLocation] = useState<OpportunityListing['location']>('Indore');
  const [compensation, setCompensation] = useState('');
  const [contactEmail, setContactEmail] = useState(currentUser?.email ?? '');
  const [description, setDescription] = useState('');

  const filtered = opportunities.filter((o) => {
    const matchType = typeFilter === 'ALL' || o.type === typeFilter;
    const matchLoc = locFilter === 'ALL' || o.location === locFilter;
    return matchType && matchLoc;
  });

  const handlePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !company.trim()) return;
    addOpportunityListing({
      title: title.trim(),
      company: company.trim(),
      postedBy: `${currentUser?.name ?? 'Alumni'} · Batch ${currentUser?.batch ?? '2024'}`,
      type,
      location,
      compensation: compensation.trim() || 'Competitive',
      contactEmail: contactEmail.trim() || 'founders@acropolis.in',
      description: description.trim() || 'Direct referral role for EDC AITR network members.',
    });
    setTitle('');
    setCompensation('');
    setDescription('');
    setPostOpen(false);
  };

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!applyTarget) return;
    pushToast(
      'Referral request sent',
      `Your profile and note were shared with ${applyTarget.company} (${applyTarget.contactEmail}).`,
      'success'
    );
    setApplyNote('');
    setApplyTarget(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Talent &amp; Founding Teams</p>
          <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
            Opportunities &amp; Co-Founder Board
          </h1>
        </div>
        <StudioButton variant="primary" size="sm" onClick={() => setPostOpen(true)}>
          <Plus className="h-4 w-4" />
          <span>Post an Opportunity</span>
        </StudioButton>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2.5">
        {(['ALL', 'Full-time', 'Internship', 'Co-Founder equity'] as const).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTypeFilter(t)}
            className={`px-3 py-1.5 text-xs font-medium rounded-[9px] border cursor-pointer ${
              typeFilter === t
                ? 'bg-[#030405] dark:bg-[#F1F0ED] text-white dark:text-[#101011] border-[#030405] dark:border-[#F1F0ED]'
                : 'bg-[var(--surface)] text-[var(--ink-secondary)] border-[var(--border-strong)] hover:bg-[var(--surface-subtle)]'
            }`}
          >
            {t === 'ALL' ? 'All Types' : t}
          </button>
        ))}

        <div className="flex items-center gap-1.5 ml-auto">
          {(['ALL', 'Indore', 'Bangalore', 'Remote'] as const).map((loc) => (
            <button
              key={loc}
              type="button"
              onClick={() => setLocFilter(loc)}
              className={`px-3 py-1.5 text-xs font-medium rounded-[9px] border cursor-pointer ${
                locFilter === loc
                  ? 'bg-[var(--accent-soft)] text-[#C01E30] dark:text-[#F87171] border-[var(--accent-border)]'
                  : 'bg-[var(--surface)] text-[var(--ink-secondary)] border-[var(--border-strong)] hover:bg-[var(--surface-subtle)]'
              }`}
            >
              {loc === 'ALL' ? 'Any Location' : loc}
            </button>
          ))}
        </div>
      </div>

      <AnimatedContent
        key={`opps-${typeFilter}-${locFilter}`}
        trigger="mount"
        distance={26}
        duration={0.55}
        stagger={0.06}
        className="space-y-4"
      >
        {filtered.map((opp) => (
          <article
            key={opp.id}
            className="studio-card p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-5 hover:border-[#C01E30]/50 hover:-translate-y-0.5 transition-all duration-200"
          >
            <div className="space-y-2 max-w-2xl">
              <div className="flex flex-wrap items-center gap-2.5 text-xs text-[var(--ink-muted)]">
                <StatusBadge
                  label={opp.type}
                  tone={opp.type === 'Co-Founder equity' ? 'crimson' : 'obsidian'}
                />
                <span className="inline-flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5" />
                  {opp.location}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-data">{opp.compensation}</span>
              </div>
              <h2 className="text-lg font-display font-semibold text-[var(--color-2-mood)]">{opp.title}</h2>
              <p className="text-xs font-medium text-[var(--ink-secondary)]">
                {opp.company} · Posted by {opp.postedBy} · {opp.postedAt}
              </p>
              <p className="text-sm text-[var(--ink-muted)] leading-relaxed">{opp.description}</p>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <a
                href={`mailto:${opp.contactEmail}?subject=${encodeURIComponent(`EDC AITR Referral: ${opp.title}`)}`}
                className="btn-secondary px-3 py-2 text-xs font-medium inline-flex items-center gap-1.5"
              >
                <span>Direct Email</span>
                <ArrowUpRight className="h-3.5 w-3.5" />
              </a>
              <StudioButton variant="primary" size="sm" onClick={() => setApplyTarget(opp)}>
                <Briefcase className="h-3.5 w-3.5" />
                <span>Request Referral</span>
              </StudioButton>
            </div>
          </article>
        ))}
      </AnimatedContent>

      {/* Post Opportunity Modal */}
      <ModalDialog
        open={postOpen}
        onClose={() => setPostOpen(false)}
        isDirty={Boolean(title.trim() || company.trim() || description.trim() || compensation.trim())}
        dirtyWarningText="Your opportunity draft has unsaved fields. Discard and close?"
        title="Post an Opportunity"
        subtitle="Share a full-time role, internship, or co-founder equity seat with verified EDC AITR members."
      >
        <form onSubmit={handlePost} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Role Title</label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Founding Backend Engineer"
                className="studio-input"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Company / Venture</label>
              <input
                type="text"
                required
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                className="studio-input"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Opportunity Type</label>
              <SelectDropdown
                value={type}
                onChange={(val) => setType(val as OpportunityListing['type'])}
                size="sm"
                className="w-full"
                menuLabel="Opportunity Type"
                options={[
                  { value: 'Full-time', label: 'Full-time' },
                  { value: 'Internship', label: 'Internship' },
                  { value: 'Co-Founder equity', label: 'Co-Founder equity' },
                ]}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Location</label>
              <SelectDropdown
                value={location}
                onChange={(val) => setLocation(val as OpportunityListing['location'])}
                size="sm"
                align="end"
                className="w-full"
                menuLabel="Location"
                options={[
                  { value: 'Indore', label: 'Indore' },
                  { value: 'Bangalore', label: 'Bangalore' },
                  { value: 'Remote', label: 'Remote' },
                ]}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Compensation / Equity</label>
              <input
                type="text"
                value={compensation}
                onChange={(e) => setCompensation(e.target.value)}
                placeholder="e.g. ₹12 LPA or 15% Equity"
                className="studio-input text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Direct Contact Email</label>
              <input
                type="email"
                required
                value={contactEmail}
                onChange={(e) => setContactEmail(e.target.value)}
                className="studio-input text-xs"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1">Role Description</label>
            <textarea
              rows={3}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="studio-input"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <StudioButton type="button" variant="secondary" onClick={() => setPostOpen(false)}>
              Cancel
            </StudioButton>
            <StudioButton type="submit" variant="primary">
              Publish Listing
            </StudioButton>
          </div>
        </form>
      </ModalDialog>

      {/* Referral Application Modal */}
      <ModalDialog
        open={Boolean(applyTarget)}
        onClose={() => setApplyTarget(null)}
        isDirty={Boolean(applyNote.trim())}
        dirtyWarningText="Your referral pitch note has not been sent yet. Discard and close?"
        title={`Request Referral — ${applyTarget?.title ?? ''}`}
        subtitle={`${applyTarget?.company ?? ''} · ${applyTarget?.contactEmail ?? ''}`}
      >
        <form onSubmit={handleApply} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[var(--color-2-mood)] mb-1.5">
              Short Pitch &amp; Portfolio / Resume Link
            </label>
            <textarea
              rows={4}
              required
              value={applyNote}
              onChange={(e) => setApplyNote(e.target.value)}
              placeholder="Introduce your background, relevant projects, and GitHub/LinkedIn link..."
              className="studio-input"
            />
          </div>
          <div className="flex justify-end gap-2">
            <StudioButton type="button" variant="secondary" onClick={() => setApplyTarget(null)}>
              Cancel
            </StudioButton>
            <StudioButton type="submit" variant="primary">
              Send Referral Note
            </StudioButton>
          </div>
        </form>
      </ModalDialog>
    </div>
  );
};

export const AlumniMessagesPage: React.FC = () => {
  const {
    path,
    conversations,
    currentUser,
    acceptConversationRequest,
    sendMessageToConversation,
    retryMessageInConversation,
  } = usePortal();
  const { reducedMotion } = useMotionSystem();

  const threadParam = new URLSearchParams(path.split('?')[1] || '').get('thread');
  const [activeId, setActiveId] = useState<string>(threadParam || conversations[0]?.id || '');
  const [replyText, setReplyText] = useState('');
  const [sending, setSending] = useState(false);
  const [isNearBottom, setIsNearBottom] = useState(true);
  const [unseenBelowCount, setUnseenBelowCount] = useState(0);

  const feedRef = useRef<HTMLDivElement | null>(null);
  const prevConvIdRef = useRef<string>('');
  const prevMsgCountRef = useRef<number>(0);
  const shouldForceScrollRef = useRef<boolean>(false);
  const knownMessageIdsRef = useRef<Set<string>>(new Set());

  const activeConv = conversations.find((c) => c.id === activeId) ?? conversations[0];

  // Sync URL query param when navigating to a specific thread (e.g. from Command Palette or Directory)
  useEffect(() => {
    if (threadParam && conversations.some((c) => c.id === threadParam)) {
      setActiveId(threadParam);
    }
  }, [threadParam, conversations]);

  const scrollToBottom = (behavior: ScrollBehavior = 'smooth') => {
    const el = feedRef.current;
    if (!el) return;
    el.scrollTo({
      top: el.scrollHeight,
      behavior: reducedMotion ? 'auto' : behavior,
    });
    setUnseenBelowCount(0);
    setIsNearBottom(true);
  };

  // Track proximity to bottom without hijacking scroll when reading older messages
  const handleFeedScroll = () => {
    const el = feedRef.current;
    if (!el) return;
    const distanceFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const near = distanceFromBottom <= 72;
    setIsNearBottom(near);
    if (near) {
      setUnseenBelowCount(0);
    }
  };

  // On thread switch: mark existing messages as already seen (no replay) & snap to bottom once
  // On new message in active thread: scroll ONLY if user sent it OR is already near bottom
  useEffect(() => {
    if (!activeConv) return;
    const convChanged = prevConvIdRef.current !== activeConv.id;
    const msgCount = activeConv.messages.length;

    if (convChanged) {
      prevConvIdRef.current = activeConv.id;
      prevMsgCountRef.current = msgCount;
      knownMessageIdsRef.current = new Set(activeConv.messages.map((m) => m.id));
      setUnseenBelowCount(0);
      setIsNearBottom(true);
      requestAnimationFrame(() => scrollToBottom('auto'));
      return;
    }

    if (msgCount > prevMsgCountRef.current) {
      const added = msgCount - prevMsgCountRef.current;
      prevMsgCountRef.current = msgCount;

      if (shouldForceScrollRef.current || isNearBottom) {
        shouldForceScrollRef.current = false;
        requestAnimationFrame(() => scrollToBottom('smooth'));
      } else {
        setUnseenBelowCount((c) => c + added);
      }

      // Register newly arrived IDs after initial render frame so they animate once and never replay
      const timer = window.setTimeout(() => {
        activeConv.messages.forEach((m) => knownMessageIdsRef.current.add(m.id));
      }, 280);
      return () => window.clearTimeout(timer);
    }

    prevMsgCountRef.current = msgCount;
  }, [activeConv?.id, activeConv?.messages.length, isNearBottom]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeConv || !replyText.trim() || activeConv.status !== 'accepted' || sending) return;
    const draft = replyText;
    setReplyText('');
    setSending(true);
    shouldForceScrollRef.current = true;
    await sendMessageToConversation(activeConv.id, draft);
    setSending(false);
  };

  const handleRetry = async (messageId: string) => {
    if (!activeConv) return;
    await retryMessageInConversation(activeConv.id, messageId);
  };

  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs font-medium text-[#C01E30] dark:text-[#F87171]">Private Platform Inbox</p>
        <h1 className="text-2xl sm:text-3xl font-display font-semibold text-[var(--color-2-mood)] mt-1">
          In-App Messaging
        </h1>
      </div>

      <div className="studio-card overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-[540px]">
        {/* Left Pane: Active Conversation Threads */}
        <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-r border-[var(--border-hairline)] bg-[var(--color-1-mood)] flex flex-col">
          <div className="px-4 py-3 border-b border-[var(--border-hairline)] flex items-center justify-between">
            <span className="text-xs font-semibold text-[var(--color-2-mood)]">
              Conversations ({conversations.length})
            </span>
            <span className="text-[11px] text-[var(--ink-muted)]">Verified Members Only</span>
          </div>

          <div className="divide-y divide-[var(--border-hairline)] overflow-y-auto flex-1">
            {conversations.map((conv) => {
              const selected = activeConv?.id === conv.id;
              const lastMsg = conv.messages[conv.messages.length - 1];
              return (
                <button
                  key={conv.id}
                  type="button"
                  onClick={() => setActiveId(conv.id)}
                  className={`relative w-full text-left p-4 transition-colors duration-150 cursor-pointer space-y-1.5 ${
                    selected ? 'bg-[var(--surface)]' : 'hover:bg-[var(--surface)]/70'
                  }`}
                >
                  {selected && (
                    <span
                      aria-hidden="true"
                      className="absolute right-0 inset-y-0 w-0.5 bg-[#C01E30]"
                    />
                  )}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <MonogramAvatar
                        name={conv.peerName}
                        size="sm"
                        tone={conv.status === 'pending_request' ? 'crimson' : 'obsidian'}
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-[var(--color-2-mood)] truncate">
                          {conv.peerName}
                        </p>
                        <p className="text-[11px] text-[var(--ink-muted)] truncate">{conv.peerCompany}</p>
                      </div>
                    </div>
                    <span className="font-mono-data text-[10px] text-[var(--ink-muted)] shrink-0">
                      {conv.lastUpdated}
                    </span>
                  </div>
                  <p className="text-xs text-[var(--ink-secondary)] truncate pl-11">
                    {lastMsg?.text ?? 'New conversation started'}
                  </p>
                  {conv.status === 'pending_request' && (
                    <div className="pl-11 pt-0.5">
                      <StatusBadge label="First-Contact Request" tone="amber" />
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Pane: Chat History & Reply Composer */}
        <div className="lg:col-span-8 flex flex-col bg-[var(--surface)] relative">
          {!activeConv ? (
            <div className="flex-1 flex items-center justify-center p-8 text-sm text-[var(--ink-muted)]">
              Select a conversation thread to view messages.
            </div>
          ) : (
            <>
              <div className="px-6 py-4 border-b border-[var(--border-hairline)] flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <MonogramAvatar name={activeConv.peerName} size="md" tone="obsidian" />
                  <div className="min-w-0">
                    <h2 className="text-sm font-semibold text-[var(--color-2-mood)] truncate">
                      {activeConv.peerName}
                    </h2>
                    <p className="text-xs text-[var(--ink-muted)] truncate">
                      {activeConv.peerRole} · {activeConv.peerCompany}
                    </p>
                  </div>
                </div>
                <StatusBadge
                  label={activeConv.status === 'accepted' ? 'Connected' : 'Pending Approval'}
                  tone={activeConv.status === 'accepted' ? 'green' : 'amber'}
                />
              </div>

              {/* First-Contact Approval Banner */}
              <AnimatePresence initial={false}>
                {activeConv.status === 'pending_request' && (
                  <motion.div
                    initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={reducedMotion ? { opacity: 0 } : { opacity: 0, height: 0, marginTop: 0 }}
                    transition={{ duration: reducedMotion ? 0.01 : 0.18 }}
                    className="mx-6 mt-4 p-4 rounded-[9px] bg-[#FFFBEB] dark:bg-amber-950/40 border border-[#FDE68A] dark:border-amber-800/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-start gap-2.5 text-xs text-[var(--ink-secondary)]">
                      <ShieldCheck className="h-4 w-4 text-[#B45309] dark:text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-[var(--color-2-mood)]">
                          Accept conversation request from {activeConv.peerName}
                        </p>
                        <p className="mt-0.5 text-[var(--ink-muted)]">
                          First-contact messages require your approval before enabling replies.
                        </p>
                      </div>
                    </div>
                    <StudioButton
                      variant="primary"
                      size="sm"
                      onClick={() => acceptConversationRequest(activeConv.id)}
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      <span>Accept Request</span>
                    </StudioButton>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Messages Feed with Scroll Position Preservation */}
              <div className="relative flex-1 min-h-0">
                <div
                  ref={feedRef}
                  onScroll={handleFeedScroll}
                  role="log"
                  aria-live="polite"
                  aria-label={`Messages with ${activeConv.peerName}`}
                  className="p-6 space-y-4 overflow-y-auto max-h-[380px] h-full"
                >
                  {activeConv.messages.length === 0 ? (
                    <p className="text-xs text-[var(--ink-muted)] text-center py-8">
                      Start the conversation with {activeConv.peerName} below.
                    </p>
                  ) : (
                    activeConv.messages.map((msg) => {
                      const isMine =
                        msg.senderId === currentUser?.id ||
                        (!currentUser && msg.senderId === 'usr-student');
                      const isNewlyAdded = !knownMessageIdsRef.current.has(msg.id);
                      const status = msg.deliveryStatus ?? 'confirmed';

                      return (
                        <motion.div
                          key={msg.id}
                          initial={
                            isNewlyAdded && !reducedMotion
                              ? { opacity: 0, y: 10, scale: 0.98 }
                              : false
                          }
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          transition={
                            reducedMotion
                              ? { duration: 0.01 }
                              : MOTION_TRACKS.portalOperational.bubbleSpring
                          }
                          className={`flex flex-col ${isMine ? 'items-end' : 'items-start'}`}
                        >
                          <div
                            className={`max-w-[82%] rounded-[9px] px-4 py-3 text-sm leading-relaxed border transition-opacity ${
                              isMine
                                ? status === 'failed'
                                  ? 'bg-[var(--accent-soft)] text-[var(--color-2-mood)] border-[#C01E30]'
                                  : 'bg-[#030405] dark:bg-[#C01E30] text-white border-[#030405] dark:border-[#C01E30]'
                                : 'bg-[var(--color-1-mood)] text-[var(--color-2-mood)] border-[var(--border-hairline)]'
                            } ${status === 'pending' ? 'opacity-80' : 'opacity-100'}`}
                          >
                            <p>{msg.text}</p>
                          </div>

                          <div className="flex items-center gap-2 mt-1 px-1">
                            <span className="text-[10px] font-mono-data text-[var(--ink-muted)]">
                              {msg.senderName} · {msg.timestamp}
                            </span>

                            {isMine && status === 'pending' && (
                              <span className="inline-flex items-center gap-1 text-[10px] font-mono-data text-[var(--ink-muted)]">
                                <Loader2 className="h-3 w-3 animate-spin" />
                                <span>Sending…</span>
                              </span>
                            )}

                            {isMine && status === 'confirmed' && (
                              <span className="inline-flex items-center gap-0.5 text-[10px] font-mono-data text-[#15803D] dark:text-emerald-400">
                                <Check className="h-3 w-3" />
                                <span>Delivered</span>
                              </span>
                            )}

                            {isMine && status === 'failed' && (
                              <span className="inline-flex items-center gap-1.5 text-[10px] font-mono-data text-[#C01E30] dark:text-[#F87171]">
                                <AlertCircle className="h-3 w-3 shrink-0" />
                                <span>{msg.errorMessage ?? 'Failed to send'}</span>
                                <button
                                  type="button"
                                  onClick={() => handleRetry(msg.id)}
                                  className="inline-flex items-center gap-0.5 underline font-semibold hover:opacity-80 cursor-pointer"
                                >
                                  <RotateCw className="h-2.5 w-2.5" />
                                  <span>Retry</span>
                                </button>
                              </span>
                            )}
                          </div>
                        </motion.div>
                      );
                    })
                  )}
                </div>

                {/* Contextual Jump-to-Latest Button (only appears when scrolled up reading history) */}
                <AnimatePresence>
                  {!isNearBottom && (
                    <motion.button
                      type="button"
                      initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={reducedMotion ? { opacity: 0 } : { opacity: 0, y: 6 }}
                      transition={{ duration: reducedMotion ? 0.01 : 0.16 }}
                      onClick={() => scrollToBottom('smooth')}
                      className="absolute bottom-3 right-5 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#030405] dark:bg-[#F1F0ED] text-white dark:text-[#101011] text-xs font-medium shadow-md border border-[var(--border-strong)] cursor-pointer hover:opacity-90"
                    >
                      <ArrowDown className="h-3.5 w-3.5" />
                      <span>
                        {unseenBelowCount > 0
                          ? `${unseenBelowCount} new ${unseenBelowCount === 1 ? 'message' : 'messages'}`
                          : 'Jump to latest'}
                      </span>
                    </motion.button>
                  )}
                </AnimatePresence>
              </div>

              {/* Reply Box */}
              <form
                onSubmit={handleSend}
                className="p-4 border-t border-[var(--border-hairline)] bg-[var(--color-1-mood)] flex gap-2.5"
              >
                <input
                  type="text"
                  disabled={activeConv.status !== 'accepted'}
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder={
                    activeConv.status === 'accepted'
                      ? `Reply to ${activeConv.peerName}...`
                      : 'Accept the conversation request above to reply...'
                  }
                  className="studio-input flex-1 text-sm"
                />
                <StudioButton
                  type="submit"
                  variant="primary"
                  loading={sending}
                  disabled={activeConv.status !== 'accepted' || !replyText.trim() || sending}
                >
                  {!sending && <Send className="h-4 w-4" />}
                  <span>Send</span>
                </StudioButton>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
