import React from 'react';
import { Lock, UserCheck } from 'lucide-react';
import { PortalProvider, usePortal } from './context/PortalContext';
import { ThemeProvider } from './context/ThemeContext';
import { MotionProvider } from './context/MotionContext';
import { DEMO_PRESET_ACCOUNTS } from './data/seedData';
import { PublicLayout } from './components/layout/PublicLayout';
import { PortalShell } from './components/layout/PortalShell';
import { StudioButton, ToastStack } from './components/ui/Primitives';
import { CommandPalette } from './components/ui/CommandPalette';
import { EdcPreloader } from './components/ui/EdcPreloader';
import { HomePage } from './pages/public/HomePage';
import { EventDetailPage, EventsListPage } from './pages/public/EventsPage';
import { AboutPage, ContactPage, TeamPage } from './pages/public/AboutTeamContactPages';
import { AccountAuthPage } from './pages/auth/AccountAuthPage';
import {
  AnnouncementsPage,
  CertificatesPage,
  ParticipantDashboardPage,
  TicketDetailPage,
} from './pages/participant/ParticipantPages';
import {
  EventBuilderPage,
  TeamRosterPage,
  WorkspaceDashboardPage,
} from './pages/workspace/WorkspaceOverviewAndBuilder';
import {
  EventClosurePage,
  QrCheckinConsolePage,
  RegistrationsExportPage,
  TaskBoardPage,
} from './pages/workspace/WorkspaceOperationsPages';
import {
  ApplicationsReviewPage,
  MembershipApplyPage,
  MfaSetupPage,
} from './pages/workspace/GovernancePages';
import {
  AlumniDirectoryPage,
  AlumniMessagesPage,
  OpportunitiesBoardPage,
  StartupShowcasePage,
} from './pages/alumni/AlumniPages';
import { IdentityStudioPage } from './pages/identity/IdentityStudioPage';
import { PublicMemberProfilePage } from './pages/public/PublicMemberProfilePage';

const AccessGate: React.FC<{
  title: string;
  description: string;
  targetPath: string;
  staffOnly?: boolean;
}> = ({ title, description, targetPath, staffOnly = false }) => {
  const { signInAsUser, navigate } = usePortal();
  const presets = staffOnly
    ? DEMO_PRESET_ACCOUNTS.filter((p) => p.userId === 'usr-core-1' || p.userId === 'usr-director')
    : DEMO_PRESET_ACCOUNTS;

  return (
    <PublicLayout>
      <div className="max-w-xl mx-auto px-4 py-16">
        <div className="studio-card p-8 space-y-5">
          <div className="h-10 w-10 rounded-[9px] bg-[var(--accent-soft)] border border-[var(--accent-border)] flex items-center justify-center text-[#C01E30]">
            <Lock className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-xl font-display font-semibold text-[var(--color-2-mood)]">{title}</h1>
            <p className="text-sm text-[var(--ink-secondary)] mt-1 leading-relaxed">{description}</p>
          </div>
          <div className="space-y-2 pt-2 border-t border-[var(--border-hairline)]">
            <p className="text-xs font-medium text-[var(--ink-muted)]">Quick Demo Account Entry:</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {presets.map((preset) => (
                <StudioButton
                  key={preset.userId}
                  variant="secondary"
                  size="sm"
                  onClick={() => signInAsUser(preset.userId, targetPath)}
                  className="justify-start"
                >
                  <UserCheck className="h-3.5 w-3.5 text-[#C01E30]" />
                  <span>{preset.label}</span>
                </StudioButton>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between pt-2">
            <StudioButton variant="primary" size="sm" onClick={() => navigate('/account')}>
              Go to Full Sign In Page
            </StudioButton>
            <StudioButton variant="ghost" size="sm" onClick={() => navigate('/')}>
              Return Home
            </StudioButton>
          </div>
        </div>
      </div>
    </PublicLayout>
  );
};

const PortalRouter: React.FC = () => {
  const { path, currentUser, activeWorkspaceEventId, toasts, dismissToast, navigate } = usePortal();
  const cleanPath = path.split('?')[0].replace(/\/+$/, '') || '/';

  const isStaff =
    currentUser?.role === 'core_team' ||
    currentUser?.role === 'advisor' ||
    currentUser?.role === 'director';

  const renderRoute = () => {
    // SECTION 1: PUBLIC PORTAL
    if (cleanPath === '/') {
      return (
        <PublicLayout>
          <HomePage />
        </PublicLayout>
      );
    }
    if (cleanPath === '/events') {
      return (
        <PublicLayout>
          <EventsListPage />
        </PublicLayout>
      );
    }
    if (cleanPath.startsWith('/events/')) {
      const slug = cleanPath.replace('/events/', '');
      return (
        <PublicLayout>
          <EventDetailPage slug={slug} />
        </PublicLayout>
      );
    }
    if (cleanPath === '/about') {
      return (
        <PublicLayout>
          <AboutPage />
        </PublicLayout>
      );
    }
    if (cleanPath === '/team') {
      return (
        <PublicLayout>
          <TeamPage />
        </PublicLayout>
      );
    }
    if (cleanPath === '/contact') {
      return (
        <PublicLayout>
          <ContactPage />
        </PublicLayout>
      );
    }
    if (cleanPath.startsWith('/members/')) {
      const memberId = cleanPath.replace('/members/', '');
      return (
        <PublicLayout>
          <PublicMemberProfilePage memberId={memberId} />
        </PublicLayout>
      );
    }

    // AUTHENTICATION
    if (cleanPath === '/account') {
      return (
        <PublicLayout>
          <AccountAuthPage />
        </PublicLayout>
      );
    }

    // Membership Application (accessible inside portal if signed in, or clean public shell if guest)
    if (cleanPath === '/account/apply') {
      if (currentUser) {
        return (
          <PortalShell breadcrumb={['Participant Portal', 'Membership Application']}>
            <MembershipApplyPage />
          </PortalShell>
        );
      }
      return (
        <PublicLayout>
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10">
            <MembershipApplyPage />
          </div>
        </PublicLayout>
      );
    }

    // Ticket Detail (also accessible immediately after registration even before sign-in)
    if (cleanPath.startsWith('/portal/registrations/')) {
      const regId = cleanPath.replace('/portal/registrations/', '');
      if (currentUser) {
        return (
          <PortalShell breadcrumb={['Participant Portal', 'My Registrations', 'Digital Pass']}>
            <TicketDetailPage registrationId={regId} />
          </PortalShell>
        );
      }
      return (
        <PublicLayout>
          <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10">
            <TicketDetailPage registrationId={regId} />
          </div>
        </PublicLayout>
      );
    }

    // SECTION 2: PARTICIPANT PORTAL
    if (cleanPath === '/portal' || cleanPath === '/account/dashboard') {
      if (!currentUser) {
        return (
          <AccessGate
            title="Sign in to open Participant Portal"
            description="Access your QR event tickets, payment verification badges, official announcements, and verified certificates."
            targetPath="/portal"
          />
        );
      }
      return (
        <PortalShell breadcrumb={['Participant Portal', 'Dashboard']}>
          <ParticipantDashboardPage />
        </PortalShell>
      );
    }
    if (cleanPath === '/portal/announcements') {
      if (!currentUser) {
        return (
          <AccessGate
            title="Sign in to view Official Announcements"
            description="Read chronological campus conclave notices and download official delegate handbooks."
            targetPath="/portal/announcements"
          />
        );
      }
      return (
        <PortalShell breadcrumb={['Participant Portal', 'Announcements']}>
          <AnnouncementsPage />
        </PortalShell>
      );
    }
    if (cleanPath === '/portal/certificates') {
      if (!currentUser) {
        return (
          <AccessGate
            title="Sign in to view Verified Certificates"
            description="Download cryptographically cataloged participation, winner, and organizer certificates issued by EDC AITR."
            targetPath="/portal/certificates"
          />
        );
      }
      return (
        <PortalShell breadcrumb={['Participant Portal', 'My Certificates']}>
          <CertificatesPage />
        </PortalShell>
      );
    }
    if (cleanPath === '/portal/profile' || cleanPath === '/account/profile') {
      if (!currentUser) {
        return (
          <AccessGate
            title="Sign in to open Identity Studio"
            description="Manage your EDC AITR member profile, institutional credential card, professional bio, and public profile visibility."
            targetPath="/portal/profile"
          />
        );
      }
      return (
        <PortalShell breadcrumb={['Identity Studio', 'My Identity']}>
          <IdentityStudioPage />
        </PortalShell>
      );
    }

    // SECTION 3: TEAM WORKSPACE & GOVERNANCE
    if (
      cleanPath === '/workspace' ||
      cleanPath.startsWith('/workspace/') ||
      cleanPath === '/account/mfa' ||
      cleanPath === '/account/applications'
    ) {
      if (!currentUser || !isStaff) {
        return (
          <AccessGate
            title="Core Team, Advisor, or Director Access Required"
            description="The operational workspace (Event Builder, 12-Team Roster, Kanban, RD QR Check-in, Closure Lock, and Governance) is restricted to authorized EDC AITR leadership."
            targetPath={cleanPath}
            staffOnly
          />
        );
      }

      if (cleanPath === '/workspace') {
        return (
          <PortalShell
            breadcrumb={['Team Workspace', 'Command Center']}
            actionSlot={
              <StudioButton
                variant="primary"
                size="sm"
                onClick={() => navigate(`/workspace/events/${activeWorkspaceEventId}/checkin`)}
              >
                Open QR Check-in
              </StudioButton>
            }
          >
            <WorkspaceDashboardPage />
          </PortalShell>
        );
      }
      if (cleanPath === '/workspace/events/new') {
        return (
          <PortalShell breadcrumb={['Team Workspace', 'Event Builder', 'New Event']}>
            <EventBuilderPage eventId="new" />
          </PortalShell>
        );
      }
      if (cleanPath === '/account/mfa') {
        return (
          <PortalShell breadcrumb={['Governance', 'Director 2FA (TOTP)']}>
            <MfaSetupPage />
          </PortalShell>
        );
      }
      if (cleanPath === '/account/applications') {
        return (
          <PortalShell breadcrumb={['Governance', 'Application Reviews']}>
            <ApplicationsReviewPage />
          </PortalShell>
        );
      }

      const wsMatch = cleanPath.match(/^\/workspace\/events\/([^/]+)(?:\/(teams|tasks|checkin|registrations|closure))?$/);
      if (wsMatch) {
        const [, evtId, sub] = wsMatch;
        if (sub === 'teams') {
          return (
            <PortalShell breadcrumb={['Team Workspace', '12-Team Roster']}>
              <TeamRosterPage eventId={evtId} />
            </PortalShell>
          );
        }
        if (sub === 'tasks') {
          return (
            <PortalShell breadcrumb={['Team Workspace', 'Task Management Board']}>
              <TaskBoardPage eventId={evtId} />
            </PortalShell>
          );
        }
        if (sub === 'checkin') {
          return (
            <PortalShell breadcrumb={['Team Workspace', 'RD QR Check-in Console']}>
              <QrCheckinConsolePage eventId={evtId} />
            </PortalShell>
          );
        }
        if (sub === 'registrations') {
          return (
            <PortalShell breadcrumb={['Team Workspace', 'Registrations & Exports']}>
              <RegistrationsExportPage eventId={evtId} />
            </PortalShell>
          );
        }
        if (sub === 'closure') {
          return (
            <PortalShell breadcrumb={['Team Workspace', 'Closure & Permanent Records']}>
              <EventClosurePage eventId={evtId} />
            </PortalShell>
          );
        }
        return (
          <PortalShell breadcrumb={['Team Workspace', 'Event Builder']}>
            <EventBuilderPage eventId={evtId} />
          </PortalShell>
        );
      }
    }

    // SECTION 4: ALUMNI CONNECT
    if (cleanPath.startsWith('/alumni')) {
      if (!currentUser) {
        return (
          <AccessGate
            title="Sign in to access Alumni Connect"
            description="Browse the verified member & alumni directory, inspect campus startups, explore co-founder/job listings, and exchange direct messages."
            targetPath={cleanPath}
          />
        );
      }
      if (cleanPath === '/alumni/startups') {
        return (
          <PortalShell breadcrumb={['Alumni Connect', 'Startup Showcase']}>
            <StartupShowcasePage />
          </PortalShell>
        );
      }
      if (cleanPath === '/alumni/opportunities') {
        return (
          <PortalShell breadcrumb={['Alumni Connect', 'Opportunities & Co-Founder Board']}>
            <OpportunitiesBoardPage />
          </PortalShell>
        );
      }
      if (cleanPath === '/alumni/messages') {
        return (
          <PortalShell breadcrumb={['Alumni Connect', 'In-App Messaging']}>
            <AlumniMessagesPage />
          </PortalShell>
        );
      }
      return (
        <PortalShell breadcrumb={['Alumni Connect', 'Verified Directory']}>
          <AlumniDirectoryPage />
        </PortalShell>
      );
    }

    // Default fallback to Home
    return (
      <PublicLayout>
        <HomePage />
      </PublicLayout>
    );
  };

  return (
    <>
      {renderRoute()}
      <CommandPalette />
      <ToastStack toasts={toasts} onDismiss={dismissToast} />
    </>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <MotionProvider>
        <PortalProvider>
          <EdcPreloader />
          <PortalRouter />
        </PortalProvider>
      </MotionProvider>
    </ThemeProvider>
  );
}
